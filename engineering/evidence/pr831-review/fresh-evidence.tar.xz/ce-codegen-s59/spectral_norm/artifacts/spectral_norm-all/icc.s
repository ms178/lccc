main:
..B1.1: # Preds ..B1.0
  pushq %rbp #37.16
  movq %rsp, %rbp #37.16
  andq $-128, %rsp #37.16
  subq $64000, %rsp #37.16
  movl $3, %edi #37.16
  movl $10330110, %esi #37.16
  call __intel_new_feature_proc_init #37.16
..B1.27: # Preds ..B1.1
  vstmxcsr (%rsp) #37.16
  vmovupd .L_2il0floatpacket.0(%rip), %ymm0 #40.40
  orl $32832, (%rsp) #37.16
  xorl %edx, %edx #40.5
  vldmxcsr (%rsp) #37.16
  movl $12, %eax #40.5
..B1.2: # Preds ..B1.2 ..B1.27
  addl $16, %edx #40.5
  vmovupd %ymm0, 47904(%rsp,%rax,8) #40.33
  vmovupd %ymm0, 47936(%rsp,%rax,8) #40.33
  vmovupd %ymm0, 47968(%rsp,%rax,8) #40.33
  vmovupd %ymm0, 48000(%rsp,%rax,8) #40.33
  addq $16, %rax #40.5
  cmpl $2000, %edx #40.5
  jb ..B1.2 # Prob 99% #40.5
..B1.3: # Preds ..B1.2
  vmovdqu .L_2il0floatpacket.1(%rip), %xmm4 #10.24
  xorb %cl, %cl #42.5
  vxorpd %ymm3, %ymm3, %ymm3 #15.20
  xorl %edx, %edx #26.13
  vmovapd %ymm3, %ymm5 #15.20
  xorl %eax, %eax #26.13
  incl %eax #26.13
  vmovdqu .L_2il0floatpacket.2(%rip), %xmm2 #10.43
  vpxor %xmm1, %xmm1, %xmm1 #10.43
  vmovdqu .L_2il0floatpacket.3(%rip), %xmm0 #26.13
..B1.4: # Preds ..B1.20 ..B1.3
  xorl %r9d, %r9d #14.5
  movq %rdx, %rdi #14.5
  movl %eax, %r8d #14.5
..B1.5: # Preds ..B1.7 ..B1.4
  incl %r8d #10.24
  lea 1(%r9), %esi #10.24
  vmovd %r9d, %xmm6 #10.24
  vmovapd %ymm5, %ymm9 #15.20
  vmovd %esi, %xmm10 #10.24
  lea 2(%r8), %r9d #10.38
  vmovd %r8d, %xmm11 #10.24
  lea 1(%r8), %r10d #10.24
  vpunpckldq %xmm10, %xmm6, %xmm8 #10.24
  vpunpckldq %xmm11, %xmm10, %xmm14 #10.38
  vmovd %r9d, %xmm13 #10.38
  movq %rdx, %r9 #16.9
  vmovd %r10d, %xmm12 #10.24
  vpunpckldq %xmm12, %xmm11, %xmm7 #10.24
  vpunpckldq %xmm13, %xmm12, %xmm15 #10.38
  vpunpcklqdq %xmm7, %xmm8, %xmm8 #10.24
  vpunpcklqdq %xmm15, %xmm14, %xmm7 #10.38
  vpbroadcastd %xmm6, %xmm6 #18.9
..B1.6: # Preds ..B1.6 ..B1.5
  vpmulld %xmm7, %xmm8, %xmm11 #10.38
  vpaddd %xmm4, %xmm8, %xmm8 #10.24
  vpcmpgtd %xmm11, %xmm1, %xmm10 #10.43
  vpaddd %xmm4, %xmm7, %xmm7 #10.38
  vpand %xmm2, %xmm10, %xmm12 #10.51
  vpaddd %xmm12, %xmm11, %xmm13 #10.51
  vpsrad $1, %xmm13, %xmm14 #10.51
  vpaddd %xmm14, %xmm6, %xmm15 #10.51
  vpaddd %xmm2, %xmm15, %xmm10 #10.51
  vmovupd 48000(%rsp,%r9,8), %ymm11 #43.21
  addq $4, %r9 #16.9
  vcvtdq2pd %xmm10, %ymm12 #10.51
  vdivpd %ymm12, %ymm11, %ymm13 #17.13
  vaddpd %ymm9, %ymm13, %ymm9 #17.13
  cmpq $2000, %r9 #16.9
  jb ..B1.6 # Prob 82% #16.9
..B1.7: # Preds ..B1.6
  movl %esi, %r9d #14.5
  vextractf128 $1, %ymm9, %xmm6 #15.20
  vaddpd %xmm6, %xmm9, %xmm7 #15.20
  vunpckhpd %xmm7, %xmm7, %xmm8 #15.20
  vaddsd %xmm8, %xmm7, %xmm10 #15.20
  vmovsd %xmm10, (%rsp,%rdi,8) #33.18
  incq %rdi #10.24
  cmpl $2000, %esi #14.5
  jb ..B1.5 # Prob 91% #14.5
..B1.8: # Preds ..B1.7
  xorl %r9d, %r9d #23.5
  movq %rdx, %r8 #23.5
  movl %eax, %edi #23.5
..B1.9: # Preds ..B1.11 ..B1.8
  incl %edi #10.24
  lea 1(%r9), %esi #10.24
  vmovd %r9d, %xmm7 #10.24
  vmovapd %ymm5, %ymm8 #24.20
  vmovd %esi, %xmm10 #10.24
  lea 2(%rdi), %r9d #10.38
  vmovd %edi, %xmm11 #10.24
  lea 1(%rdi), %r10d #10.24
  vpunpckldq %xmm10, %xmm7, %xmm6 #10.24
  vpunpckldq %xmm11, %xmm10, %xmm14 #10.38
  vmovd %r9d, %xmm13 #10.38
  movq %rdx, %r9 #25.9
  vmovd %r10d, %xmm12 #10.24
  vpunpckldq %xmm12, %xmm11, %xmm9 #10.24
  vpunpckldq %xmm13, %xmm12, %xmm15 #10.38
  vpunpcklqdq %xmm9, %xmm6, %xmm7 #10.24
  vmovdqa %xmm0, %xmm9 #26.13
  vpunpcklqdq %xmm15, %xmm14, %xmm6 #10.38
..B1.10: # Preds ..B1.10 ..B1.9
  vpmulld %xmm6, %xmm7, %xmm11 #10.38
  vpaddd %xmm4, %xmm7, %xmm7 #10.24
  vpcmpgtd %xmm11, %xmm1, %xmm10 #10.43
  vpaddd %xmm4, %xmm6, %xmm6 #10.38
  vpand %xmm2, %xmm10, %xmm12 #10.51
  vpaddd %xmm12, %xmm11, %xmm13 #10.51
  vpsrad $1, %xmm13, %xmm14 #10.51
  vpaddd %xmm9, %xmm14, %xmm15 #10.51
  vpaddd %xmm4, %xmm9, %xmm9 #26.13
  vpaddd %xmm2, %xmm15, %xmm10 #10.51
  vmovupd (%rsp,%r9,8), %ymm11 #34.16
  addq $4, %r9 #25.9
  vcvtdq2pd %xmm10, %ymm12 #10.51
  vdivpd %ymm12, %ymm11, %ymm13 #26.13
  vaddpd %ymm8, %ymm13, %ymm8 #26.13
  cmpq $2000, %r9 #25.9
  jb ..B1.10 # Prob 82% #25.9
..B1.11: # Preds ..B1.10
  movl %esi, %r9d #23.5
  vextractf128 $1, %ymm8, %xmm6 #24.20
  vaddpd %xmm6, %xmm8, %xmm7 #24.20
  vunpckhpd %xmm7, %xmm7, %xmm9 #24.20
  vaddsd %xmm9, %xmm7, %xmm10 #24.20
  vmovsd %xmm10, 32000(%rsp,%r8,8) #43.24
  incq %r8 #10.24
  cmpl $2000, %esi #23.5
  jb ..B1.9 # Prob 91% #23.5
..B1.12: # Preds ..B1.11
  xorl %r9d, %r9d #14.5
  movq %rdx, %r8 #14.5
  movl %eax, %edi #14.5
..B1.13: # Preds ..B1.15 ..B1.12
  incl %edi #10.24
  lea 1(%r9), %esi #10.24
  vmovd %r9d, %xmm6 #10.24
  vmovapd %ymm5, %ymm9 #15.20
  vmovd %esi, %xmm10 #10.24
  lea 2(%rdi), %r9d #10.38
  vmovd %edi, %xmm11 #10.24
  lea 1(%rdi), %r10d #10.24
  vpunpckldq %xmm10, %xmm6, %xmm8 #10.24
  vpunpckldq %xmm11, %xmm10, %xmm14 #10.38
  vmovd %r9d, %xmm13 #10.38
  movq %rdx, %r9 #16.9
  vmovd %r10d, %xmm12 #10.24
  vpunpckldq %xmm12, %xmm11, %xmm7 #10.24
  vpunpckldq %xmm13, %xmm12, %xmm15 #10.38
  vpunpcklqdq %xmm7, %xmm8, %xmm8 #10.24
  vpunpcklqdq %xmm15, %xmm14, %xmm7 #10.38
  vpbroadcastd %xmm6, %xmm6 #18.9
..B1.14: # Preds ..B1.14 ..B1.13
  vpmulld %xmm7, %xmm8, %xmm11 #10.38
  vpaddd %xmm4, %xmm8, %xmm8 #10.24
  vpcmpgtd %xmm11, %xmm1, %xmm10 #10.43
  vpaddd %xmm4, %xmm7, %xmm7 #10.38
  vpand %xmm2, %xmm10, %xmm12 #10.51
  vpaddd %xmm12, %xmm11, %xmm13 #10.51
  vpsrad $1, %xmm13, %xmm14 #10.51
  vpaddd %xmm14, %xmm6, %xmm15 #10.51
  vpaddd %xmm2, %xmm15, %xmm10 #10.51
  vmovupd 32000(%rsp,%r9,8), %ymm11 #44.21
  addq $4, %r9 #16.9
  vcvtdq2pd %xmm10, %ymm12 #10.51
  vdivpd %ymm12, %ymm11, %ymm13 #17.13
  vaddpd %ymm9, %ymm13, %ymm9 #17.13
  cmpq $2000, %r9 #16.9
  jb ..B1.14 # Prob 82% #16.9
..B1.15: # Preds ..B1.14
  movl %esi, %r9d #14.5
  vextractf128 $1, %ymm9, %xmm6 #15.20
  vaddpd %xmm6, %xmm9, %xmm7 #15.20
  vunpckhpd %xmm7, %xmm7, %xmm8 #15.20
  vaddsd %xmm8, %xmm7, %xmm10 #15.20
  vmovsd %xmm10, 16000(%rsp,%r8,8) #33.18
  incq %r8 #10.24
  cmpl $2000, %esi #14.5
  jb ..B1.13 # Prob 91% #14.5
..B1.16: # Preds ..B1.15
  xorl %r9d, %r9d #23.5
  movq %rdx, %r8 #23.5
  movl %eax, %edi #23.5
..B1.17: # Preds ..B1.19 ..B1.16
  incl %edi #10.24
  lea 1(%r9), %esi #10.24
  vmovd %r9d, %xmm7 #10.24
  vmovapd %ymm5, %ymm8 #24.20
  vmovd %esi, %xmm10 #10.24
  lea 2(%rdi), %r9d #10.38
  vmovd %edi, %xmm11 #10.24
  lea 1(%rdi), %r10d #10.24
  vpunpckldq %xmm10, %xmm7, %xmm6 #10.24
  vpunpckldq %xmm11, %xmm10, %xmm14 #10.38
  vmovd %r9d, %xmm13 #10.38
  movq %rdx, %r9 #25.9
  vmovd %r10d, %xmm12 #10.24
  vpunpckldq %xmm12, %xmm11, %xmm9 #10.24
  vpunpckldq %xmm13, %xmm12, %xmm15 #10.38
  vpunpcklqdq %xmm9, %xmm6, %xmm7 #10.24
  vmovdqa %xmm0, %xmm9 #26.13
  vpunpcklqdq %xmm15, %xmm14, %xmm6 #10.38
..B1.18: # Preds ..B1.18 ..B1.17
  vpmulld %xmm6, %xmm7, %xmm11 #10.38
  vpaddd %xmm4, %xmm7, %xmm7 #10.24
  vpcmpgtd %xmm11, %xmm1, %xmm10 #10.43
  vpaddd %xmm4, %xmm6, %xmm6 #10.38
  vpand %xmm2, %xmm10, %xmm12 #10.51
  vpaddd %xmm12, %xmm11, %xmm13 #10.51
  vpsrad $1, %xmm13, %xmm14 #10.51
  vpaddd %xmm9, %xmm14, %xmm15 #10.51
  vpaddd %xmm4, %xmm9, %xmm9 #26.13
  vpaddd %xmm2, %xmm15, %xmm10 #10.51
  vmovupd 16000(%rsp,%r9,8), %ymm11 #34.16
  addq $4, %r9 #25.9
  vcvtdq2pd %xmm10, %ymm12 #10.51
  vdivpd %ymm12, %ymm11, %ymm13 #26.13
  vaddpd %ymm8, %ymm13, %ymm8 #26.13
  cmpq $2000, %r9 #25.9
  jb ..B1.18 # Prob 82% #25.9
..B1.19: # Preds ..B1.18
  movl %esi, %r9d #23.5
  vextractf128 $1, %ymm8, %xmm6 #24.20
  vaddpd %xmm6, %xmm8, %xmm7 #24.20
  vunpckhpd %xmm7, %xmm7, %xmm9 #24.20
  vaddsd %xmm9, %xmm7, %xmm10 #24.20
  vmovsd %xmm10, 48000(%rsp,%r8,8) #44.24
  incq %r8 #10.24
  cmpl $2000, %esi #23.5
  jb ..B1.17 # Prob 91% #23.5
..B1.20: # Preds ..B1.19
  incb %cl #42.5
  cmpb $10, %cl #42.5
  jb ..B1.4 # Prob 99% #42.5
..B1.21: # Preds ..B1.20
  vmovapd %ymm5, %ymm0 #47.16
  xorl %eax, %eax #48.5
..B1.22: # Preds ..B1.22 ..B1.21
  vmovupd 32000(%rsp,%rdx,8), %ymm6 #49.23
  lea 12(%rax), %edi #49.16
  vmovupd 32000(%rsp,%rdi,8), %ymm1 #49.23
  vfmadd231pd 48000(%rsp,%rdx,8), %ymm6, %ymm3 #49.9
  vmulpd %ymm1, %ymm1, %ymm7 #50.9
  addq $16, %rdx #48.5
  lea 8(%rax), %esi #49.16
  vmovupd 32000(%rsp,%rsi,8), %ymm2 #49.23
  lea 4(%rax), %ecx #49.16
  vmovupd 32000(%rsp,%rcx,8), %ymm4 #49.23
  vfmadd231pd %ymm2, %ymm2, %ymm7 #50.9
  vfmadd231pd 48000(%rsp,%rcx,8), %ymm4, %ymm0 #49.9
  vfmadd231pd 48000(%rsp,%rsi,8), %ymm2, %ymm3 #49.9
  vfmadd231pd %ymm4, %ymm4, %ymm7 #50.9
  vfmadd231pd 48000(%rsp,%rdi,8), %ymm1, %ymm0 #49.9
  vfmadd231pd %ymm6, %ymm6, %ymm7 #50.9
  addl $16, %eax #48.5
  vaddpd %ymm5, %ymm7, %ymm5 #50.9
  cmpl $2000, %eax #48.5
  jb ..B1.22 # Prob 99% #48.5
..B1.23: # Preds ..B1.22
  vaddpd %ymm0, %ymm3, %ymm0 #47.16
  movl $.L_2__STRING.0, %edi #52.5
  movl $1, %eax #52.5
  vextractf128 $1, %ymm0, %xmm1 #47.16
  vextractf128 $1, %ymm5, %xmm6 #47.24
  vaddpd %xmm1, %xmm0, %xmm2 #47.16
  vaddpd %xmm6, %xmm5, %xmm7 #47.24
  vunpckhpd %xmm2, %xmm2, %xmm3 #47.16
  vunpckhpd %xmm7, %xmm7, %xmm8 #47.24
  vaddsd %xmm3, %xmm2, %xmm4 #47.16
  vaddsd %xmm8, %xmm7, %xmm9 #47.24
  vdivsd %xmm9, %xmm4, %xmm0 #52.5
  vsqrtsd %xmm0, %xmm0, %xmm0 #52.5
  vzeroupper #52.5
  call printf #52.5
..B1.24: # Preds ..B1.23
  xorl %eax, %eax #53.12
  movq %rbp, %rsp #53.12
  popq %rbp #53.12
  ret #53.12
.L_2il0floatpacket.0:
.L_2il0floatpacket.1:
.L_2il0floatpacket.2:
.L_2il0floatpacket.3:
.L_2__STRING.0:

.LC13:
main:
  pushq %rbp
  movl $-117901064, %ecx
  vpcmpeqd %ymm7, %ymm7, %ymm7
  vpxor %xmm8, %xmm8, %xmm8
  vmovd %ecx, %xmm6
  movl $185273099, %ecx
  movl $buf.1+4096, %edx
  movl $buf.1, %eax
  vpbroadcastd %xmm6, %ymm6
  vpsrlw $8, %ymm7, %ymm7
  movq %rsp, %rbp
  andq $-32, %rsp
  subq $64, %rsp
  vmovdqa .LC0(%rip), %ymm2
  vpbroadcastq .LC16(%rip), %ymm15
  vpbroadcastq .LC17(%rip), %ymm14
  vmovdqa %ymm6, 32(%rsp)
  vmovd %ecx, %xmm6
  vpbroadcastq .LC18(%rip), %ymm13
  vpbroadcastq .LC19(%rip), %ymm12
  vpbroadcastd %xmm6, %ymm6
  vpbroadcastq .LC20(%rip), %ymm11
  vpbroadcastq .LC21(%rip), %ymm10
  vmovdqa %ymm6, (%rsp)
  vpbroadcastq .LC22(%rip), %ymm9
.L2:
  vpaddq %ymm15, %ymm2, %ymm1
  vpaddq %ymm13, %ymm2, %ymm4
  addq $32, %rax
  vperm2i128 $32, %ymm1, %ymm2, %ymm0
  vperm2i128 $49, %ymm1, %ymm2, %ymm1
  vpaddq %ymm11, %ymm2, %ymm5
  vpshufd $216, %ymm1, %ymm1
  vpshufd $216, %ymm0, %ymm0
  vpaddq %ymm9, %ymm2, %ymm6
  vpunpcklqdq %ymm1, %ymm0, %ymm0
  vpaddq %ymm14, %ymm2, %ymm1
  vperm2i128 $32, %ymm4, %ymm1, %ymm3
  vperm2i128 $49, %ymm4, %ymm1, %ymm1
  vpshufd $216, %ymm1, %ymm1
  vpshufd $216, %ymm3, %ymm3
  vpunpcklqdq %ymm1, %ymm3, %ymm3
  vpblendw $85, %ymm0, %ymm8, %ymm1
  vpblendw $85, %ymm3, %ymm8, %ymm3
  vpackusdw %ymm3, %ymm1, %ymm1
  vpaddq %ymm12, %ymm2, %ymm3
  vperm2i128 $32, %ymm5, %ymm3, %ymm0
  vperm2i128 $49, %ymm5, %ymm3, %ymm3
  vpaddq %ymm10, %ymm2, %ymm5
  vpshufd $216, %ymm3, %ymm3
  vpshufd $216, %ymm0, %ymm0
  vpermq $216, %ymm1, %ymm1
  vpunpcklqdq %ymm3, %ymm0, %ymm0
  vperm2i128 $32, %ymm6, %ymm5, %ymm3
  vperm2i128 $49, %ymm6, %ymm5, %ymm5
  vpshufd $216, %ymm3, %ymm3
  vpshufd $216, %ymm5, %ymm5
  vpblendw $85, %ymm0, %ymm8, %ymm0
  vpunpcklqdq %ymm5, %ymm3, %ymm3
  vpand %ymm1, %ymm7, %ymm1
  vpblendw $85, %ymm3, %ymm8, %ymm3
  vpackusdw %ymm3, %ymm0, %ymm0
  vpermq $216, %ymm0, %ymm0
  vpand %ymm0, %ymm7, %ymm0
  vpackuswb %ymm0, %ymm1, %ymm1
  vpermq $216, %ymm1, %ymm1
  vpsllw $3, %ymm1, %ymm0
  vpand 32(%rsp), %ymm0, %ymm0
  vpaddb %ymm1, %ymm0, %ymm0
  vpaddb %ymm0, %ymm0, %ymm0
  vpaddb %ymm0, %ymm0, %ymm0
  vpaddb %ymm1, %ymm0, %ymm0
  vpaddb (%rsp), %ymm0, %ymm0
  vmovdqa %ymm0, -32(%rax)
  vpbroadcastq .LC23(%rip), %ymm0
  vpaddq %ymm0, %ymm2, %ymm2
  cmpq %rax, %rdx
  jne .L2
  movl $1, %eax
.L3:
  leal -17(%rax), %edx
  movb %al, fr.0-1(%rax)
  incq %rax
  movb %dl, fr.0+6(%rax)
  cmpq $9, %rax
  jne .L3
  movabsq $578437695752307201, %rax
  movabsq $-579005069656919568, %rdx
  cmpq %rdx, fr.0+8(%rip)
  movl $287454020, fr.0+16(%rip)
  movq %rax, buf.1(%rip)
  movl $6, %eax
  jne .L12
  vmovdqa .LC2(%rip), %ymm5
  xorl %edx, %edx
  vmovdqa %ymm8, %ymm4
.L5:
  movl $buf.1, %eax
  vmovdqa %ymm8, %ymm2
  vmovdqa %ymm8, %ymm1
.L6:
  vperm2i128 $32, %ymm2, %ymm1, %ymm0
  vperm2i128 $49, %ymm2, %ymm1, %ymm3
  vpaddq %ymm5, %ymm2, %ymm2
  addq $8, %rax
  vpshufd $216, %ymm3, %ymm3
  vpshufd $216, %ymm0, %ymm0
  vpaddq %ymm5, %ymm1, %ymm1
  vpunpcklqdq %ymm3, %ymm0, %ymm0
  vpbroadcastd -8(%rax), %ymm3
  vpxor %ymm0, %ymm3, %ymm0
  vpaddd %ymm0, %ymm4, %ymm4
  cmpq $buf.1+4096, %rax
  jne .L6
  incl %edx
  cmpl $2500, %edx
  jne .L5
  vextracti128 $0x1, %ymm4, %xmm0
  xorl %eax, %eax
  movl $.LC13, %edi
  movabsq $4453885151207054848, %rdx
  vpaddd %xmm4, %xmm0, %xmm0
  vpsrldq $8, %xmm0, %xmm1
  vpaddd %xmm1, %xmm0, %xmm0
  vpsrldq $4, %xmm0, %xmm1
  vpaddd %xmm1, %xmm0, %xmm0
  vmovd %xmm0, %esi
  vzeroupper
  call printf
  xorl %eax, %eax
  leave
  ret
.L12:
  vzeroupper
  leave
  ret
.LC0:
.LC2:
.LC16:
.LC18:
.LC19:
.LC20:
.LC21:
.LC22:
.LC23:

.Lstr0:

main.buf.0:
main.fr.1:

main:
    pushq %rbx
    pushq %r12
    subq $24, %rsp
    leaq main.buf.0(%rip), %rbx
    xorl %r9d, %r9d
.LBB1:
    cmpq $4096, %r9
jae .LBB3
.LBB2:
    imulq $37, %r9, %rdx
    leaq 11(%rdx), %r11
    movb %r11b, (%rbx, %r9)
    addq $1, %r9
    cmpq $4096, %r9
jb .LBB2
.LBB3:
    movb $1, main.fr.1(%rip)
    movb $240, main.fr.1+8(%rip)
    movb $2, main.fr.1+1(%rip)
    movb $241, main.fr.1+9(%rip)
    movb $3, main.fr.1+2(%rip)
    movb $242, main.fr.1+10(%rip)
    movb $4, main.fr.1+3(%rip)
    movb $243, main.fr.1+11(%rip)
    movb $5, main.fr.1+4(%rip)
    movb $244, main.fr.1+12(%rip)
    movb $6, main.fr.1+5(%rip)
    movb $245, main.fr.1+13(%rip)
    movb $7, main.fr.1+6(%rip)
    movb $246, main.fr.1+14(%rip)
    movb $8, main.fr.1+7(%rip)
    movb $247, main.fr.1+15(%rip)
    movl $287454020, main.fr.1+16(%rip)
    movb $1, main.buf.0(%rip)
    movb $2, main.buf.0+1(%rip)
    movb $3, main.buf.0+2(%rip)
    movb $4, main.buf.0+3(%rip)
    movb $5, main.buf.0+4(%rip)
    movb $6, main.buf.0+5(%rip)
    movb $7, main.buf.0+6(%rip)
    movb $8, main.buf.0+7(%rip)
    movzwl main.buf.0(%rip), %r9d
    cmpw $513, %r9w
je .LBB5
.LBB4:
    movl $2, %eax
.L__lccc_epilogue_1:
    addq $24, %rsp
    popq %r12
    popq %rbx
    ret
.LBB5:
    movzbl main.buf.0(%rip), %edi
    movl %edi, %esi
    movzbl main.buf.0+1(%rip), %edx
    movl %edx, %r11d
    shll $8, %r11d
    orl %r11d, %esi
    movzbl main.buf.0+2(%rip), %r10d
    movl %r10d, %r9d
    shll $16, %r9d
    orl %r9d, %esi
    movzbl main.buf.0+3(%rip), %r11d
    movl %r11d, %r9d
    shll $24, %r9d
    orl %r9d, %esi
    cmpl $67305985, %esi
je .LBB7
.LBB6:
    movl $3, %eax
    jmp .L__lccc_epilogue_1
.LBB7:
    movzbl %dil, %esi
    movzbl %dl, %r9d
    shlq $8, %r9
    orq %r9, %rsi
    movzbl %r10b, %edi
    shlq $16, %rdi
    orq %rdi, %rsi
    movzbl %r11b, %edx
    shlq $24, %rdx
    orq %rdx, %rsi
    movzbl main.buf.0+4(%rip), %r11d
    movl %r11d, %r10d
    shlq $32, %r10
    orq %r10, %rsi
    movzbl main.buf.0+5(%rip), %r9d
    movl %r9d, %edi
    shlq $40, %rdi
    orq %rdi, %rsi
    movzbl main.buf.0+6(%rip), %edx
    movl %edx, %r10d
    shlq $48, %r10
    orq %r10, %rsi
    movabsq $576460752303423488, %rax
    orq %rax, %rsi
    movabsq $578437695752307201, %rcx
    cmpq %rcx, %rsi
je .LBB9
.LBB8:
    movl $4, %eax
    jmp .L__lccc_epilogue_1
.LBB9:
    movzbl main.buf.0(%rip), %edi
    shlq $56, %rdi
    movzbl main.buf.0+1(%rip), %esi
    shlq $48, %rsi
    orq %rsi, %rdi
    movzbl main.buf.0+2(%rip), %r10d
    shlq $40, %r10
    orq %r10, %rdi
    movzbl main.buf.0+3(%rip), %esi
    shlq $32, %rsi
    orq %rsi, %rdi
    movzbl %r11b, %r10d
    shlq $24, %r10
    orq %r10, %rdi
    movzbl %r9b, %esi
    shlq $16, %rsi
    orq %rsi, %rdi
    movzbl %dl, %r11d
    shlq $8, %r11
    orq %r11, %rdi
    orq $8, %rdi
    movabsq $72623859790382856, %rcx
    cmpq %rcx, %rdi
je .LBB11
.LBB10:
    movl $5, %eax
    jmp .L__lccc_epilogue_1
.LBB11:
    movabsq $-579005069656919568, %rcx
    cmpq %rcx, main.fr.1+8(%rip)
jne .LBB19
.LBB12:
    xorl %r11d, %r11d
    xorl %r12d, %r12d
    xorl %r10d, %r10d
.LBB13:
    cmpq $20000, %r12
jae .LBB18
.LBB14:
    xorl %edi, %edi
    movq %r11, %rsi
    movq %rbx, %rdx
.LBB15:
    cmpq $4088, %rdi
ja .LBB17
.LBB16:
    movl (%rdx), %r8d
    xorl %edi, %r8d
    addl %r8d, %esi
    addq $8, %rdi
    leaq 8(%rdx), %rdx
    cmpq $4088, %rdi
jbe .LBB16
.LBB17:
    addq main.fr.1+8(%rip), %r10
    addq $1, %r12
    movq %rsi, %r11
    cmpq $20000, %r12
jb .LBB14
.LBB18:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    movq %r10, %rdx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    jmp .L__lccc_epilogue_1
.LBB19:
    movl $6, %eax
    jmp .L__lccc_epilogue_1



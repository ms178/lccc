main:
..B1.1: # Preds ..B1.0
  pushq %rbp #60.16
  movq %rsp, %rbp #60.16
  andq $-128, %rsp #60.16
  pushq %r12 #60.16
  pushq %r13 #60.16
  pushq %r14 #60.16
  pushq %r15 #60.16
  pushq %rbx #60.16
  subq $88, %rsp #60.16
  movl $3, %edi #60.16
  movl $10330110, %esi #60.16
  call __intel_new_feature_proc_init #60.16
..B1.21: # Preds ..B1.1
  vstmxcsr (%rsp) #60.16
  vmovdqu .L_2il0floatpacket.1(%rip), %ymm1 #68.43
  vmovdqu .L_2il0floatpacket.2(%rip), %ymm0 #68.43
  orl $32832, (%rsp) #60.16
  xorl %edx, %edx #65.20
  vldmxcsr (%rsp) #60.16
  xorl %esi, %esi #64.18
  xorl %eax, %eax #67.5
..B1.2: # Preds ..B1.2 ..B1.21
  vmovdqu %ymm0, buf.129.0.6(%rax) #68.9
  vpaddb %ymm1, %ymm0, %ymm0 #68.43
  vpaddb %ymm1, %ymm0, %ymm2 #68.43
  vmovdqu %ymm0, 32+buf.129.0.6(%rax) #68.9
  vpaddb %ymm1, %ymm2, %ymm3 #68.43
  vmovdqu %ymm2, 64+buf.129.0.6(%rax) #68.9
  vmovdqu %ymm3, 96+buf.129.0.6(%rax) #68.9
  vpaddb %ymm1, %ymm3, %ymm0 #68.43
  addq $128, %rax #67.5
  cmpq $4096, %rax #67.5
  jb ..B1.2 # Prob 99% #67.5
..B1.3: # Preds ..B1.2
  vmovq .L_2__cnst_pck.0(%rip), %xmm2 #76.14
  movq $0x807060504030201, %rdi #70.9
  vmovq %xmm2, buf.129.0.6(%rip) #76.5
  movq $0xf7f6f5f4f3f2f1f0, %r12 #71.9
  movzbl 1+buf.129.0.6(%rip), %ecx #78.14
  movl %ecx, %r10d #18.59
  shll $8, %r10d #18.59
  movzbl buf.129.0.6(%rip), %ebx #78.14
  orl %ebx, %r10d #18.59
  vmovq %rdi, %xmm0 #70.9
  vmovq %r12, %xmm1 #71.9
  vmovq %xmm0, fr.129.0.6(%rip) #70.9
  vmovq %xmm1, 8+fr.129.0.6(%rip) #71.9
  movl $287454020, 16+fr.129.0.6(%rip) #73.5
  cmpl $513, %r10d #78.22
  je ..B1.5 # Prob 42% #78.22
..B1.4: # Preds ..B1.3
  vzeroupper #79.16
  movl $2, %eax #79.16
  addq $88, %rsp #79.16
  popq %rbx #79.16
  popq %r15 #79.16
  popq %r14 #79.16
  popq %r13 #79.16
  popq %r12 #79.16
  movq %rbp, %rsp #79.16
  popq %rbp #79.16
  ret #79.16
..B1.5: # Preds ..B1.3
  movzbl 2+buf.129.0.6(%rip), %r14d #80.14
  movl %r14d, %r8d #23.31
  movzbl 3+buf.129.0.6(%rip), %eax #80.14
  movl %eax, %r9d #23.56
  shll $16, %r8d #23.31
  shll $24, %r9d #23.56
  orl %r8d, %r10d #23.31
  orl %r9d, %r10d #23.56
  cmpl $67305985, %r10d #80.22
  je ..B1.7 # Prob 42% #80.22
..B1.6: # Preds ..B1.5
  vzeroupper #81.16
  movl $3, %eax #81.16
  addq $88, %rsp #81.16
  popq %rbx #81.16
  popq %r15 #81.16
  popq %r14 #81.16
  popq %r13 #81.16
  popq %r12 #81.16
  movq %rbp, %rsp #81.16
  popq %rbp #81.16
  ret #81.16
..B1.7: # Preds ..B1.5
  movq %rcx, %r13 #27.48
  movq %r14, %r15 #27.72
  shlq $8, %r13 #27.48
  orq %rbx, %r13 #27.48
  shlq $16, %r15 #27.72
  orq %r15, %r13 #27.72
  movq %rax, %r15 #28.31
  shlq $24, %r15 #28.31
  movzbl 4+buf.129.0.6(%rip), %r8d #82.14
  orq %r15, %r13 #28.31
  movq %r8, %r15 #28.56
  shlq $32, %r15 #28.56
  movzbl 5+buf.129.0.6(%rip), %r9d #82.14
  orq %r15, %r13 #28.56
  movq %r9, %r15 #29.31
  shlq $40, %r15 #29.31
  movzbl 6+buf.129.0.6(%rip), %r10d #82.14
  orq %r15, %r13 #29.31
  movq %r10, %r15 #29.56
  shlq $48, %r15 #29.56
  movzbl 7+buf.129.0.6(%rip), %r11d #82.14
  orq %r15, %r13 #29.56
  movq %r11, %r15 #30.31
  shlq $56, %r15 #30.31
  orq %r15, %r13 #30.31
  cmpq %r13, %rdi #82.22
  je ..B1.9 # Prob 42% #82.22
..B1.8: # Preds ..B1.7
  vzeroupper #83.16
  movl $4, %eax #83.16
  addq $88, %rsp #83.16
  popq %rbx #83.16
  popq %r15 #83.16
  popq %r14 #83.16
  popq %r13 #83.16
  popq %r12 #83.16
  movq %rbp, %rsp #83.16
  popq %rbp #83.16
  ret #83.16
..B1.9: # Preds ..B1.7
  shlq $56, %rbx #37.31
  movq $0x102030405060708, %rdi #84.5
  shlq $48, %rcx #37.56
  shlq $40, %r14 #38.31
  orq %rcx, %rbx #37.56
  shlq $32, %rax #38.56
  orq %r14, %rbx #38.31
  shlq $24, %r8 #39.31
  orq %rax, %rbx #38.56
  shlq $16, %r9 #39.56
  orq %r8, %rbx #39.31
  shlq $8, %r10 #40.31
  orq %r9, %rbx #39.56
  orq %r10, %rbx #40.31
  orq %r11, %rbx #40.46
  cmpq %rbx, %rdi #84.22
  je ..B1.11 # Prob 42% #84.22
..B1.10: # Preds ..B1.9
  vzeroupper #85.16
  movl $5, %eax #85.16
  addq $88, %rsp #85.16
  popq %rbx #85.16
  popq %r15 #85.16
  popq %r14 #85.16
  popq %r13 #85.16
  popq %r12 #85.16
  movq %rbp, %rsp #85.16
  popq %rbp #85.16
  ret #85.16
..B1.11: # Preds ..B1.9
  movzbl 9+fr.129.0.6(%rip), %ecx #52.40
  shlq $8, %rcx #52.48
  movzbl 8+fr.129.0.6(%rip), %eax #52.22
  movzbl 10+fr.129.0.6(%rip), %ebx #52.64
  orq %rcx, %rax #52.48
  shlq $16, %rbx #52.72
  movzbl 11+fr.129.0.6(%rip), %edi #53.23
  orq %rbx, %rax #52.72
  shlq $24, %rdi #53.31
  movzbl 12+fr.129.0.6(%rip), %r8d #53.48
  orq %rdi, %rax #53.31
  shlq $32, %r8 #53.56
  movzbl 13+fr.129.0.6(%rip), %r9d #54.23
  orq %r8, %rax #53.56
  shlq $40, %r9 #54.31
  movzbl 14+fr.129.0.6(%rip), %r10d #54.48
  orq %r9, %rax #54.31
  shlq $48, %r10 #54.56
  movzbl 15+fr.129.0.6(%rip), %r11d #55.23
  orq %r10, %rax #54.56
  shlq $56, %r11 #55.31
  orq %r11, %rax #55.31
  cmpq %rax, %r12 #86.27
  je ..B1.13 # Prob 72% #86.27
..B1.12: # Preds ..B1.11
  vzeroupper #87.16
  movl $6, %eax #87.16
  addq $88, %rsp #87.16
  popq %rbx #87.16
  popq %r15 #87.16
  popq %r14 #87.16
  popq %r13 #87.16
  popq %r12 #87.16
  movq %rbp, %rsp #87.16
  popq %rbp #87.16
  ret #87.16
..B1.13: # Preds ..B1.11
  xorl %ebx, %ebx #88.10
  movl $8, %ecx #89.44
..B1.14: # Preds ..B1.16 ..B1.13
  xorl %r8d, %r8d #89.14
  movq %rcx, %rdi #89.44
..B1.15: # Preds ..B1.15 ..B1.14
  movzbl 1+buf.129.0.6(%r8), %r9d #90.25
  shll $8, %r9d #22.48
  movzbl buf.129.0.6(%r8), %r12d #90.25
  movzbl 2+buf.129.0.6(%r8), %r10d #90.25
  orl %r9d, %r12d #22.48
  shll $16, %r10d #23.31
  movzbl 3+buf.129.0.6(%r8), %r11d #90.25
  orl %r10d, %r12d #23.31
  shll $24, %r11d #23.56
  orl %r11d, %r12d #23.56
  xorl %r8d, %r12d #90.46
  movq %rdi, %r8 #89.44
  addq $8, %rdi #89.26
  addl %r12d, %esi #90.13
  cmpq $4096, %rdi #89.32
  jbe ..B1.15 # Prob 82% #89.32
..B1.16: # Preds ..B1.15
  incl %ebx #88.29
  addq %rax, %rdx #91.9
  cmpl $20000, %ebx #88.21
  jb ..B1.14 # Prob 99% #88.21
..B1.17: # Preds ..B1.16
  movl $.L_2__STRING.0, %edi #93.5
  xorl %eax, %eax #93.5
  vzeroupper #93.5
  call printf #93.5
..B1.18: # Preds ..B1.17
  xorl %eax, %eax #94.12
  addq $88, %rsp #94.12
  popq %rbx #94.12
  popq %r15 #94.12
  popq %r14 #94.12
  popq %r13 #94.12
  popq %r12 #94.12
  movq %rbp, %rsp #94.12
  popq %rbp #94.12
  ret #94.12
buf.129.0.6:
fr.129.0.6:
.L_2il0floatpacket.1:
.L_2il0floatpacket.2:
.L_2__cnst_pck.0:
.L_2__STRING.0:

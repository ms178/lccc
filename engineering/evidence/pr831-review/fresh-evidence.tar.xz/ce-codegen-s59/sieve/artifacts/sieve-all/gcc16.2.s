count_primes:
  subq $8, %rsp
  movl $10000001, %edx
  movl $1, %esi
  movl $sieve, %edi
  call memset
  xorl %eax, %eax
  movl $2, %ecx
  movw %ax, sieve(%rip)
  movl $4, %eax
  jmp .L4
.L2:
  leal 1(%rdi), %eax
  incq %rcx
  imull %eax, %eax
  cmpl $10000000, %eax
  jg .L12
.L4:
  cmpb $0, sieve(%rcx)
  movl %ecx, %edi
  je .L2
  movl %ecx, %esi
.L3:
  movslq %eax, %rdx
  addl %esi, %eax
  movb $0, sieve(%rdx)
  cmpl $10000000, %eax
  jle .L3
  leal 1(%rdi), %eax
  incq %rcx
  imull %eax, %eax
  cmpl $10000000, %eax
  jle .L4
.L12:
  movl $sieve+2, %eax
  movl $sieve+10000001, %ecx
  xorl %edx, %edx
.L6:
  cmpb $1, (%rax)
  sbbl $-1, %edx
  incq %rax
  cmpq %rax, %rcx
  jne .L6
  movl %edx, %eax
  addq $8, %rsp
  ret
.LC0:
main:
  subq $24, %rsp
  call count_primes
  movl $10000000, %esi
  movl $.LC0, %edi
  movl %eax, 12(%rsp)
  movl 12(%rsp), %edx
  xorl %eax, %eax
  call printf
  xorl %eax, %eax
  addq $24, %rsp
  ret

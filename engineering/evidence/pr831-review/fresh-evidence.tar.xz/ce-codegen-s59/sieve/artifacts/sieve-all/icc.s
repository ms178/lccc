main:
..B1.1: # Preds ..B1.0
  pushq %rbp #24.16
  movq %rsp, %rbp #24.16
  andq $-128, %rsp #24.16
  subq $128, %rsp #24.16
  movl $3, %edi #24.16
  movl $10330110, %esi #24.16
  call __intel_new_feature_proc_init #24.16
..B1.17: # Preds ..B1.1
  vstmxcsr 4(%rsp) #24.16
  movl $sieve, %edi #12.5
  movl $1, %esi #12.5
  orl $32832, 4(%rsp) #24.16
  movl $10000001, %edx #12.5
  vldmxcsr 4(%rsp) #24.16
  call __intel_avx_rep_memset #12.5
..B1.2: # Preds ..B1.17
  xorl %esi, %esi #13.5
  movl $2, %ecx #14.16
  movb %sil, sieve(%rip) #13.5
  movl $2, %edx #14.16
  movb %sil, 1+sieve(%rip) #13.16
..B1.3: # Preds ..B1.8 ..B1.2
  cmpb $0, sieve(%rdx) #15.13
  je ..B1.8 # Prob 50% #15.13
..B1.4: # Preds ..B1.3
  movl %ecx, %eax #16.28
  imull %ecx, %eax #16.28
  movslq %eax, %rax #16.28
  cmpq $10000000, %rax #16.36
  jg ..B1.8 # Prob 10% #16.36
..B1.6: # Preds ..B1.4 ..B1.6
  movb $0, sieve(%rax) #17.17
  addq %rdx, %rax #16.39
  cmpq $10000000, %rax #16.36
  jle ..B1.6 # Prob 99% #16.36
..B1.8: # Preds ..B1.6 ..B1.3 ..B1.4
  incl %ecx #14.33
  incq %rdx #14.33
  movl %ecx, %eax #14.25
  imull %ecx, %eax #14.25
  cmpl $10000000, %eax #14.30
  jle ..B1.3 # Prob 82% #14.30
..B1.9: # Preds ..B1.8
  movl %esi, %ecx #19.5
  xorb %dl, %dl #19.5
  movl $2, %eax #19.5
..B1.10: # Preds ..B1.10 ..B1.9
  cmpb sieve(%rax), %cl #20.23
  adcl $0, %esi #20.23
  incb %dl #19.5
  cmpb 1+sieve(%rax), %cl #20.23
  adcl $0, %esi #20.23
  addq $2, %rax #19.5
  cmpb $15, %dl #19.5
  jb ..B1.10 # Prob 99% #19.5
..B1.11: # Preds ..B1.10
  vmovd %esi, %xmm4 #18.15
  movl $30, %edx #19.5
  vpxor %ymm3, %ymm3, %ymm3 #18.15
  movl $32, %eax #19.5
  vmovdqa %ymm3, %ymm6 #18.15
  vmovdqa %ymm6, %ymm2 #18.15
  vmovdqa %ymm2, %ymm5 #18.15
  vpcmpeqd %ymm1, %ymm1, %ymm1 #20.13
  vmovaps %xmm4, %xmm4 #18.15
..B1.12: # Preds ..B1.12 ..B1.11
  vmovdqu sieve(%rax), %ymm7 #20.13
  addl $32, %edx #19.5
  addq $32, %rax #19.5
  vpmovsxbd %xmm7, %ymm8 #20.13
  vextracti128 $1, %ymm7, %xmm0 #20.13
  vpsrldq $8, %xmm7, %xmm11 #20.13
  vpcmpeqd %ymm8, %ymm3, %ymm9 #20.13
  vpxor %ymm1, %ymm9, %ymm10 #20.13
  vpmovsxbd %xmm0, %ymm15 #20.13
  vpsrldq $8, %xmm0, %xmm0 #20.13
  vpmovsxbd %xmm11, %ymm12 #20.13
  vpmovsxbd %xmm0, %ymm9 #20.13
  vpsubd %ymm10, %ymm4, %ymm4 #20.23
  vpcmpeqd %ymm12, %ymm3, %ymm13 #20.13
  vpcmpeqd %ymm15, %ymm3, %ymm7 #20.13
  vpcmpeqd %ymm9, %ymm3, %ymm10 #20.13
  vpxor %ymm1, %ymm13, %ymm14 #20.13
  vpxor %ymm1, %ymm7, %ymm8 #20.13
  vpxor %ymm1, %ymm10, %ymm11 #20.13
  vpsubd %ymm14, %ymm6, %ymm6 #20.23
  vpsubd %ymm8, %ymm2, %ymm2 #20.23
  vpsubd %ymm11, %ymm5, %ymm5 #20.23
  cmpl $9999998, %edx #19.5
  jb ..B1.12 # Prob 99% #19.5
..B1.13: # Preds ..B1.12
  vpaddd %ymm6, %ymm4, %ymm0 #18.15
  movl $.L_2__STRING.0, %edi #26.5
  vpaddd %ymm2, %ymm0, %ymm1 #18.15
  movl $10000000, %esi #26.5
  vpaddd %ymm5, %ymm1, %ymm2 #18.15
  cmpb 10000000+sieve(%rip), %cl #20.23
  vextractf128 $1, %ymm2, %xmm3 #18.15
  vpaddd %xmm3, %xmm2, %xmm4 #18.15
  vpsrldq $8, %xmm4, %xmm5 #18.15
  vpaddd %xmm5, %xmm4, %xmm6 #18.15
  vpsrlq $32, %xmm6, %xmm7 #18.15
  vpaddd %xmm7, %xmm6, %xmm8 #18.15
  vmovd %xmm8, %eax #18.15
  adcl $0, %eax #20.23
  movl %eax, (%rsp) #25.25
  xorl %eax, %eax #26.5
  movl (%rsp), %edx #26.40
  vzeroupper #26.5
  call printf #26.5
..B1.14: # Preds ..B1.13
  xorl %eax, %eax #27.12
  movq %rbp, %rsp #27.12
  popq %rbp #27.12
  ret #27.12
count_primes:
..B2.1: # Preds ..B2.0
  pushq %rbp #11.24
  movq %rsp, %rbp #11.24
  andq $-32, %rsp #11.24
  movl $sieve, %edi #12.5
  movl $1, %esi #12.5
  movl $10000001, %edx #12.5
  call __intel_avx_rep_memset #12.5
..B2.2: # Preds ..B2.1
  xorl %esi, %esi #13.5
  movl $2, %ecx #14.16
  movb %sil, sieve(%rip) #13.5
  movl $2, %edx #14.16
  movb %sil, 1+sieve(%rip) #13.16
..B2.3: # Preds ..B2.8 ..B2.2
  cmpb $0, sieve(%rdx) #15.13
  je ..B2.8 # Prob 50% #15.13
..B2.4: # Preds ..B2.3
  movl %ecx, %eax #16.28
  imull %ecx, %eax #16.28
  movslq %eax, %rax #16.28
  cmpq $10000000, %rax #16.36
  jg ..B2.8 # Prob 10% #16.36
..B2.6: # Preds ..B2.4 ..B2.6
  movb $0, sieve(%rax) #17.17
  addq %rdx, %rax #16.39
  cmpq $10000000, %rax #16.36
  jle ..B2.6 # Prob 99% #16.36
..B2.8: # Preds ..B2.6 ..B2.3 ..B2.4
  incl %ecx #14.33
  incq %rdx #14.33
  movl %ecx, %eax #14.25
  imull %ecx, %eax #14.25
  cmpl $10000000, %eax #14.30
  jle ..B2.3 # Prob 82% #14.30
..B2.9: # Preds ..B2.8
  movl %esi, %ecx #19.5
  xorb %dl, %dl #19.5
  movl $2, %eax #19.5
..B2.10: # Preds ..B2.10 ..B2.9
  cmpb sieve(%rax), %cl #20.23
  adcl $0, %esi #20.23
  incb %dl #19.5
  cmpb 1+sieve(%rax), %cl #20.23
  adcl $0, %esi #20.23
  addq $2, %rax #19.5
  cmpb $15, %dl #19.5
  jb ..B2.10 # Prob 99% #19.5
..B2.11: # Preds ..B2.10
  vmovd %esi, %xmm4 #18.15
  movl $30, %edx #19.5
  vpxor %ymm3, %ymm3, %ymm3 #18.15
  movl $32, %eax #19.5
  vmovdqa %ymm3, %ymm6 #18.15
  vmovdqa %ymm6, %ymm2 #18.15
  vmovdqa %ymm2, %ymm5 #18.15
  vpcmpeqd %ymm1, %ymm1, %ymm1 #20.13
  vmovaps %xmm4, %xmm4 #18.15
..B2.12: # Preds ..B2.12 ..B2.11
  vmovdqu sieve(%rax), %ymm7 #20.13
  addl $32, %edx #19.5
  addq $32, %rax #19.5
  vpmovsxbd %xmm7, %ymm8 #20.13
  vextracti128 $1, %ymm7, %xmm0 #20.13
  vpsrldq $8, %xmm7, %xmm11 #20.13
  vpcmpeqd %ymm8, %ymm3, %ymm9 #20.13
  vpxor %ymm1, %ymm9, %ymm10 #20.13
  vpmovsxbd %xmm0, %ymm15 #20.13
  vpsrldq $8, %xmm0, %xmm0 #20.13
  vpmovsxbd %xmm11, %ymm12 #20.13
  vpmovsxbd %xmm0, %ymm9 #20.13
  vpsubd %ymm10, %ymm4, %ymm4 #20.23
  vpcmpeqd %ymm12, %ymm3, %ymm13 #20.13
  vpcmpeqd %ymm15, %ymm3, %ymm7 #20.13
  vpcmpeqd %ymm9, %ymm3, %ymm10 #20.13
  vpxor %ymm1, %ymm13, %ymm14 #20.13
  vpxor %ymm1, %ymm7, %ymm8 #20.13
  vpxor %ymm1, %ymm10, %ymm11 #20.13
  vpsubd %ymm14, %ymm6, %ymm6 #20.23
  vpsubd %ymm8, %ymm2, %ymm2 #20.23
  vpsubd %ymm11, %ymm5, %ymm5 #20.23
  cmpl $9999998, %edx #19.5
  jb ..B2.12 # Prob 99% #19.5
..B2.13: # Preds ..B2.12
  vpaddd %ymm6, %ymm4, %ymm0 #18.15
  vpaddd %ymm2, %ymm0, %ymm1 #18.15
  vpaddd %ymm5, %ymm1, %ymm2 #18.15
  cmpb 10000000+sieve(%rip), %cl #21.12
  vextractf128 $1, %ymm2, %xmm3 #18.15
  vpaddd %xmm3, %xmm2, %xmm4 #18.15
  vpsrldq $8, %xmm4, %xmm5 #18.15
  vpaddd %xmm5, %xmm4, %xmm6 #18.15
  vpsrlq $32, %xmm6, %xmm7 #18.15
  vpaddd %xmm7, %xmm6, %xmm8 #18.15
  vmovd %xmm8, %eax #18.15
  adcl $0, %eax #21.12
  vzeroupper #21.12
  movq %rbp, %rsp #21.12
  popq %rbp #21.12
  ret #21.12
sieve:
.L_2__STRING.0:

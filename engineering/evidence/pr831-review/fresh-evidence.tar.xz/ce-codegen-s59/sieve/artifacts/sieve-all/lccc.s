.Lstr0:

sieve:

count_primes:
    subq $8, %rsp
    leaq sieve(%rip), %rdi
    movl $1, %esi
    movl $10000001, %edx
    call memset@PLT
    leaq sieve(%rip), %r11
    movb $0, sieve+1(%rip)
    movb $0, (%r11)
    movl $2, %r10d
.LBB1:
    movl %r10d, %r8d
    imull %r10d, %r8d
    cmpl $10000000, %r8d
jg .LBB7
.LBB2:
    movslq %r10d, %r9
    cmpb $0, (%r11, %r9)
je .LBB6
.LBB3:
    movl %r10d, %edx
    imull %r10d, %edx
.LBB4:
    cmpl $10000000, %edx
jg .LBB6
.LBB5:
    movslq %edx, %r8
    movb $0, (%r11, %r8)
    addl %r10d, %edx
    cmpl $10000000, %edx
jle .LBB5
.LBB6:
    addl $1, %r10d
    movl %r10d, %edi
    imull %r10d, %edi
    cmpl $10000000, %edi
jle .LBB2
.LBB7:
    xorl %esi, %esi
    movl $2, %edx
.LBB8:
    cmpq $10000000, %rdx
jg .LBB10
.LBB9:
    leal 1(%rsi), %r9d
    cmpb $0, (%r11, %rdx)
    cmovnel %r9d, %esi
    addq $1, %rdx
    cmpq $10000000, %rdx
jle .LBB9
.LBB10:
    movl %esi, %eax
    addq $8, %rsp
    ret

main:
    subq $24, %rsp
    call count_primes@PLT
    movl %eax, 16(%rsp)
    movslq 16(%rsp), %r11
    leaq .Lstr0(%rip), %rdi
    movl $10000000, %esi
    movq %r11, %rdx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $24, %rsp
    ret



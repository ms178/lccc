.Lstr0:

tls_slots:
tls_indirect:

tls_pass:
    pushq %r14
    movq %fs:0, %rax
    leaq tls_slots@TPOFF(%rax), %rdx
    leaq 8(%rdx), %r8
    movq %r8, %fs:tls_indirect@TPOFF
    movl %edi, %r9d
    movq %r9, %fs:tls_slots@TPOFF+8
    movl %edi, %r11d
    xorl %r10d, %r10d
    movl $2, %edi
.LBB1:
    cmpq $64, %rdi
jg .LBB3
.LBB2:
    addq %r11, %r9
    movq %r9, (%rdx, %rdi, 8)
    movq %rdi, %rsi
    andq $7, %rsi
    movq 8(%rdx, %rsi, 8), %r14
    xorq %r9, %r14
    addq %r14, %r10
    addq $1, %rdi
    cmpq $64, %rdi
jle .LBB2
.LBB3:
    movq %fs:tls_indirect@TPOFF, %rdx
    addq (%rdx), %r10
    movq %r10, %rax
    popq %r14
    ret

main:
    pushq %rbx
    pushq %r12
    subq $24, %rsp
    xorl %ebx, %ebx
    xorl %r12d, %r12d
.LBB5:
    cmpl $200000, %r12d
jae .LBB7
.LBB6:
    movl %r12d, %r11d
    orl $1, %r11d
    movl %r11d, %edi
    call tls_pass
    addq %rax, %rbx
    addl $1, %r12d
    cmpl $200000, %r12d
jb .LBB6
.LBB7:
    leaq .Lstr0(%rip), %rdi
    movq %rbx, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $24, %rsp
    popq %r12
    popq %rbx
    ret



.Lstr0:

perm:
perm1:
count:
maxflips:
checksum:

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $56, %rsp
    movl $0, maxflips(%rip)
    movl $0, checksum(%rip)
    leaq perm1(%rip), %r11
    movl $0, (%r11)
    movl $1, perm1+4(%rip)
    movl $2, perm1+8(%rip)
    movl $3, perm1+12(%rip)
    movl $4, perm1+16(%rip)
    movl $5, perm1+20(%rip)
    movl $6, perm1+24(%rip)
    movl $7, perm1+28(%rip)
    movl $8, perm1+32(%rip)
    movl $9, perm1+36(%rip)
    movl $10, perm1+40(%rip)
    leaq perm(%rip), %r8
    movq %r11, 16(%rsp)
    movq $11, 40(%rsp)
    movq $0, 32(%rsp)
.LBB1:
.LBB2:
    movslq 40(%rsp), %rax
    cmpl $1, %eax
jg .LBB15
.LBB3:
    xorl %edi, %edi
.LBB4:
    cmpq $32, %rdi
jge .LBB6
.LBB5:
    movq 16(%rsp), %rax
    vmovdqu (%rax,%rdi), %ymm2
    vmovdqu %ymm2, (%r8,%rdi)
    addq $32, %rdi
    cmpq $32, %rdi
jl .LBB5
.LBB6:
    shrq $2, %rdi
    movslq %edi, %rsi
.LBB7:
    cmpl $11, %esi
jl .LBB14
.LBB8:
    xorl %r13d, %r13d
.LBB9:
    movl (%r8), %edi
    testl %edi, %edi
je .LBB16
.LBB10:
    leal 1(%rdi), %r14d
    sarl $1, %r14d
    xorl %r10d, %r10d
.LBB11:
    cmpl %r14d, %r10d
jge .LBB13
.LBB12:
    movslq %r10d, %r15
    movl (%r8, %r15, 4), %ebp
    movl %edi, %esi
    subl %r10d, %esi
    movslq %esi, %rsi
    movl (%r8, %rsi, 4), %eax
    movl %eax, (%r8, %r15, 4)
    movl %ebp, (%r8, %rsi, 4)
    addl $1, %r10d
    cmpl %r14d, %r10d
jl .LBB12
.LBB13:
    addl $1, %r13d
    jmp .LBB9
.LBB14:
    movslq %esi, %rdx
    movl (%r11, %rdx, 4), %eax
    movl %eax, (%r8, %rdx, 4)
    addl $1, %esi
    cmpl $11, %esi
jl .LBB14
    jmp .LBB8
.LBB15:
    movl 40(%rsp), %esi
    subl $1, %esi
    movslq %esi, %rsi
    leaq count(%rip), %rcx
    movslq 40(%rsp), %rax
    movl %eax, (%rcx, %rsi, 4)
    movq %rsi, 40(%rsp)
    movslq 40(%rsp), %rax
    cmpl $1, %eax
jg .LBB15
    jmp .LBB3
.LBB16:
    cmpl maxflips(%rip), %r13d
jle .LBB18
.LBB17:
    movl %r13d, maxflips(%rip)
.LBB18:
    movl 32(%rsp), %edi
    andl $1, %edi
    movl %r13d, %esi
    negl %esi
    testl %edi, %edi
    movq %r13, %rdx
    cmovnel %esi, %edx
    movslq checksum(%rip), %r10
    leal (%r10, %rdx), %eax
    movl %eax, checksum(%rip)
    movl 32(%rsp), %ebx
    addl $1, %ebx
    movq 40(%rsp), %rdi
.LBB19:
    cmpl $11, %edi
je .LBB26
.LBB20:
    movl (%r11), %r12d
    xorl %edx, %edx
    xorl %r13d, %r13d
.LBB21:
    cmpl %edi, %edx
jge .LBB23
.LBB22:
    addl $1, %edx
    movslq %edx, %r14
    movslq %edx, %rdx
    movl (%r11, %rdx, 4), %eax
    movl %eax, (%r11, %r13, 4)
    movq %r14, %r13
    cmpl %edi, %edx
jl .LBB22
.LBB23:
    movslq %edi, %r9
    movl %r12d, (%r11, %r9, 4)
    leaq count(%rip), %r10
    leaq (%r10, %r9, 4), %r10
    movl (%r10), %edx
    subl $1, %edx
    movl %edx, (%r10)
    testl %edx, %edx
jg .LBB25
.LBB24:
    addl $1, %edi
    cmpl $11, %edi
je .LBB26
    jmp .LBB20
.LBB25:
    movq %rdi, 40(%rsp)
    movq %rbx, 32(%rsp)
    jmp .LBB1
.LBB26:
    movslq checksum(%rip), %r11
    movslq maxflips(%rip), %r10
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    movl $11, %edx
    movq %r10, %rcx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    vzeroupper
    addq $56, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret



.LCPI0_0:
.LCPI0_1:
.LCPI0_2:
.LCPI0_3:
.LCPI0_4:
.LCPI0_5:
.LCPI0_6:
main:
  pushq %rbp
  pushq %r15
  pushq %r14
  pushq %r13
  pushq %r12
  pushq %rbx
  subq $152, %rsp
  vmovdqa .LCPI0_0(%rip), %ymm0
  vmovdqa %ymm0, perm1(%rip)
  movabsq $38654705672, %rax
  movq %rax, perm1+32(%rip)
  movl $10, perm1+40(%rip)
  movl $11, %r15d
  movq $0, 8(%rsp)
  leaq count(%rip), %r14
  vmovdqa .LCPI0_2(%rip), %ymm5
  vpbroadcastd .LCPI0_3(%rip), %ymm6
  vpbroadcastd .LCPI0_4(%rip), %ymm7
  vpbroadcastd .LCPI0_5(%rip), %ymm8
  vpbroadcastd .LCPI0_6(%rip), %ymm9
  leaq perm1(%rip), %r12
  leaq perm(%rip), %r13
  movl $0, (%rsp)
  movl $0, 4(%rsp)
  vmovdqu %ymm6, 112(%rsp)
  vmovdqu %ymm7, 80(%rsp)
  vmovdqu %ymm8, 48(%rsp)
  vmovdqu %ymm9, 16(%rsp)
.LBB0_1:
  cmpl $2, %r15d
  jl .LBB0_15
  movl %r15d, %eax
  cmpl $9, %r15d
  jae .LBB0_6
  movq %rax, %rsi
  jmp .LBB0_4
.LBB0_6:
  leaq -1(%rax), %rcx
  cmpl $33, %r15d
  jae .LBB0_8
  xorl %edx, %edx
  movq %rax, %rsi
  jmp .LBB0_12
.LBB0_8:
  movq %rcx, %rdx
  andq $-32, %rdx
  movq %rax, %rsi
  subq %rdx, %rsi
  vmovd %r15d, %xmm0
  vpbroadcastd %xmm0, %ymm0
  vpaddd .LCPI0_1(%rip), %ymm0, %ymm0
  movq %rdx, %rdi
  negq %rdi
  leaq (%r14,%rax,4), %r8
  addq $-32, %r8
  xorl %r9d, %r9d
.LBB0_9:
  vpermd %ymm0, %ymm5, %ymm1
  vpaddd %ymm6, %ymm1, %ymm2
  vpaddd %ymm7, %ymm1, %ymm3
  vpaddd %ymm1, %ymm8, %ymm4
  vmovdqu %ymm1, (%r8,%r9,4)
  vmovdqu %ymm2, -32(%r8,%r9,4)
  vmovdqu %ymm3, -64(%r8,%r9,4)
  vmovdqu %ymm4, -96(%r8,%r9,4)
  vpaddd %ymm0, %ymm9, %ymm0
  addq $-32, %r9
  cmpq %r9, %rdi
  jne .LBB0_9
  movl $1, %r15d
  cmpq %rdx, %rcx
  je .LBB0_15
  testb $24, %cl
  je .LBB0_4
.LBB0_12:
  movq %rcx, %rdi
  andq $-8, %rdi
  vmovd %esi, %xmm0
  vpbroadcastd %xmm0, %ymm0
  vpaddd .LCPI0_1(%rip), %ymm0, %ymm0
  movq %rdi, %rsi
  negq %rsi
  negq %rdx
  leaq (%r14,%rax,4), %r8
  addq $-32, %r8
  subq %rdi, %rax
.LBB0_13:
  vpermd %ymm0, %ymm5, %ymm1
  vmovdqu %ymm1, (%r8,%rdx,4)
  vpaddd %ymm6, %ymm0, %ymm0
  addq $-8, %rdx
  cmpq %rdx, %rsi
  jne .LBB0_13
  movl $1, %r15d
  movq %rax, %rsi
  cmpq %rdi, %rcx
  je .LBB0_15
.LBB0_4:
  movl %esi, -4(%r14,%rsi,4)
  cmpq $2, %rsi
  leaq -1(%rsi), %rsi
  ja .LBB0_4
  movl $1, %r15d
.LBB0_15:
  vmovaps perm1(%rip), %ymm0
  vmovups %ymm0, perm(%rip)
  vmovdqu perm1+12(%rip), %ymm0
  vmovdqu %ymm0, perm+12(%rip)
  movl perm(%rip), %ecx
  xorl %eax, %eax
  jmp .LBB0_16
.LBB0_24:
  movl perm(%rip), %ecx
.LBB0_25:
  incl %eax
.LBB0_16:
  testl %ecx, %ecx
  je .LBB0_26
  leal 1(%rcx), %esi
  sarl %esi
  testl %esi, %esi
  jle .LBB0_25
  movl %esi, %edi
  movl %edi, %edx
  andl $3, %edx
  cmpl $4, %esi
  jae .LBB0_28
  xorl %esi, %esi
  jmp .LBB0_22
.LBB0_28:
  leal -3(%rcx), %r8d
  leal -2(%rcx), %r9d
  leal -1(%rcx), %r10d
  movl %ecx, %r11d
  andl $2147483644, %edi
  negq %rdi
  xorl %esi, %esi
  leaq perm+12(%rip), %rbx
.LBB0_29:
  movl -12(%rbx), %ebp
  leal (%r11,%rsi), %r14d
  movslq %r14d, %r14
  movl (%r13,%r14,4), %r12d
  movl %r12d, -12(%rbx)
  movl %ebp, (%r13,%r14,4)
  movl -8(%rbx), %ebp
  leal (%r10,%rsi), %r14d
  movslq %r14d, %r14
  movl (%r13,%r14,4), %r12d
  movl %r12d, -8(%rbx)
  movl %ebp, (%r13,%r14,4)
  movl -4(%rbx), %ebp
  leal (%r9,%rsi), %r14d
  movslq %r14d, %r14
  movl (%r13,%r14,4), %r12d
  movl %r12d, -4(%rbx)
  movl %ebp, (%r13,%r14,4)
  movl (%rbx), %ebp
  leal (%r8,%rsi), %r14d
  movslq %r14d, %r14
  movl (%r13,%r14,4), %r12d
  movl %r12d, (%rbx)
  movl %ebp, (%r13,%r14,4)
  addq $16, %rbx
  addq $-4, %rsi
  cmpq %rsi, %rdi
  jne .LBB0_29
  testq %rdx, %rdx
  leaq count(%rip), %r14
  leaq perm1(%rip), %r12
  je .LBB0_24
  negq %rsi
.LBB0_22:
  subl %esi, %ecx
  shlq $2, %rsi
  xorl %edi, %edi
.LBB0_23:
  leaq (%rsi,%rdi,4), %r8
  movl (%r13,%r8), %r9d
  movslq %ecx, %rcx
  movl (%r13,%rcx,4), %r10d
  movl %r10d, (%r13,%r8)
  movl %r9d, (%r13,%rcx,4)
  incq %rdi
  decl %ecx
  cmpq %rdi, %rdx
  jne .LBB0_23
  jmp .LBB0_24
.LBB0_26:
  movl (%rsp), %ecx
  cmpl %ecx, %eax
  cmovgl %eax, %ecx
  movl %ecx, (%rsp)
  movl %eax, %ecx
  negl %ecx
  testb $1, 4(%rsp)
  cmovel %eax, %ecx
  movq 8(%rsp), %rax
  addl %ecx, %eax
  movq %rax, 8(%rsp)
  cmpl $11, %r15d
  je .LBB0_34
  incl 4(%rsp)
.LBB0_31:
  movl perm1(%rip), %ebx
  testl %r15d, %r15d
  jle .LBB0_33
  movl %r15d, %edx
  shlq $2, %rdx
  movq %r12, %rdi
  leaq perm1+4(%rip), %rsi
  vzeroupper
  callq memmove@PLT
  vmovdqu 16(%rsp), %ymm9
  vmovdqu 48(%rsp), %ymm8
  vmovdqu 80(%rsp), %ymm7
  vmovdqu 112(%rsp), %ymm6
  vmovdqa .LCPI0_2(%rip), %ymm5
.LBB0_33:
  movslq %r15d, %rax
  movl %ebx, (%r12,%rax,4)
  movl (%r14,%rax,4), %ecx
  decl %ecx
  movl %ecx, (%r14,%rax,4)
  testl %ecx, %ecx
  jg .LBB0_1
  incl %r15d
  cmpl $11, %r15d
  jne .LBB0_31
.LBB0_34:
  leaq .L.str(%rip), %rdi
  movq 8(%rsp), %rsi
  movl $11, %edx
  movl (%rsp), %ecx
  xorl %eax, %eax
  vzeroupper
  callq printf@PLT
  xorl %eax, %eax
  addq $152, %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  popq %rbp
  retq

.L.str:

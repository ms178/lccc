.LC2:
main:
  pushq %rbp
  xorl %r11d, %r11d
  movl $11, %r9d
  movabsq $38654705672, %rax
  movq %rsp, %rbp
  pushq %r13
  xorl %r13d, %r13d
  pushq %r12
  xorl %r12d, %r12d
  pushq %rbx
  xorl %ebx, %ebx
  subq $8, %rsp
  movq %rax, perm1+32(%rip)
  vmovdqa .LC0(%rip), %ymm0
  movl $0, maxflips(%rip)
  movl $0, checksum(%rip)
  movl $10, perm1+40(%rip)
  vmovdqa %ymm0, perm1(%rip)
.L2:
  cmpl $1, %r9d
  je .L12
.L3:
  leal -1(%r9), %eax
  movl %r9d, count(,%rax,4)
  decl %r9d
  cmpl $1, %r9d
  jne .L3
.L12:
  movq perm1+8(%rip), %rax
  movq perm1(%rip), %r8
  xorl %r10d, %r10d
  vmovdqu perm1+28(%rip), %xmm0
  movq %rax, perm+8(%rip)
  movq perm1+16(%rip), %rax
  movq %r8, perm(%rip)
  movq %rax, perm+16(%rip)
  movq perm1+24(%rip), %rax
  movq %rax, perm+24(%rip)
  vmovdqu %xmm0, perm+28(%rip)
  testl %r8d, %r8d
  je .L4
.L7:
  leal 1(%r8), %edi
  sarl %edi
  testl %edi, %edi
  jle .L5
  xorl %eax, %eax
.L6:
  movl %r8d, %edx
  movl perm(,%rax,4), %ecx
  subl %eax, %edx
  movslq %edx, %rdx
  movl perm(,%rdx,4), %esi
  movl %esi, perm(,%rax,4)
  incq %rax
  movl %ecx, perm(,%rdx,4)
  cmpq %rax, %rdi
  jne .L6
  movl perm(%rip), %r8d
.L5:
  incl %r10d
  testl %r8d, %r8d
  jne .L7
.L4:
  cmpl %ebx, %r10d
  jle .L8
  movl %r10d, %ebx
  movl $1, %r13d
.L8:
  movl %r10d, %eax
  negl %eax
  testb $1, %r12b
  cmovne %eax, %r10d
  addl %r10d, %r11d
.L22:
  movl perm1(%rip), %ecx
  testl %r9d, %r9d
  jle .L34
  movl %r9d, %edx
  leaq 0(,%rdx,4), %rax
  cmpl $32, %eax
  jb .L15
  movl %eax, %eax
  vmovdqu perm1+4(%rip), %ymm1
  vmovdqu perm1-28(%rax), %ymm0
  vmovdqu %ymm1, perm1(%rip)
  vmovdqu %ymm0, perm1-32(%rax)
.L14:
  movl count(,%rdx,4), %eax
  movl %ecx, perm1(,%rdx,4)
  decl %eax
  movl %eax, count(,%rdx,4)
  testl %eax, %eax
  jg .L35
  incl %r9d
  cmpl $11, %r9d
  jne .L22
  movl %r11d, checksum(%rip)
  testb %r13b, %r13b
  je .L26
  movl %ebx, maxflips(%rip)
.L23:
  movl %ebx, %ecx
  xorl %eax, %eax
  movl $11, %edx
  movl %r11d, %esi
  movl $.LC2, %edi
  vzeroupper
  call printf
  addq $8, %rsp
  xorl %eax, %eax
  popq %rbx
  popq %r12
  popq %r13
  popq %rbp
  ret
.L15:
  cmpl $16, %eax
  jnb .L16
  cmpl $8, %eax
  jb .L36
  movl %eax, %eax
  movq perm1+4(%rip), %rdi
  movq perm1-4(%rax), %rsi
  movq %rdi, perm1(%rip)
  movq %rsi, perm1-8(%rax)
  jmp .L14
.L16:
  movl %eax, %eax
  vmovdqu perm1+4(%rip), %xmm1
  vmovdqu perm1-12(%rax), %xmm0
  vmovdqu %xmm1, perm1(%rip)
  vmovdqu %xmm0, perm1-16(%rax)
  jmp .L14
.L36:
  movl %eax, %eax
  movl perm1+4(%rip), %edi
  movl perm1(%rax), %esi
  movl %edi, perm1(%rip)
  movl %esi, perm1-4(%rax)
  jmp .L14
.L34:
  movslq %r9d, %rdx
  movl count(,%rdx,4), %eax
  movl %ecx, perm1(,%rdx,4)
  decl %eax
  movl %eax, count(,%rdx,4)
  testl %eax, %eax
  jg .L37
  incl %r9d
  jmp .L22
.L35:
  incl %r12d
  jmp .L2
.L26:
  xorl %ebx, %ebx
  jmp .L23
.L37:
  incl %r12d
  jmp .L12
.LC0:

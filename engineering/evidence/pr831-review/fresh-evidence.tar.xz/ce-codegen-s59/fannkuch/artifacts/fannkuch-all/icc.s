main:
..B1.1: # Preds ..B1.0
  pushq %rbp #52.16
  movq %rsp, %rbp #52.16
  andq $-128, %rsp #52.16
  pushq %r12 #52.16
  pushq %r13 #52.16
  pushq %r14 #52.16
  pushq %r15 #52.16
  pushq %rbx #52.16
  subq $88, %rsp #52.16
  movl $3, %edi #52.16
  movl $10330110, %esi #52.16
  call __intel_new_feature_proc_init #52.16
..B1.50: # Preds ..B1.1
  vstmxcsr (%rsp) #52.16
  vmovdqu .L_2il0floatpacket.0(%rip), %ymm0 #14.33
  xorl %ecx, %ecx #11.5
  movl $11, %edx #16.13
  movq %rdx, %r13 #47.13
  orl $32832, (%rsp) #52.16
  vmovdqu %ymm0, perm1(%rip) #14.33
  movl %ecx, %r14d #47.13
  vldmxcsr (%rsp) #52.16
  movl $8, 32+perm1(%rip) #14.33
  movl %ecx, %r15d #47.13
  movl $9, 36+perm1(%rip) #14.33
  movl %ecx, %r12d #47.13
  movl $10, 40+perm1(%rip) #14.33
  vmovdqu .L_2il0floatpacket.1(%rip), %ymm0 #47.13
..B1.2: # Preds ..B1.32 ..B1.50
  movl %r13d, %esi #20.9
  cmpl $1, %esi #20.20
  jle ..B1.11 # Prob 50% #20.20
..B1.3: # Preds ..B1.2
  vmovdqu perm1(%rip), %ymm2 #22.47
  lea -1(%rsi), %ebx #20.9
  movl 32+perm1(%rip), %eax #22.47
  movl 36+perm1(%rip), %ecx #22.47
  movl 40+perm1(%rip), %edi #22.47
  cmpl $16, %ebx #20.9
  jl ..B1.34 # Prob 10% #20.9
..B1.4: # Preds ..B1.3
  movl %ebx, %edx #20.9
  lea -7(%rsi), %r10d #47.13
  movslq %ebx, %rbx #20.25
  lea -15(%rsi), %r8d #47.13
  andl $-16, %edx #20.9
  vmovd %r10d, %xmm1 #47.13
  xorl %r10d, %r10d #20.9
  vmovd %r8d, %xmm3 #47.13
  lea count(,%rbx,4), %r9 #20.25
  vpbroadcastd %xmm1, %ymm0 #47.13
  lea -28(%r9), %r8 #20.25
  vpbroadcastd %xmm3, %ymm4 #47.13
  vpaddd .L_2il0floatpacket.2(%rip), %ymm0, %ymm1 #47.13
  vpaddd .L_2il0floatpacket.2(%rip), %ymm4, %ymm0 #47.13
  vmovdqu .L_2il0floatpacket.1(%rip), %ymm3 #20.25
..B1.5: # Preds ..B1.5 ..B1.4
  addl $16, %r10d #20.9
  vmovdqu %ymm1, (%r8) #20.25
  addq $-64, %r8 #20.9
  vmovdqu %ymm0, -60(%r9) #20.25
  vpaddd %ymm3, %ymm1, %ymm1 #47.13
  vpaddd %ymm3, %ymm0, %ymm0 #47.13
  addq $-64, %r9 #20.9
  cmpl %edx, %r10d #20.9
  jb ..B1.5 # Prob 93% #20.9
..B1.6: # Preds ..B1.5
  movl %esi, %r13d #20.9
  subl %edx, %r13d #20.9
  movslq %r13d, %r13 #20.43
..B1.7: # Preds ..B1.6 ..B1.34
  cmpl %ebx, %edx #20.9
  jae ..B1.12 # Prob 10% #20.9
..B1.9: # Preds ..B1.7 ..B1.9
  movl %esi, %r9d #47.13
  subl %edx, %r9d #47.13
  incl %edx #20.9
  lea -1(%r9), %r8d #20.25
  movslq %r8d, %r8 #20.25
  movl %r9d, count(,%r8,4) #20.25
  cmpl %ebx, %edx #20.9
  jb ..B1.9 # Prob 93% #20.9
..B1.10: # Preds ..B1.9
  subl %edx, %esi #47.13
  movslq %esi, %r13 #20.43
  jmp ..B1.12 # Prob 100% #20.43
..B1.11: # Preds ..B1.2
  vmovdqu perm1(%rip), %ymm2 #22.47
  movl 32+perm1(%rip), %eax #22.47
  movl 36+perm1(%rip), %ecx #22.47
  movl 40+perm1(%rip), %edi #22.47
..B1.12: # Preds ..B1.10 ..B1.7 ..B1.11
  vmovdqu %ymm2, perm(%rip) #22.37
  xorl %r9d, %r9d #24.19
  movl perm(%rip), %r8d #26.21
  movl %eax, 32+perm(%rip) #22.37
  movl %ecx, 36+perm(%rip) #22.37
  movl %edi, 40+perm(%rip) #22.37
  testl %r8d, %r8d #26.33
  je ..B1.26 # Prob 10% #26.33
..B1.13: # Preds ..B1.12
  movl $1, %r9d #26.9
  lea 1(%r8), %ebx #27.27
  sarl $1, %ebx #27.33
  testl %ebx, %ebx #28.33
  jle ..B1.47 # Prob 10% #28.33
..B1.14: # Preds ..B1.13
  lea 1(%r8), %ebx #27.27
  sarl $1, %ebx #27.33
..B1.15: # Preds ..B1.23 ..B1.14
  movl %ebx, %ecx #28.13
  movl %r8d, %esi #29.25
  movl $1, %r10d #28.13
  xorl %edi, %edi #28.13
  shrl $1, %ecx #28.13
  je ..B1.19 # Prob 0% #28.13
..B1.17: # Preds ..B1.15 ..B1.17
  movslq %esi, %rsi #30.27
  lea (%rdi,%rdi), %r10d #29.25
  movslq %r10d, %r10 #29.25
  lea 1(%rdi,%rdi), %edx #29.25
  movslq %edx, %rdx #29.25
  incl %edi #28.13
  movl perm(,%rsi,4), %r11d #30.27
  movl perm(,%r10,4), %eax #29.25
  movl %r11d, perm(,%r10,4) #30.17
  lea -1(%rsi), %r11d #30.27
  movslq %r11d, %r11 #30.27
  movl %eax, perm(,%rsi,4) #31.17
  addl $-2, %esi #28.13
  movl perm(,%rdx,4), %eax #29.25
  movl perm(,%r11,4), %r10d #30.27
  movl %r10d, perm(,%rdx,4) #30.17
  movl %eax, perm(,%r11,4) #31.17
  cmpl %ecx, %edi #28.13
  jb ..B1.17 # Prob 87% #28.13
..B1.18: # Preds ..B1.17
  lea 1(%rdi,%rdi), %r10d #29.25
..B1.19: # Preds ..B1.18 ..B1.15
  lea -1(%r10), %edi #28.13
  cmpl %ebx, %edi #28.13
  jae ..B1.21 # Prob 0% #28.13
..B1.20: # Preds ..B1.19
  subl %r10d, %r8d #30.27
  incl %r8d #28.13
  movslq %r8d, %r8 #30.27
  movslq %edi, %rdi #29.25
  movl perm(,%r8,4), %r10d #30.27
  movl perm(,%rdi,4), %ebx #29.25
  movl %r10d, perm(,%rdi,4) #30.17
  movl %ebx, perm(,%r8,4) #31.17
..B1.21: # Preds ..B1.19 ..B1.20
  movl perm(%rip), %r8d #26.21
..B1.22: # Preds ..B1.21 ..B1.23
  testl %r8d, %r8d #26.33
  je ..B1.26 # Prob 18% #26.33
..B1.23: # Preds ..B1.47 ..B1.22
  incl %r9d #26.9
  lea 1(%r8), %ebx #27.27
  sarl $1, %ebx #27.33
  testl %ebx, %ebx #28.33
  jle ..B1.22 # Prob 10% #28.33
  jmp ..B1.15 # Prob 100% #28.33
..B1.26: # Preds ..B1.22 ..B1.12
  cmpl %r15d, %r9d #36.9
  movl %r9d, %ebx #37.36
  cmovg %r9d, %r15d #36.9
  negl %ebx #37.36
  testl $1, %r14d #37.30
  movl %r15d, maxflips(%rip) #36.31
  cmovne %ebx, %r9d #37.9
  incl %r14d #38.9
  addl %r9d, %r12d #37.9
  movl %r12d, checksum(%rip) #37.9
  jmp ..B1.27 # Prob 100% #37.9
..B1.33: # Preds ..B1.32
  incq %r13 #47.13
..B1.27: # Preds ..B1.33 ..B1.26
  cmpq $11, %r13 #41.22
  je ..B1.45 # Prob 6% #41.22
..B1.28: # Preds ..B1.27
  movl perm1(%rip), %ebx #42.22
  testq %r13, %r13 #43.33
  jle ..B1.32 # Prob 50% #43.33
..B1.29: # Preds ..B1.28
  movl %r13d, %eax #43.13
  cmpq $24, %r13 #43.13
  jle ..B1.36 # Prob 10% #43.13
..B1.30: # Preds ..B1.29
  xorl %r9d, %r9d #43.13
  lea (,%rax,4), %edi #43.13
  cmpl $-4, %edi #43.13
  setl %r9b #43.13
  xorl %r8d, %r8d #43.13
  cmpl $4, %edi #43.13
  setl %r8b #43.13
  orl %r8d, %r9d #43.13
  je ..B1.36 # Prob 10% #43.13
..B1.31: # Preds ..B1.30
  movl $perm1, %edi #43.13
  lea (,%r13,4), %rdx #43.13
  movl $perm1+4, %esi #43.13
  vzeroupper #43.13
  call __intel_avx_rep_memcpy #43.13
..B1.32: # Preds ..B1.42 ..B1.40 ..B1.31 ..B1.28
  movl %ebx, perm1(,%r13,4) #44.13
  movl count(,%r13,4), %ebx #45.13
  decl %ebx #45.13
  movl %ebx, count(,%r13,4) #45.13
  testl %ebx, %ebx #46.28
  jg ..B1.2 # Prob 20% #46.28
  jmp ..B1.33 # Prob 100% #46.28
..B1.34: # Preds ..B1.3
  xorl %edx, %edx #20.9
  jmp ..B1.7 # Prob 100% #20.9
..B1.36: # Preds ..B1.29 ..B1.30
  cmpl $8, %eax #43.13
  jl ..B1.44 # Prob 10% #43.13
..B1.37: # Preds ..B1.36
  movl %eax, %r9d #43.13
  xorl %r8d, %r8d #43.13
  andl $-8, %r9d #43.13
  movl $1, %edi #43.41
..B1.38: # Preds ..B1.38 ..B1.37
  vmovdqu perm1(,%rdi,4), %ymm0 #43.52
  addl $8, %r8d #43.13
  vmovdqu %ymm0, -4+perm1(,%rdi,4) #43.41
  addq $8, %rdi #43.13
  cmpl %r9d, %r8d #43.13
  jb ..B1.38 # Prob 93% #43.13
..B1.40: # Preds ..B1.38 ..B1.44
  movslq %r9d, %rdi #43.13
  cmpl %eax, %r9d #43.13
  jae ..B1.32 # Prob 10% #43.13
..B1.42: # Preds ..B1.40 ..B1.42
  incl %r9d #43.52
  lea 1(%rdi), %r10 #43.52
  movl perm1(,%r10,4), %r8d #43.52
  movl %r8d, perm1(,%rdi,4) #43.41
  movq %r10, %rdi #43.13
  cmpl %eax, %r9d #43.13
  jb ..B1.42 # Prob 93% #43.13
  jmp ..B1.32 # Prob 100% #43.13
..B1.44: # Preds ..B1.36
  xorl %r9d, %r9d #43.13
  jmp ..B1.40 # Prob 100% #43.13
..B1.45: # Preds ..B1.27
  movl %r12d, %esi #
  movl %r15d, %ecx #
  movl $.L_2__STRING.0, %edi #55.5
  movl $11, %edx #55.5
  xorl %eax, %eax #55.5
  vzeroupper #55.5
  call printf #55.5
..B1.46: # Preds ..B1.45
  xorl %eax, %eax #56.12
  addq $88, %rsp #56.12
  popq %rbx #56.12
  popq %r15 #56.12
  popq %r14 #56.12
  popq %r13 #56.12
  popq %r12 #56.12
  movq %rbp, %rsp #56.12
  popq %rbp #56.12
  ret #56.12
..B1.47: # Preds ..B1.13
  movl $4, %r9d #26.9
  jmp ..B1.23 # Prob 100% #26.9
perm1:
count:
perm:
maxflips:
checksum:
.L_2il0floatpacket.0:
.L_2il0floatpacket.1:
.L_2il0floatpacket.2:
.L_2__STRING.0:

.section .rodata
.Lstr0:
    .byte 37, 100, 10, 80, 102, 97, 110, 110, 107, 117, 99, 104, 101, 110, 40, 37, 100, 41, 32, 61, 32, 37, 100, 10, 0

.section .bss
.align 16
.type perm, @object
.size perm, 64
perm:
    .zero 64
.align 16
.type perm1, @object
.size perm1, 64
perm1:
    .zero 64
.align 16
.type count, @object
.size count, 64
count:
    .zero 64
.align 4
.type maxflips, @object
.size maxflips, 4
maxflips:
    .zero 4
.align 4
.type checksum, @object
.size checksum, 4
checksum:
    .zero 4

.text
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $40, %rsp
    .cfi_def_cfa_offset 96
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movl $0, maxflips(%rip)
    movl $0, checksum(%rip)
    leaq perm1(%rip), %r11
    movl $0, (%r11)
    movl $1, perm1+4(%rip)
    movl $2, perm1+8(%rip)
    movl $3, perm1+12(%rip)
    movl $4, perm1+16(%rip)
    movl $5, perm1+20(%rip)
    movl $6, perm1+24(%rip)
    movl $7, perm1+28(%rip)
    movl $8, perm1+32(%rip)
    movl $9, perm1+36(%rip)
    movl $10, perm1+40(%rip)
    leaq perm(%rip), %r8
    movl $11, %r12d
    movq $0, 24(%rsp)
.p2align 5,,15
.p2align 4
.LBB1:
.LBB2:
    cmpl $1, %r12d
jg .LBB15
.LBB3:
    xorl %edi, %edi
.LBB4:
    cmpq $32, %rdi
jge .LBB6
.p2align 5,,15
.p2align 4
.LBB5:
    vmovdqu (%r11,%rdi), %ymm2
    vmovdqu %ymm2, (%r8,%rdi)
    addq $32, %rdi
    cmpq $32, %rdi
jl .LBB5
.LBB6:
    shrq $2, %rdi
    movslq %edi, %rdx
.LBB7:
    cmpq $11, %rdx
jl .LBB14
.LBB8:
    xorl %r14d, %r14d
.LBB9:
    movl (%r8), %esi
    testl %esi, %esi
je .LBB16
.LBB10:
    leal 1(%rsi), %r15d
    sarl $1, %r15d
    xorl %r10d, %r10d
.LBB11:
    cmpl %r15d, %r10d
jge .LBB13
.p2align 4,,10
.p2align 3
.LBB12:
    movl (%r8, %r10, 4), %ebp
    movl %esi, %r9d
    subl %r10d, %r9d
    movslq %r9d, %r9
    movl (%r8, %r9, 4), %eax
    movl %eax, (%r8, %r10, 4)
    movl %ebp, (%r8, %r9, 4)
    addl $1, %r10d
    cmpl %r15d, %r10d
jl .LBB12
.LBB13:
    addl $1, %r14d
    jmp .LBB9
.p2align 4,,10
.p2align 3
.LBB14:
    movl (%r11, %rdx, 4), %eax
    movl %eax, (%r8, %rdx, 4)
    addq $1, %rdx
    cmpq $11, %rdx
jl .LBB14
    jmp .LBB8
.p2align 4,,10
.p2align 3
.LBB15:
    leal -1(%r12), %esi
    movslq %esi, %rsi
    leaq count(%rip), %rcx
    movl %r12d, (%rcx, %rsi, 4)
    movq %rsi, %r12
    cmpl $1, %esi
jg .LBB15
    jmp .LBB3
.LBB16:
    cmpl maxflips(%rip), %r14d
jle .LBB18
.LBB17:
    movl %r14d, maxflips(%rip)
.LBB18:
    movl 24(%rsp), %edi
    andl $1, %edi
    movl %r14d, %esi
    negl %esi
    testl %edi, %edi
    movq %r14, %rdx
    cmovnel %esi, %edx
    movslq checksum(%rip), %r10
    leal (%r10, %rdx), %eax
    movl %eax, checksum(%rip)
    movl 24(%rsp), %eax
    addl $1, %eax
    movq %rax, 24(%rsp)
    movslq %r12d, %rdi
    shlq $2, %rdi
    leaq perm1(%rip), %rcx
    leaq (%rcx, %rdi), %r13
    leaq count(%rip), %r14
    addq %rdi, %r14
.LBB19:
    cmpl $11, %r12d
je .LBB26
.p2align 4,,10
.p2align 3
.LBB20:
    movl (%r11), %r15d
    movslq %r12d, %rbp
    xorl %edi, %edi
.LBB21:
    cmpq %rbp, %rdi
jge .LBB23
.p2align 4,,10
.p2align 3
.LBB22:
    leaq 1(%rdi), %rdx
    movl (%r11, %rdx, 4), %eax
    movl %eax, (%r11, %rdi, 4)
    movq %rdx, %rdi
    cmpq %rbp, %rdx
jl .LBB22
.LBB23:
    movl %r15d, (%r13)
    movl (%r14), %esi
    subl $1, %esi
    movl %esi, (%r14)
    testl %esi, %esi
    jg .LBB1
.LBB24:
    leal 1(%r12), %eax
    leaq 4(%r13), %r13
    leaq 4(%r14), %r14
    movl %eax, %r12d
    cmpl $11, %eax
je .LBB26
    jmp .LBB20
.LBB25:
    jmp .LBB1
.LBB26:
    movslq checksum(%rip), %r11
    movslq maxflips(%rip), %r10
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    movl $11, %edx
    movq %r10, %rcx
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 4
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    vzeroupper
    addq $40, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

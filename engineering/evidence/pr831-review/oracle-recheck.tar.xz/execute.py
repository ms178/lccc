import hashlib, json, os, sys, time
from pathlib import Path
root = Path('/home/user/lccc').resolve()
sys.path.insert(0, str(root / 'scripts'))
import godbolt
out = Path(__file__).resolve().parent
flags = '-O2 -march=haswell -fwrapv'
version = '''#include <stdio.h>
#ifndef __INTEL_LLVM_COMPILER
#define __INTEL_LLVM_COMPILER 0
#endif
#ifndef __INTEL_COMPILER
#define __INTEL_COMPILER 0
#endif
int main(void) { printf("version=%s;intel_classic=%d;intel_llvm=%d\\n", __VERSION__, __INTEL_COMPILER, __INTEL_LLVM_COMPILER); return 0; }
'''
wrap = '#define main original_main\n' + (root/'tests/regression/wrapv_domains.c').read_text() + '''
#undef main
int main(void) { char arg[] = "0"; char *argv[] = {"probe", arg, 0}; for (int i=0;i<4;++i) { arg[0]='0'+i; int rc=original_main(2, argv); if(rc) return rc; } return 0; }
'''
cases = {'version': version, 'signed_rotation': (root/'tests/regression/rotation_signed_wrap.c').read_text(), 'wrapv_domains': wrap, 'strict_fenv': (root/'tests/regression/fenv_rounding_freestanding.c').read_text()}
report = {'complete': False, 'cache': os.environ['GODBOLT_CACHE'], 'metric':'semantic execution, not performance', 'records': []}
def save():
    tmp=out/'execution.tmp';tmp.write_text(json.dumps(report,indent=2)+'\n');tmp.replace(out/'execution.json')
def stream(rows): return '\n'.join(r.get('text','') if isinstance(r,dict) else str(r) for r in rows or [])
try:
    for case, source in cases.items():
        (out/(case+'.c')).write_text(source)
        for compiler in ['gcc16.2','clang','icc','icx']:
            use_flags = flags
            if case == 'strict_fenv':
                use_flags += ' -fp-model strict' if compiler in ['icc','icx'] else ' -frounding-math -ffp-contract=off'
            row={'case':case,'compiler':compiler,'id':godbolt.resolve_compiler(compiler),'flags':use_flags,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'started_ns':time.time_ns()}
            try:
                data=godbolt.compile_on_godbolt(compiler,source,use_flags,execute=True,raise_on_error=True)
                (out/(case+'-'+compiler+'.json')).write_text(json.dumps(data,indent=2)+'\n')
                ex=data.get('execResult') or {}
                row.update(code=ex.get('code'),stdout=stream(ex.get('stdout')),stderr=stream(ex.get('stderr')))
                row['observed_exit_zero']=row['code']==0
                if case=='wrapv_domains':row['expected_output_match']=row['stdout'].strip()=='28\n-1073665362\n1\n10'
            except Exception as exc:
                row['error']=str(exc)
            report['records'].append(row);save();print(json.dumps(row),flush=True)
    report['complete']=all('error' not in r and r.get('code') is not None for r in report['records']) and len(report['records'])==16
finally:
    save()

main:
..B1.1: # Preds ..B1.0
  pushq %rbp #152.1
  movq %rsp, %rbp #152.1
  andq $-128, %rsp #152.1
  subq $128, %rsp #152.1
  movl $3, %edi #152.1
  movl $10330110, %esi #152.1
  call __intel_new_feature_proc_init #152.1
..B1.115: # Preds ..B1.1
  vstmxcsr (%rsp) #152.1
  xorl %esi, %esi #154.16
  movl $-1843407944, %edx #137.5
  orl $32832, (%rsp) #152.1
  xorl %eax, %eax #136.8
  vldmxcsr (%rsp) #152.1
..B1.2: # Preds ..B1.5 ..B1.4 ..B1.115
  movl %edx, %ecx #146.35
  shrl $24, %ecx #146.35
  movb %cl, src_data(%rax) #146.7
  movl %eax, %ecx #136.29
  jmp ..B1.3 # Prob 100% #136.29
..B1.6: # Preds ..B1.5
  movl %edx, %edi #144.49
  andl $63, %edi #144.49
  lea -128(%rcx,%rdi), %r8d #144.49
  movb src_data(%r8), %r9b #144.21
  movb %r9b, src_data(%rax) #144.7
..B1.3: # Preds ..B1.2 ..B1.6
  incl %ecx #136.29
  movl %ecx, %eax #136.29
  cmpq $524288, %rax #136.19
  jae ..B1.9 # Prob 18% #136.19
..B1.4: # Preds ..B1.3
  imull $1664525, %edx, %edx #137.21
  addl $1013904223, %edx #137.32
  movl %edx, %edi #143.18
  andl $15, %edi #143.18
  cmpl $6, %edi #143.27
  jae ..B1.2 # Prob 50% #143.27
..B1.5: # Preds ..B1.4
  cmpl $128, %ecx #143.37
  jae ..B1.6 # Prob 50% #143.37
  jmp ..B1.2 # Prob 100% #143.37
..B1.9: # Preds ..B1.3
  xorb %dl, %dl #158.8
  xorl %eax, %eax #158.15
  movl $src_data+524288, %r11d #56.26
  vpcmpeqd %ymm1, %ymm1, %ymm1 #92.36
  movl $src_data+524276, %r10d #57.36
  movq %r12, (%rsp) #62.3[spill]
  movq %r13, 8(%rsp) #62.3[spill]
  movq %r14, 16(%rsp) #62.3[spill]
  movq %r15, 24(%rsp) #62.3[spill]
  movb %dl, %r12b #62.3
  movq %rbx, 32(%rsp) #62.3[spill]
  movl %eax, %ebx #62.3
  vpcmpeqd %xmm0, %xmm0, %xmm0 #92.36
  movq %rsi, %r15 #62.3
  movl $src_data+1, %r8d #62.3
..B1.10: # Preds ..B1.69 ..B1.9
  movl $src_data, %r9d #58.22
  movl $hash_table, %edi #62.3
  xorl %esi, %esi #62.3
  movl $65536, %edx #62.3
  movq %r9, 96(%rsp) #62.3[spill]
  movl $dst_data, %r14d #59.12
  vzeroupper #62.3
  call __intel_avx_rep_memset #62.3
..B1.11: # Preds ..B1.10
  movl $src_data+1, %r8d #
  movl $src_data+524276, %ecx #69.15
  movq 96(%rsp), %r9 #[spill]
  movq %r8, %rax #68.3
  cmpq %rcx, %r8 #69.15
  jae ..B1.54 # Prob 10% #69.15
..B1.12: # Preds ..B1.11
  movl %ebx, 72(%rsp) #[spill]
  movq %r14, %rdi #
  movb %r12b, 80(%rsp) #[spill]
  movq %rax, %r14 #
  movq %r15, 88(%rsp) #[spill]
..B1.13: # Preds ..B1.52 ..B1.12
  movl (%r14), %edx #42.3
..B1.14: # Preds ..B1.13
  imull $-1640531535, %edx, %edx #49.17
  movq %r14, %rbx #72.27
  shrl $18, %edx #49.33
  movl $src_data, %ecx #72.27
  movl hash_table(,%rdx,4), %r15d #71.27
  subq %rcx, %rbx #72.27
  movl %ebx, hash_table(,%rdx,4) #72.5
  lea src_data(%r15), %r15 #71.21
  cmpq %r14, %r15 #74.15
  jae ..B1.51 # Prob 50% #74.15
..B1.15: # Preds ..B1.14
  movl $src_data, %edx #74.28
  cmpq %rdx, %r15 #74.28
  jb ..B1.51 # Prob 78% #74.28
..B1.16: # Preds ..B1.15
  movl (%r15), %edx #42.3
..B1.17: # Preds ..B1.16
  movl (%r14), %ecx #42.3
..B1.18: # Preds ..B1.17
  cmpl %ecx, %edx #74.50
  jne ..B1.51 # Prob 50% #74.50
..B1.19: # Preds ..B1.18
  movq %r14, %r8 #76.45
  addq $4, %r14 #78.7
  movl $src_data+524288, %edx #80.19
  subq %r9, %r8 #76.45
  movl %r8d, %r13d #76.50
  lea 4(%r15), %rbx #77.25
  cmpq %rdx, %r14 #80.19
  jae ..B1.24 # Prob 10% #80.19
..B1.20: # Preds ..B1.19
  movl $src_data+524288, %ecx #
..B1.21: # Preds ..B1.22 ..B1.20
  movb (%r14), %dl #80.28
  cmpb (%rbx), %dl #80.35
  jne ..B1.24 # Prob 20% #80.35
..B1.22: # Preds ..B1.21
  incq %r14 #81.9
  incq %rbx #82.9
  cmpq %rcx, %r14 #80.19
  jb ..B1.21 # Prob 82% #80.19
..B1.24: # Preds ..B1.21 ..B1.22 ..B1.19
  negq %r15 #85.47
  lea 1(%rdi), %r12 #86.19
  addq %rbx, %r15 #85.47
  movq %r12, %rcx #86.19
  addq $-4, %r15 #85.61
  movq %rdi, 64(%rsp) #86.19[spill]
  cmpl $15, %r13d #89.22
  jb ..B1.31 # Prob 50% #89.22
..B1.25: # Preds ..B1.24
  movb $240, (%rdi) #90.10
  lea -15(%r13), %r11d #91.36
  cmpl $255, %r11d #92.21
  jb ..B1.29 # Prob 10% #92.21
..B1.26: # Preds ..B1.25
  movq $0x8080808080808081, %rax #92.9
  movq %r11, %r10 #92.9
  negq %r10 #92.9
  imulq %r10 #92.9
  subq %r11, %rdx #92.9
  shrq $7, %rdx #92.9
  sarq $63, %r10 #92.9
  negq %rdx #92.9
  addq %r10, %rdx #92.9
  movl %edx, %r10d #92.9
  cmpl $96, %r10d #92.9
  jle ..B1.76 # Prob 0% #92.9
..B1.27: # Preds ..B1.26
  movslq %edx, %rdx #92.9
  movq %r12, %rdi #92.9
  movl $255, %esi #92.9
  movl %r10d, 40(%rsp) #92.9[spill]
  movq %rcx, 48(%rsp) #92.9[spill]
  movq %r8, 56(%rsp) #92.9[spill]
  movq %r9, 96(%rsp) #92.9[spill]
  vzeroupper #92.9
  call __intel_avx_rep_memset #92.9
..B1.117: # Preds ..B1.27
  movq 96(%rsp), %r9 #[spill]
  movq 56(%rsp), %r8 #[spill]
  movq 48(%rsp), %rcx #[spill]
  movl 40(%rsp), %r10d #[spill]
..B1.28: # Preds ..B1.87 ..B1.80 ..B1.85 ..B1.117
  movl %r10d, %edx #92.29
  shll $8, %edx #92.29
  negl %edx #92.29
  addl %r10d, %edx #92.29
  decl %r10d #92.29
  movslq %r10d, %r10 #92.29
  lea -15(%r13,%rdx), %r11d #92.29
  lea 1(%rcx,%r10), %r12 #92.29
..B1.29: # Preds ..B1.28 ..B1.25
  movb %r11b, (%r12) #93.10
  incq %r12 #93.10
  cmpl $96, %r13d #97.7
  jbe ..B1.72 # Prob 0% #97.7
..B1.30: # Preds ..B1.29
  movl %r8d, %edx #97.7
  movq %r12, %rdi #97.7
  movq %r9, %rsi #97.7
  vzeroupper #97.7
  call __intel_avx_rep_memcpy #97.7
  jmp ..B1.42 # Prob 100% #97.7
..B1.31: # Preds ..B1.24
  movl %r13d, %edx #95.34
  shll $4, %edx #95.34
  movb %dl, (%rdi) #95.10
  testl %r13d, %r13d #97.23
  jbe ..B1.43 # Prob 50% #97.23
..B1.32: # Preds ..B1.31 ..B1.72
  xorl %edx, %edx #97.7
..B1.33: # Preds ..B1.74 ..B1.32
  lea 1(%rdx), %ecx #97.7
  cmpl %r13d, %ecx #97.7
  ja ..B1.42 # Prob 50% #97.7
..B1.34: # Preds ..B1.33
  movl %r13d, %eax #97.7
  subl %edx, %eax #97.7
  cmpl $8, %eax #97.7
  jb ..B1.106 # Prob 10% #97.7
..B1.35: # Preds ..B1.34
  movl %eax, %ecx #97.7
  xorl %r8d, %r8d #97.7
  andl $-8, %ecx #97.7
..B1.36: # Preds ..B1.36 ..B1.35
  lea (%rdx,%r8), %r10d #98.10
  addl $8, %r8d #97.7
  vmovq (%r10,%r9), %xmm0 #98.17
  movslq %r10d, %r10 #98.10
  vmovq %xmm0, (%r10,%r12) #98.10
  cmpl %ecx, %r8d #97.7
  jb ..B1.36 # Prob 82% #97.7
..B1.38: # Preds ..B1.36 ..B1.106
  cmpl %eax, %ecx #97.7
  jae ..B1.42 # Prob 9% #97.7
..B1.40: # Preds ..B1.38 ..B1.40
  lea (%rdx,%rcx), %r8d #98.10
  incl %ecx #97.7
  movslq %r8d, %r11 #98.10
  movb (%r8,%r9), %r10b #98.17
  movb %r10b, (%r11,%r12) #98.10
  cmpl %eax, %ecx #97.7
  jb ..B1.40 # Prob 82% #97.7
..B1.42: # Preds ..B1.40 ..B1.38 ..B1.33 ..B1.30
  decl %r13d #98.10
  movslq %r13d, %r13 #98.10
  lea 1(%r12,%r13), %r12 #98.10
..B1.43: # Preds ..B1.42 ..B1.31
  negq %rbx #101.26
  lea 2(%r12), %rdi #103.8
  addq %r14, %rbx #101.26
  movb %bl, -2(%rdi) #102.8
  shrl $8, %ebx #103.30
  movb %bl, -1(%rdi) #103.8
  cmpl $15, %r15d #106.24
  jb ..B1.49 # Prob 50% #106.24
..B1.44: # Preds ..B1.43
  movq 64(%rsp), %rdx #107.10[spill]
  lea -15(%r15), %ecx #108.38
  orb $15, (%rdx) #107.10
  cmpl $255, %ecx #109.21
  jb ..B1.48 # Prob 10% #109.21
..B1.45: # Preds ..B1.44
  movq $0x8080808080808081, %rax #109.9
  movq %rcx, %rbx #109.9
  negq %rbx #109.9
  imulq %rbx #109.9
  subq %rcx, %rdx #109.9
  shrq $7, %rdx #109.9
  sarq $63, %rbx #109.9
  negq %rdx #109.9
  addq %rbx, %rdx #109.9
  movl %edx, %ebx #109.9
  cmpl $96, %ebx #109.9
  jle ..B1.91 # Prob 0% #109.9
..B1.46: # Preds ..B1.45
  movslq %edx, %rdx #109.9
  movl $255, %esi #109.9
  vzeroupper #109.9
  call __intel_avx_rep_memset #109.9
..B1.47: # Preds ..B1.102 ..B1.46 ..B1.95 ..B1.100
  movl %ebx, %edx #109.29
  shll $8, %edx #109.29
  negl %edx #109.29
  addl %ebx, %edx #109.29
  incl %ebx #109.29
  movslq %ebx, %rbx #109.29
  lea -15(%r15,%rdx), %ecx #109.29
  lea 1(%r12,%rbx), %rdi #109.29
..B1.48: # Preds ..B1.47 ..B1.44
  movb %cl, (%rdi) #110.10
  incq %rdi #110.10
  jmp ..B1.50 # Prob 100% #110.10
..B1.49: # Preds ..B1.43
  movq 64(%rsp), %rdx #112.10[spill]
  orb %r15b, (%rdx) #112.10
..B1.50: # Preds ..B1.48 ..B1.49
  movq %r14, %r9 #115.7
  jmp ..B1.52 # Prob 100% #115.7
..B1.51: # Preds ..B1.14 ..B1.15 ..B1.18
  movq %r14, %rdx #117.19
  subq %r9, %rdx #117.19
  sarq $6, %rdx #117.35
  lea 1(%r14,%rdx), %r14 #117.7
..B1.52: # Preds ..B1.51 ..B1.50
  movl $src_data+524276, %edx #69.15
  cmpq %rdx, %r14 #69.15
  jb ..B1.13 # Prob 82% #69.15
..B1.53: # Preds ..B1.52
  movl 72(%rsp), %ebx #[spill]
  movq %rdi, %r14 #
  movb 80(%rsp), %r12b #[spill]
  movl $src_data+1, %r8d #
  movq 88(%rsp), %r15 #[spill]
..B1.54: # Preds ..B1.53 ..B1.11
  movl $src_data+524288, %ecx #122.43
  subq %r9, %rcx #122.43
  movl %ecx, %r13d #122.50
  cmpl $15, %r13d #123.28
  jae ..B1.66 # Prob 50% #123.28
..B1.55: # Preds ..B1.54
  movl %r13d, %ecx #123.47
  shll $4, %ecx #123.47
  movb %cl, (%r14) #123.4
  incq %r14 #123.4
  testl %r13d, %r13d #124.19
  jbe ..B1.69 # Prob 50% #124.19
..B1.56: # Preds ..B1.55 ..B1.109
  xorl %ecx, %ecx #124.3
..B1.57: # Preds ..B1.111 ..B1.56
  lea 1(%rcx), %r10d #124.3
  cmpl %r13d, %r10d #124.3
  ja ..B1.68 # Prob 50% #124.3
..B1.58: # Preds ..B1.57
  movl %r13d, %edx #124.3
  subl %ecx, %edx #124.3
  cmpl $8, %edx #124.3
  jb ..B1.108 # Prob 10% #124.3
..B1.59: # Preds ..B1.58
  movl %edx, %eax #124.3
  xorl %r10d, %r10d #124.3
  andl $-8, %eax #124.3
..B1.60: # Preds ..B1.60 ..B1.59
  lea (%rcx,%r10), %r11d #125.6
  addl $8, %r10d #124.3
  vmovq (%r11,%r9), %xmm0 #125.13
  movslq %r11d, %r11 #125.6
  vmovq %xmm0, (%r11,%r14) #125.6
  cmpl %eax, %r10d #124.3
  jb ..B1.60 # Prob 82% #124.3
..B1.62: # Preds ..B1.60 ..B1.108
  cmpl %edx, %eax #124.3
  jae ..B1.68 # Prob 10% #124.3
..B1.64: # Preds ..B1.62 ..B1.64
  lea (%rcx,%rax), %r10d #125.6
  incl %eax #124.3
  movslq %r10d, %rsi #125.6
  movb (%r10,%r9), %r11b #125.13
  movb %r11b, (%rsi,%r14) #125.6
  cmpl %edx, %eax #124.3
  jb ..B1.64 # Prob 82% #124.3
  jmp ..B1.68 # Prob 100% #124.3
..B1.66: # Preds ..B1.54
  movb $240, (%r14) #123.4
  incq %r14 #123.4
  cmpl $96, %r13d #124.3
  jbe ..B1.109 # Prob 0% #124.3
..B1.67: # Preds ..B1.66
  movl %ecx, %edx #124.3
  movq %r14, %rdi #124.3
  movq %r9, %rsi #124.3
  vzeroupper #124.3
  call __intel_avx_rep_memcpy #124.3
..B1.116: # Preds ..B1.67
  movl $src_data+1, %r8d #
..B1.68: # Preds ..B1.64 ..B1.62 ..B1.57 ..B1.116
  decl %r13d #125.6
  movslq %r13d, %r13 #125.6
  lea 1(%r14,%r13), %r14 #125.6
..B1.69: # Preds ..B1.68 ..B1.55
  movl $dst_data, %ecx #127.25
  incb %r12b #158.33
  subq %rcx, %r14 #127.25
  movl %ebx, %r11d #161.22
  addl $4099, %ebx #158.33
  movl %r14d, %r10d #160.23
  andq $524287, %r11 #161.31
  shrl $1, %r14d #160.79
  shlq $32, %r10 #160.34
  movzbl dst_data(%rip), %r9d #160.40
  xorq %r9, %r10 #160.40
  movzbl dst_data(%r14), %edi #160.60
  shlq $16, %rdi #160.85
  xorq %rdi, %r10 #160.85
  xorb $85, src_data(%r11) #161.5
  addq %r10, %r15 #160.5
  cmpb $24, %r12b #158.25
  jb ..B1.10 # Prob 95% #158.25
..B1.70: # Preds ..B1.69
  movq %r15, %rsi #
  movl $.L_2__STRING.0, %edi #164.3
  xorl %eax, %eax #164.3
  movq (%rsp), %r12 #[spill]
  movq 8(%rsp), %r13 #[spill]
  movq 16(%rsp), %r14 #[spill]
  movq 24(%rsp), %r15 #[spill]
  movq 32(%rsp), %rbx #[spill]
  vzeroupper #164.3
  call printf #164.3
..B1.71: # Preds ..B1.70
  xorl %eax, %eax #165.10
  movq %rbp, %rsp #165.10
  popq %rbp #165.10
  ret #165.10
..B1.72: # Preds ..B1.29
  cmpl $32, %r13d #97.7
  jb ..B1.32 # Prob 10% #97.7
..B1.73: # Preds ..B1.72
  movl %r13d, %edx #97.7
  xorl %ecx, %ecx #97.7
  andl $-32, %edx #97.7
  xorl %eax, %eax #98.10
..B1.74: # Preds ..B1.74 ..B1.73
  vmovdqu (%rcx,%r9), %ymm0 #98.17
  addl $32, %ecx #97.7
  vmovdqu %ymm0, (%rax,%r12) #98.10
  addq $32, %rax #97.7
  cmpl %edx, %ecx #97.7
  jb ..B1.74 # Prob 82% #97.7
  jmp ..B1.33 # Prob 100% #97.7
..B1.76: # Preds ..B1.26
  cmpl $32, %r10d #92.9
  jl ..B1.90 # Prob 10% #92.9
..B1.77: # Preds ..B1.76
  movl %r10d, %eax #92.9
  xorl %edx, %edx #92.9
  andl $-32, %eax #92.9
  vpcmpeqd %ymm0, %ymm0, %ymm0 #92.9
..B1.78: # Preds ..B1.78 ..B1.77
  addl $32, %edx #92.9
  vmovdqu %ymm0, (%r12) #92.29
  addq $32, %r12 #92.29
  cmpl %eax, %edx #92.9
  jb ..B1.78 # Prob 82% #92.9
..B1.80: # Preds ..B1.78 ..B1.90
  lea 1(%rax), %edx #92.9
  cmpl %r10d, %edx #92.9
  ja ..B1.28 # Prob 50% #92.9
..B1.81: # Preds ..B1.80
  negl %eax #92.9
  addl %r10d, %eax #92.9
  cmpl $8, %eax #92.9
  jl ..B1.89 # Prob 10% #92.9
..B1.82: # Preds ..B1.81
  movl %eax, %edx #92.9
  xorl %r11d, %r11d #92.9
  andl $-8, %edx #92.9
  vpcmpeqd %xmm0, %xmm0, %xmm0 #92.9
..B1.83: # Preds ..B1.83 ..B1.82
  addl $8, %r11d #92.9
  vmovq %xmm0, (%r12) #92.29
  addq $8, %r12 #92.29
  cmpl %edx, %r11d #92.9
  jb ..B1.83 # Prob 82% #92.9
..B1.85: # Preds ..B1.83 ..B1.89
  cmpl %eax, %edx #92.9
  jae ..B1.28 # Prob 0% #92.9
..B1.87: # Preds ..B1.85 ..B1.87
  incl %edx #92.9
  movb $255, (%r12) #92.29
  incq %r12 #92.29
  cmpl %eax, %edx #92.9
  jb ..B1.87 # Prob 82% #92.9
  jmp ..B1.28 # Prob 100% #92.9
..B1.89: # Preds ..B1.81
  xorl %edx, %edx #92.9
  jmp ..B1.85 # Prob 100% #92.9
..B1.90: # Preds ..B1.76
  xorl %eax, %eax #92.9
  jmp ..B1.80 # Prob 100% #92.9
..B1.91: # Preds ..B1.45
  cmpl $32, %ebx #109.9
  jl ..B1.105 # Prob 10% #109.9
..B1.92: # Preds ..B1.91
  movl %ebx, %eax #109.9
  xorl %edx, %edx #109.9
  andl $-32, %eax #109.9
  vpcmpeqd %ymm0, %ymm0, %ymm0 #109.9
..B1.93: # Preds ..B1.93 ..B1.92
  addl $32, %edx #109.9
  vmovdqu %ymm0, (%rdi) #109.29
  addq $32, %rdi #109.29
  cmpl %eax, %edx #109.9
  jb ..B1.93 # Prob 82% #109.9
..B1.95: # Preds ..B1.93 ..B1.105
  lea 1(%rax), %edx #109.9
  cmpl %ebx, %edx #109.9
  ja ..B1.47 # Prob 50% #109.9
..B1.96: # Preds ..B1.95
  negl %eax #109.9
  addl %ebx, %eax #109.9
  cmpl $8, %eax #109.9
  jl ..B1.104 # Prob 10% #109.9
..B1.97: # Preds ..B1.96
  movl %eax, %edx #109.9
  xorl %ecx, %ecx #109.9
  andl $-8, %edx #109.9
  vpcmpeqd %xmm0, %xmm0, %xmm0 #109.9
..B1.98: # Preds ..B1.98 ..B1.97
  addl $8, %ecx #109.9
  vmovq %xmm0, (%rdi) #109.29
  addq $8, %rdi #109.29
  cmpl %edx, %ecx #109.9
  jb ..B1.98 # Prob 82% #109.9
..B1.100: # Preds ..B1.98 ..B1.104
  cmpl %eax, %edx #109.9
  jae ..B1.47 # Prob 0% #109.9
..B1.102: # Preds ..B1.100 ..B1.102
  incl %edx #109.9
  movb $255, (%rdi) #109.29
  incq %rdi #109.29
  cmpl %eax, %edx #109.9
  jb ..B1.102 # Prob 82% #109.9
  jmp ..B1.47 # Prob 100% #109.9
..B1.104: # Preds ..B1.96
  xorl %edx, %edx #109.9
  jmp ..B1.100 # Prob 100% #109.9
..B1.105: # Preds ..B1.91
  xorl %eax, %eax #109.9
  jmp ..B1.95 # Prob 100% #109.9
..B1.106: # Preds ..B1.34
  xorl %ecx, %ecx #97.7
  jmp ..B1.38 # Prob 100% #97.7
..B1.108: # Preds ..B1.58
  xorl %eax, %eax #124.3
  jmp ..B1.62 # Prob 100% #124.3
..B1.109: # Preds ..B1.66
  cmpl $32, %r13d #124.3
  jb ..B1.56 # Prob 10% #124.3
..B1.110: # Preds ..B1.109
  movl %r13d, %ecx #124.3
  xorl %r11d, %r11d #124.3
  andl $-32, %ecx #124.3
  xorl %r10d, %r10d #125.6
..B1.111: # Preds ..B1.111 ..B1.110
  vmovdqu (%r11,%r9), %ymm0 #125.13
  addl $32, %r11d #124.3
  vmovdqu %ymm0, (%r10,%r14) #125.6
  addq $32, %r10 #124.3
  cmpl %ecx, %r11d #124.3
  jb ..B1.111 # Prob 82% #124.3
  jmp ..B1.57 # Prob 100% #124.3
src_data:
hash_table:
dst_data:
.L_2__STRING.0:

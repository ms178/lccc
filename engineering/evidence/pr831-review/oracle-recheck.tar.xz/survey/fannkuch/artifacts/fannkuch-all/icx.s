.LCPI0_0:
.LCPI0_1:
.LCPI0_3:
main:
  pushq %rbp
  pushq %r15
  pushq %r14
  pushq %r13
  pushq %r12
  pushq %rbx
  subq $24, %rsp
  vstmxcsr 12(%rsp)
  orl $32832, 12(%rsp)
  vldmxcsr 12(%rsp)
  vmovdqu .LCPI0_0(%rip), %ymm0
  vmovdqu %ymm0, perm1(%rip)
  movabsq $38654705672, %rax
  movq %rax, perm1+32(%rip)
  movl $10, perm1+40(%rip)
  movl $11, %r12d
  xorl %r14d, %r14d
  vmovdqu .LCPI0_1(%rip), %ymm2
  vpbroadcastq .LCPI0_3(%rip), %ymm3
  xorl %ebp, %ebp
  xorl %r13d, %r13d
.LBB0_2:
  cmpl $2, %r12d
  jl .LBB0_3
  movl %r12d, %esi
  leaq -1(%rsi), %rdx
  movq %rdx, %rax
  shrq $3, %rax
  cmpl $9, %r12d
  jb .LBB0_21
  movq %rax, %rcx
  xorl %edi, %edi
.LBB0_20:
  vmovd %edi, %xmm0
  vpbroadcastd %xmm0, %ymm0
  vpor %ymm2, %ymm0, %ymm1
  vpaddd %ymm3, %ymm0, %ymm0
  vpblendd $192, %ymm0, %ymm1, %ymm0
  vmovdqu %ymm0, count+4(,%rdi,4)
  addq $8, %rdi
  decq %rcx
  jne .LBB0_20
.LBB0_21:
  movq %rdx, %rcx
  andq $-8, %rcx
  subq %rcx, %rsi
  addq $-2, %rsi
  cmpq $6, %rsi
  ja .LBB0_4
  jmpq *.LJTI0_0(,%rsi,8)
.LBB0_28:
  leal 2(,%rax,8), %eax
  jmp .LBB0_35
.LBB0_3:
  movl %r12d, %r15d
  jmp .LBB0_5
.LBB0_27:
  leal 2(,%rax,8), %eax
  jmp .LBB0_34
.LBB0_26:
  leal 2(,%rax,8), %eax
  jmp .LBB0_33
.LBB0_25:
  leal 2(,%rax,8), %eax
  jmp .LBB0_32
.LBB0_24:
  shll $3, %eax
  jmp .LBB0_31
.LBB0_23:
  shll $3, %eax
  jmp .LBB0_30
.LBB0_29:
  leal 7(,%rax,8), %esi
  shll $3, %eax
  leal 8(%rcx), %edi
  movl %edi, count(,%rsi,4)
.LBB0_30:
  movl %eax, %esi
  orl $6, %esi
  orl $7, %edx
  movl %edx, count(,%rsi,4)
.LBB0_31:
  orl $2, %eax
  leal 3(%rax), %edx
  movl %ecx, %esi
  orl $6, %esi
  movl %esi, count(,%rdx,4)
.LBB0_32:
  leal 2(%rax), %edx
  movl %ecx, %esi
  orl $5, %esi
  movl %esi, count(,%rdx,4)
.LBB0_33:
  leal 1(%rax), %edx
  movl %ecx, %esi
  orl $4, %esi
  movl %esi, count(,%rdx,4)
.LBB0_34:
  movl %eax, %edx
  movl %ecx, %esi
  orl $3, %esi
  movl %esi, count(,%rdx,4)
.LBB0_35:
  decl %eax
  orl $2, %ecx
  movl %ecx, count(,%rax,4)
.LBB0_4:
  movl $1, %r15d
.LBB0_5:
  vmovups perm1(%rip), %ymm0
  vmovups %ymm0, perm(%rip)
  vmovdqu perm1+12(%rip), %ymm0
  vmovdqu %ymm0, perm+12(%rip)
  movl perm(%rip), %ecx
  xorl %eax, %eax
  jmp .LBB0_6
.LBB0_14:
  movl perm(%rip), %ecx
.LBB0_15:
  incl %eax
.LBB0_6:
  testl %ecx, %ecx
  je .LBB0_16
  leal 1(%rcx), %esi
  cmpl $2, %esi
  jl .LBB0_15
  movl %esi, %edx
  sarl %edx
  cmpl $8, %esi
  jb .LBB0_11
  movl %edx, %esi
  shrl $2, %esi
  movl $perm+12, %edi
  movl %ecx, %r8d
.LBB0_10:
  movl -12(%rdi), %r9d
  movslq %r8d, %r8
  movl perm(,%r8,4), %r10d
  movl %r10d, -12(%rdi)
  movl %r9d, perm(,%r8,4)
  movl -8(%rdi), %r9d
  leal -1(%r8), %r10d
  movslq %r10d, %r10
  movl perm(,%r10,4), %r11d
  movl %r11d, -8(%rdi)
  movl %r9d, perm(,%r10,4)
  movl -4(%rdi), %r9d
  leal -2(%r8), %r10d
  movslq %r10d, %r10
  movl perm(,%r10,4), %r11d
  movl %r11d, -4(%rdi)
  movl %r9d, perm(,%r10,4)
  movl (%rdi), %r9d
  leal -3(%r8), %r10d
  movslq %r10d, %r10
  movl perm(,%r10,4), %r11d
  movl %r11d, (%rdi)
  movl %r9d, perm(,%r10,4)
  addq $16, %rdi
  addl $-4, %r8d
  decq %rsi
  jne .LBB0_10
.LBB0_11:
  movl %edx, %esi
  andl $-4, %esi
  cmpq %rdx, %rsi
  jae .LBB0_14
  movl %edx, %edi
  andl $-4, %edi
  subl %edi, %ecx
.LBB0_13:
  movl perm(,%rsi,4), %edi
  movslq %ecx, %rcx
  movl perm(,%rcx,4), %r8d
  movl %r8d, perm(,%rsi,4)
  movl %edi, perm(,%rcx,4)
  incq %rsi
  decl %ecx
  cmpq %rsi, %rdx
  jne .LBB0_13
  jmp .LBB0_14
.LBB0_16:
  cmpl %ebp, %eax
  cmovgl %eax, %ebp
  movl %eax, %ecx
  negl %ecx
  testb $1, %r13b
  cmovel %eax, %ecx
  addl %ecx, %r14d
  cmpl $11, %r15d
  je .LBB0_17
  movl %ebp, 8(%rsp)
  movq %r14, 16(%rsp)
  incl %r13d
  movl %r13d, 4(%rsp)
  movl $11, %ebx
  subl %r15d, %ebx
  cmpl $2, %ebx
  jb .LBB0_46
  movl %ebx, %r13d
  shrl %r13d
  movl %r15d, %r14d
.LBB0_38:
  movl perm1(%rip), %ebp
  testl %r14d, %r14d
  jle .LBB0_40
  movl %r14d, %edx
  shlq $2, %rdx
  movl $perm1, %edi
  movl $perm1+4, %esi
  vzeroupper
  callq memmove@PLT
  vpbroadcastq .LCPI0_3(%rip), %ymm3
  vmovdqu .LCPI0_1(%rip), %ymm2
.LBB0_40:
  movslq %r14d, %rax
  movl %ebp, perm1(,%rax,4)
  movl count(,%rax,4), %ecx
  decl %ecx
  movl %ecx, count(,%rax,4)
  testl %ecx, %ecx
  jg .LBB0_41
  movl perm1(%rip), %ebp
  leal 1(%r14), %r12d
  cmpl $2147483646, %r14d
  ja .LBB0_44
  movl %r12d, %edx
  shlq $2, %rdx
  movl $perm1, %edi
  movl $perm1+4, %esi
  vzeroupper
  callq memmove@PLT
  vpbroadcastq .LCPI0_3(%rip), %ymm3
  vmovdqu .LCPI0_1(%rip), %ymm2
.LBB0_44:
  movslq %r12d, %rax
  movl %ebp, perm1(,%rax,4)
  movl count(,%rax,4), %ecx
  decl %ecx
  movl %ecx, count(,%rax,4)
  testl %ecx, %ecx
  jg .LBB0_1
  addl $2, %r14d
  decl %r13d
  jne .LBB0_38
.LBB0_46:
  movl %ebx, %eax
  andl $-2, %eax
  cmpl %ebx, %eax
  movq 16(%rsp), %r14
  movl 8(%rsp), %ebp
  movl 4(%rsp), %r13d
  jae .LBB0_17
  addl %eax, %r15d
  movl %r15d, %r12d
.LBB0_48:
  movl perm1(%rip), %ebx
  testl %r12d, %r12d
  jle .LBB0_50
  movl %r12d, %edx
  shlq $2, %rdx
  movl $perm1, %edi
  movl $perm1+4, %esi
  vzeroupper
  callq memmove@PLT
  vpbroadcastq .LCPI0_3(%rip), %ymm3
  vmovdqu .LCPI0_1(%rip), %ymm2
.LBB0_50:
  movslq %r12d, %rax
  movl %ebx, perm1(,%rax,4)
  movl count(,%rax,4), %ecx
  decl %ecx
  movl %ecx, count(,%rax,4)
  testl %ecx, %ecx
  jg .LBB0_2
  incl %r12d
  cmpl $11, %r12d
  jne .LBB0_48
  jmp .LBB0_17
.LBB0_41:
  movl %r14d, %r12d
.LBB0_1:
  movq 16(%rsp), %r14
  movl 8(%rsp), %ebp
  movl 4(%rsp), %r13d
  jmp .LBB0_2
.LBB0_17:
  movl $.L.str, %edi
  movl %r14d, %esi
  movl $11, %edx
  movl %ebp, %ecx
  xorl %eax, %eax
  vzeroupper
  callq printf
  xorl %eax, %eax
  addq $24, %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  popq %rbp
  retq
.LJTI0_0:

.L.str:


.Lstr0:

buffer:

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $88, %rsp
    leaq buffer(%rip), %r10
    xorl %r8d, %r8d
    movl $2235986729, %r9d
.LBB1:
    cmpl $1048576, %r8d
jb .LBB2
.LBB27:
    movq $0, 72(%rsp)
    xorl %r11d, %r11d
    movl $324508639, %esi
    jmp .LBB28
.LBB2:
    imull $1664525, %r9d, %r9d
    leal 1013904223(%r9), %edx
    testb $7, %dl
jne .LBB26
    cmpl $64, %r8d
jb .LBB26
.LBB3:
    leal -64(%r8), %r9d
    movl %edx, %edi
    shrl $28, %edi
    addl %edi, %r9d
    movzbl (%r10, %r9), %eax
    movl %eax, 12(%rsp)
    movzbl 12(%rsp), %esi
    jmp .LBB4
.LBB26:
    movl %edx, %r9d
    shrl $24, %r9d
    movzbl %r9b, %esi
.LBB4:
    movl %r8d, %edi
    movb %sil, (%r10, %rdi)
    addl $1, %r8d
    movq %rdx, %r9
    cmpl $1048576, %r8d
jb .LBB2
    jmp .LBB27
.LBB28:
    movl 72(%rsp), %eax
    cmpl $16, %eax
jae .LBB29
.LBB5:
    movq %r11, %r13
    xorl %r10d, %r10d
    movq %rsi, %r14
.LBB6:
    cmpl $131072, %r10d
jae .LBB17
.LBB7:
    imull $1664525, %r14d, %r9d
    leal 1013904223(%r9), %r15d
    movq %r15, %rbp
    andl $1048319, %ebp
    movl %r15d, %r8d
    shrl $12, %r8d
    andl $1048319, %r8d
    movl %r15d, %edi
    andl $127, %edi
    addl $16, %edi
    movl %ebp, %r12d
    leaq buffer(%rip), %rax
    addq %r12, %rax
    movq %rax, 24(%rsp)
    movl %r8d, %r12d
    leaq (%rax, %rdi), %rsi
    leaq -7(%rsi), %rbx
    movq %rax, %r8
    leaq buffer(%rip), %r9
    addq %r12, %r9
.LBB8:
    cmpq %rbx, %r8
jb .LBB21
.LBB9:
    movq %r8, %rdi
    movq %r9, %r14
    jmp .LBB10
.LBB21:
    movq (%r9), %rdi
    xorq (%r8), %rdi
jne .LBB23
.LBB22:
    addq $8, %r8
    addq $8, %r9
    cmpq %rbx, %r8
jb .LBB21
    jmp .LBB9
.LBB23:
    tzcntq %rdi, %rsi
    shrl $3, %esi
    addq %rsi, %r8
    subq 24(%rsp), %r8
    movl %r8d, %r9d
    jmp .LBB16
.LBB12:
    cmpq %rsi, %rdx
jae .LBB15
.LBB13:
    movzbl (%rdx), %r8d
    cmpb (%r9), %r8b
jne .LBB15
.LBB14:
    addq $1, %rdx
    leaq 1(%r9), %rax
    movq %rax, 8(%rsp)
    movq %rax, %r9
    cmpq %rsi, %rdx
jb .LBB13
.LBB15:
    subq 24(%rsp), %rdx
    movl %edx, %r9d
.LBB16:
    movl %r9d, %esi
    movl %r10d, %edx
    andl $7, %edx
    shll $3, %edx
    shlxq %rdx, %rsi, %rsi
    movl %ebp, %r8d
    xorq %r8, %rsi
    addq %rsi, %r13
    addl $1, %r10d
    movq %r15, %r14
    cmpl $131072, %r10d
jb .LBB7
.LBB17:
    movl 72(%rsp), %eax
    addl $1, %eax
    movq %rax, 72(%rsp)
    movq %r13, %r11
    movq %r14, %rsi
    cmpl $16, %eax
jb .LBB5
.LBB29:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $88, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB10:
    leaq 31(%rdi), %r11
    cmpq %rsi, %r11
jb .LBB18
.LBB11:
    movq %rdi, %rdx
    movq %r14, %r9
    jmp .LBB12
.LBB18:
    leaq 31(%r14), %r8
    movq %r14, %r9
    orq $4095, %r9
    cmpq %r9, %r8
jbe .LBB19
.LBB25:
    movq %rdi, %rdx
    movq %r14, %r9
    jmp .LBB12
.LBB19:
    vmovdqu (%rdi), %ymm2
    vmovdqu (%r14), %ymm3
    vpcmpeqb %ymm3, %ymm2, %ymm0
    vpmovmskb %ymm0, %eax
    movq %rax, 16(%rsp)
    cmpl $-1, %eax
je .LBB20
.LBB24:
    xorq $-1, %rax
    tzcntl %eax, %eax
    movl %eax, %r11d
    leaq (%rdi, %r11, 1), %r8
    leaq (%r14, %r11, 1), %rbx
    movq %r8, %rdx
    movq %rbx, %r9
    jmp .LBB12
.LBB20:
    addq $32, %rdi
    addq $32, %r14
    leaq 31(%rdi), %r9
    cmpq %rsi, %r9
jb .LBB18
    jmp .LBB11



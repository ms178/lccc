linux_find_next_andnot_bit.part.0:
  movq %rsi, %r8
  movq %rcx, %rsi
  movq %rdx, %rax
  movl %ecx, %edx
  shrq $6, %rsi
  movq $-1, %rcx
  movq (%r8,%rsi,8), %r9
  shlx %rdx, %rcx, %rcx
  andq (%rdi,%rsi,8), %rcx
  andn %rcx, %r9, %rdx
  andn %rcx, %r9, %r9
  jne .L2
  leaq 1(%rsi), %rcx
  salq $6, %rcx
  jmp .L4
.L16:
  incq %rsi
  movq (%r8,%rsi,8), %rdx
  andn (%rdi,%rsi,8), %rdx, %rdx
  testq %rdx, %rdx
  jne .L5
  addq $64, %rcx
.L4:
  cmpq %rax, %rcx
  jb .L16
  ret
.L2:
  movq %rsi, %rcx
  salq $6, %rcx
.L5:
  xorl %esi, %esi
  testl %edx, %edx
  jne .L6
  shrq $32, %rdx
  movl $32, %esi
.L6:
  testw %dx, %dx
  jne .L7
  addl $16, %esi
  shrq $16, %rdx
.L7:
  testb %dl, %dl
  jne .L8
  addl $8, %esi
  shrq $8, %rdx
.L8:
  testb $15, %dl
  jne .L9
  addl $4, %esi
  shrq $4, %rdx
.L9:
  testb $3, %dl
  jne .L10
  addl $2, %esi
  shrq $2, %rdx
.L10:
  andl $1, %edx
  cmpq $1, %rdx
  adcl $0, %esi
  addq %rcx, %rsi
  cmpq %rax, %rsi
  cmovbe %rsi, %rax
  ret
.LC7:
main:
  pushq %rbp
  xorl %ecx, %ecx
  movl $192, %edx
  movq %rsp, %rbp
  pushq %r13
  pushq %r12
  pushq %rbx
  andq $-32, %rsp
  subq $64, %rsp
  vmovdqa .LC1(%rip), %xmm0
  leaq 32(%rsp), %rsi
  movq %rsp, %rdi
  movq $0, 16(%rsp)
  vmovdqa %xmm0, (%rsp)
  vmovdqa .LC2(%rip), %xmm0
  movq $-1, 48(%rsp)
  vmovdqa %xmm0, 32(%rsp)
  call linux_find_next_andnot_bit.part.0
  cmpq $5, %rax
  jne .L20
  movl $6, %ecx
  movl $192, %edx
  leaq 32(%rsp), %rsi
  movq %rax, %r10
  call linux_find_next_andnot_bit.part.0
  cmpq $192, %rax
  je .L32
.L20:
  movl $2, %eax
.L17:
  leaq -24(%rbp), %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %rbp
  ret
.L32:
  vmovq %r10, %xmm3
  vmovdqa .LC0(%rip), %ymm1
  vmovdqa .LC3(%rip), %ymm7
  xorl %eax, %eax
  vmovdqa .LC5(%rip), %ymm6
  vmovdqa .LC6(%rip), %ymm4
  vpbroadcastq %xmm3, %ymm3
  vpxor %xmm5, %xmm5, %xmm5
.L21:
  vpand %ymm7, %ymm1, %ymm0
  addq $32, %rax
  vpaddq %ymm4, %ymm1, %ymm1
  vpcmpeqq %ymm3, %ymm0, %ymm0
  vpand %ymm6, %ymm0, %ymm2
  vpcmpeqq %ymm5, %ymm0, %ymm0
  vmovdqa %ymm2, linux_bitmap_a-32(%rax)
  vmovdqa %ymm0, linux_bitmap_b-32(%rax)
  cmpq $131072, %rax
  jne .L21
  xorl %r11d, %r11d
  xorl %r12d, %r12d
  xorl %r10d, %r10d
  xorl %ebx, %ebx
  movl $1, %r13d
  jmp .L24
.L22:
  movzbl %r12b, %edx
  leal 0(,%rbx,8), %eax
  addq $13, %r12
  addq $524288, %r11
  subl %ebx, %eax
  salq $6, %rdx
  incl %ebx
  shlx %rax, %r13, %rax
  xorq %rax, linux_bitmap_b+40(,%rdx,8)
  cmpl $65536, %ebx
  je .L33
.L24:
  movl %ebx, %ecx
  andl $63, %ecx
.L23:
  movl $1048576, %edx
  movl $linux_bitmap_b, %esi
  movl $linux_bitmap_a, %edi
  call linux_find_next_andnot_bit.part.0
  cmpq $1048576, %rax
  je .L22
  leaq (%r11,%rax), %rdx
  leaq 1(%rax), %rcx
  xorq %rdx, %r10
  cmpq $1048575, %rax
  jne .L23
  jmp .L22
.L33:
  xorl %eax, %eax
  movq %r10, %rsi
  movl $.LC7, %edi
  vzeroupper
  call printf
  xorl %eax, %eax
  jmp .L17
.LC0:
.LC1:
.LC2:
.LC3:
.LC5:
.LC6:

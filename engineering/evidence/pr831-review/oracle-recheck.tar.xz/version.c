#include <stdio.h>
#ifndef __INTEL_LLVM_COMPILER
#define __INTEL_LLVM_COMPILER 0
#endif
#ifndef __INTEL_COMPILER
#define __INTEL_COMPILER 0
#endif
int main(void) { printf("version=%s;intel_classic=%d;intel_llvm=%d\n", __VERSION__, __INTEL_COMPILER, __INTEL_LLVM_COMPILER); return 0; }

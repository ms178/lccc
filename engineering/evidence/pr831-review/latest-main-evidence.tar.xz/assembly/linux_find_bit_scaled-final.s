.section .rodata
.Lstr0:
    .byte 37, 108, 117, 10, 0

.section .rodata
.align 16
.type .LCA_0, @object
.size .LCA_0, 24
.LCA_0:
    .byte 32
    .zero 7
    .byte 4
    .zero 15
.align 16
.type .LCA_1, @object
.size .LCA_1, 24
.LCA_1:
    .zero 8
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
.align 16
.type .LCA_2, @object
.size .LCA_2, 24
.LCA_2:
    .byte 32
    .zero 7
    .byte 4
    .zero 15
.align 16
.type .LCA_3, @object
.size .LCA_3, 24
.LCA_3:
    .zero 8
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255
    .byte 255

.section .bss
.align 16
.type linux_bitmap_a, @object
.size linux_bitmap_a, 131072
linux_bitmap_a:
    .zero 131072
.align 16
.type linux_bitmap_b, @object
.size linux_bitmap_b, 131072
linux_bitmap_b:
    .zero 131072

.text
.p2align 4
.type linux_find_next_andnot_bit, @function
linux_find_next_andnot_bit:
.cfi_startproc
    pushq %r12
    .cfi_def_cfa_offset 16
    .cfi_offset %r12, -16
    pushq %rbp
    .cfi_def_cfa_offset 24
    .cfi_offset %rbp, -24
    subq $24, %rsp
    .cfi_def_cfa_offset 48
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    cmpq %rdx, %rcx
jb .LBB2
.LBB1:
    movq %rdx, %rax
.L__lccc_epilogue_1:
    addq $24, %rsp
    .cfi_def_cfa_offset 24
    popq %rbp
    .cfi_def_cfa_offset 16
    popq %r12
    .cfi_def_cfa_offset 8
    ret
.LBB2:
    .cfi_def_cfa_offset 48
    movq %rcx, %r9
    andq $63, %r9
    movq $-1, %r11
    shlxq %r9, %r11, %r11
    movq %rcx, %r10
    shrq $6, %r10
    movq (%rdi, %r10, 8), %r12
    movq (%rsi, %r10, 8), %rax
    andnq %r12, %rax, %r9
    movq %r9, %rcx
    andq %r11, %rcx
.LBB3:
    testq %rcx, %rcx
jne .LBB6
.p2align 4,,10
.p2align 3
.LBB4:
    leaq 1(%r10), %r9
    shlq $6, %r9
    cmpq %rdx, %r9
jb .LBB5
.LBB7:
    movq %rdx, %rax
    jmp .L__lccc_epilogue_1
.LBB5:
    addq $1, %r10
    movq (%rdi, %r10, 8), %rbp
    movq (%rsi, %r10, 8), %rax
    andnq %rbp, %rax, %rcx
    testq %rcx, %rcx
je .LBB4
.LBB6:
    shlq $6, %r10
    tzcntq %rcx, %r11
    movl %r11d, %edi
    addq %rdi, %r10
    cmpq %rdx, %r10
    movq %rdx, %rcx
    cmovbq %r10, %rcx
    movq %rcx, %rax
    jmp .L__lccc_epilogue_1
.cfi_endproc
.size linux_find_next_andnot_bit, .-linux_find_next_andnot_bit

.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $24, %rsp
    .cfi_def_cfa_offset 80
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    leaq .LCA_2(%rip), %rdi
    leaq .LCA_3(%rip), %rsi
    movl $192, %edx
    xorl %ecx, %ecx
    call linux_find_next_andnot_bit
    # LCCC_CALL_ARGS 4
    # LCCC_CALL_FP 0
    cmpq $5, %rax
jne .LBB10
.LBB9:
    leaq .LCA_2(%rip), %rdi
    leaq .LCA_3(%rip), %rsi
    movl $192, %edx
    movl $6, %ecx
    call linux_find_next_andnot_bit
    # LCCC_CALL_ARGS 4
    # LCCC_CALL_FP 0
    cmpq $192, %rax
    movl $0, %ecx
    movl $1, %r8d
    cmovnel %ecx, %r8d
    testl %r8d, %r8d
jne .LBB11
.LBB10:
    movl $2, %eax
.L__lccc_epilogue_2:
    addq $24, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.LBB11:
    .cfi_def_cfa_offset 80
    leaq linux_bitmap_b(%rip), %rbx
    leaq linux_bitmap_a(%rip), %r12
    xorl %r13d, %r13d
.LBB12:
    cmpq $16384, %r13
jae .LBB16
.p2align 4,,10
.p2align 3
.LBB13:
    movq $0, (%r12, %r13, 8)
    movq $-1, (%rbx, %r13, 8)
    movq %r13, %r11
    andq $63, %r11
    cmpq $5, %r11
jne .LBB15
.LBB14:
    imulq $13, %r13, %r10
    leaq 7(%r10), %r8
    andq $63, %r8
    movq %r13, %rdi
    shlq $3, %rdi
    movl $1, %eax
    movq %r8, %rcx
    shlxq %rcx, %rax, %rax
    movq %rax, (%r12, %r13, 8)
    movq $0, (%rbx, %r13, 8)
.LBB15:
    addq $1, %r13
    cmpq $16384, %r13
jb .LBB13
.LBB16:
    xorl %r14d, %r14d
    xorl %r11d, %r11d
.LBB17:
    cmpl $65536, %r14d
jae .LBB21
.p2align 4,,10
.p2align 3
.LBB18:
    movq %r14, %rax
    andq $63, %rax
    movl %eax, %r15d
    movl %r14d, %ebp
    shlq $19, %rbp
    movq %r11, %r12
.p2align 4,,10
.p2align 3
.LBB19:
    leaq linux_bitmap_a(%rip), %rdi
    leaq linux_bitmap_b(%rip), %rsi
    movl $1048576, %edx
    movq %r15, %rcx
    call linux_find_next_andnot_bit
    # LCCC_CALL_ARGS 4
    # LCCC_CALL_FP 0
    leaq (%rax, %rbp, 1), %rdi
    movq %r12, %rsi
    xorq %rdi, %rsi
    leaq 1(%rax), %rdx
    cmpq $1048576, %rax
    movq %r12, %r11
    cmovbq %rsi, %r11
    cmovbq %rdx, %r15
    movq %r11, %r12
jb .LBB19
.LBB20:
    movl %r14d, %r10d
    imulq $13, %r10, %r10
    andq $255, %r10
    shlq $6, %r10
    addq $5, %r10
    imull $7, %r14d, %r8d
    andl $63, %r8d
    movl $1, %r9d
    shlxq %r8, %r9, %r9
    xorq (%rbx, %r10, 8), %r9
    movq %r9, (%rbx, %r10, 8)
    addl $1, %r14d
    cmpl $65536, %r14d
jb .LBB18
.LBB21:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    jmp .L__lccc_epilogue_2
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

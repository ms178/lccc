.section .rodata
.Lstr0:
    .byte 37, 48, 49, 54, 108, 108, 120, 10, 0

.section .bss
.align 16
.type src_data, @object
.size src_data, 524352
src_data:
    .zero 524352
.align 16
.type dst_data, @object
.size dst_data, 1048576
dst_data:
    .zero 1048576
.align 16
.type hash_table, @object
.size hash_table, 65536
hash_table:
    .zero 65536

.text
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $232, %rsp
    .cfi_def_cfa_offset 288
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    leaq dst_data(%rip), %rax
    movq %rax, 88(%rsp)
    leaq src_data(%rip), %rax
    movq %rax, 80(%rsp)
    leaq 524288(%rax), %rbp
    movq 80(%rsp), %rax
    addq $524276, %rax
    movq %rax, 72(%rsp)
    movq 80(%rsp), %rax
    addq $1, %rax
    movq %rax, 64(%rsp)
    xorl %r11d, %r11d
    movl $1511734397, %r10d
.LBB1:
    cmpl $524288, %r11d
jae .LBB53
.p2align 4,,10
.p2align 3
.LBB2:
    imull $1664525, %r10d, %r10d
    leal 1013904223(%r10), %r8d
    movl %r8d, %r9d
    andl $15, %r9d
    cmpl $6, %r9d
jae .LBB52
    cmpl $128, %r11d
jb .LBB52
.LBB3:
    leal -128(%r11), %edx
    movl %r8d, %r10d
    andl $63, %r10d
    addl %r10d, %edx
    leaq src_data(%rip), %rcx
    movzbl (%rcx, %rdx), %esi
.LBB4:
    movl %r11d, %edx
    leaq src_data(%rip), %rcx
    movb %sil, (%rcx, %rdx)
    addl $1, %r11d
    movq %r8, %r10
    cmpl $524288, %r11d
jb .LBB2
    jmp .LBB53
.p2align 5,,15
.p2align 4
.LBB5:
.LBB6:
    movl $16384, %eax
    subq $0, %rax
    leaq 0(,%rax,4), %r12
    testq %rax, %rax
jne .LBB51
.LBB7:
    movq 64(%rsp), %rsi
    movq 88(%rsp), %rax
    movq %rax, 216(%rsp)
    movq 80(%rsp), %r15
.LBB8:
    cmpq 72(%rsp), %rsi
jae .LBB34
.p2align 5,,15
.p2align 4
.LBB9:
    movl (%rsi), %edx
    imull $-1640531535, %edx, %edx
    shrl $18, %edx
    leaq hash_table(%rip), %r10
    leaq (%r10, %rdx, 4), %r10
    movl (%r10), %r8d
    leaq src_data(%rip), %rcx
    leaq (%rcx, %r8), %r9
    movq %rsi, %rdi
    subq 80(%rsp), %rdi
    movl %edi, (%r10)
    cmpq %rsi, %r9
jae .LBB49
.LBB10:
    cmpq 80(%rsp), %r9
jb .LBB49
.LBB11:
    movl (%r9), %edi
    cmpl (%rsi), %edi
jne .LBB49
.LBB12:
    movq %rsi, %rax
    addq $4, %rax
    movq %rax, 208(%rsp)
    leaq 4(%r9), %r12
.LBB13:
    leaq 31(%rax), %r11
    cmpq %rbp, %r11
jb .LBB40
.LBB14:
    movq 208(%rsp), %rbx
    movq %r12, %r14
.LBB15:
    cmpq %rbp, %rbx
jae .LBB18
.p2align 4,,10
.p2align 3
.LBB16:
    movzbl (%rbx), %r10d
    cmpb (%r14), %r10b
jne .LBB18
.LBB17:
    addq $1, %rbx
    addq $1, %r14
    cmpq %rbp, %rbx
jb .LBB16
.LBB18:
    movq %r14, %rdi
    subq %r9, %rdi
    leaq -4(%rdi), %rax
    movq %rax, 56(%rsp)
    movq 216(%rsp), %rax
    addq $1, %rax
    movq %rax, 192(%rsp)
    subq %r15, %rsi
    movl %esi, %eax
    movq %rax, 48(%rsp)
    cmpl $15, %esi
jb .LBB48
.LBB19:
    movq 216(%rsp), %rcx
    movb $240, (%rcx)
    movq 192(%rsp), %r12
    movl 48(%rsp), %r13d
    subl $15, %r13d
.LBB20:
    cmpl $255, %r13d
jb .LBB22
.p2align 4,,10
.p2align 3
.LBB21:
    movb $255, (%r12)
    subl $255, %r13d
    leaq 1(%r12), %rax
    movq %rax, 24(%rsp)
    movq %rax, %r12
    cmpl $255, %r13d
jae .LBB21
.LBB22:
    movq %r12, %rax
    addq $1, %rax
    movq %rax, 192(%rsp)
    movb %r13b, (%r12)
.LBB23:
    movl 48(%rsp), %r11d
    movq %r11, %r10
    movq 192(%rsp), %r8
    subq %r15, %r8
    subq $1, %r10
    cmpq %r10, %r8
    movl %r11d, %edi
ja .LBB47
.LBB24:
    xorl %r13d, %r13d
.LBB25:
    cmpq %rdi, %r13
jb .LBB39
.LBB26:
.LBB27:
    movq %rbx, %rsi
    subq %r14, %rsi
    movzwl %si, %edx
    movq 192(%rsp), %r10
    addq $1, %r10
    movl %edx, %r8d
    movq 192(%rsp), %rcx
    movb %dl, (%rcx)
    movq 192(%rsp), %r14
    addq $2, %r14
    sarl $8, %r8d
    movb %r8b, (%r10)
    movl 56(%rsp), %r15d
    cmpl $15, %r15d
jb .LBB46
.LBB28:
    movq 216(%rsp), %rcx
    movzbl (%rcx), %edx
    orl $15, %edx
    movb %dl, (%rcx)
    movq %r14, %r12
    movl %r15d, %r13d
    subl $15, %r13d
.LBB29:
    cmpl $255, %r13d
jb .LBB31
.p2align 4,,10
.p2align 3
.LBB30:
    movb $255, (%r12)
    leal -255(%r13), %eax
    movl %eax, 28(%rsp)
    leaq 1(%r12), %rax
    movq %rax, %r12
    movl 28(%rsp), %r13d
    cmpl $255, %r13d
jae .LBB30
.LBB31:
    leaq 1(%r12), %r15
    movb %r13b, (%r12)
.LBB32:
    movq %rbx, %r12
    movq %r15, %r13
    movq %rbx, 168(%rsp)
.LBB33:
    movq %r12, %rsi
    movq %r13, 216(%rsp)
    movq 168(%rsp), %r15
    cmpq 72(%rsp), %r12
jb .LBB9
.LBB34:
    movq %rbp, %rdi
    subq %r15, %rdi
    movl %edi, %r14d
    movq 216(%rsp), %rax
    addq $1, %rax
    movq %rax, 40(%rsp)
    movl %edi, %edx
    shll $4, %edx
    cmpl $15, %edi
    movl $240, %r10d
    cmovbl %edx, %r10d
    movq 216(%rsp), %rcx
    movb %r10b, (%rcx)
    movl %r14d, %r10d
    movq %r10, %r9
    movq 40(%rsp), %rdi
    subq %r15, %rdi
    subq $1, %r9
    cmpq %r9, %rdi
    movl %r14d, %r13d
ja .LBB50
.LBB35:
    movq 40(%rsp), %r14
    xorl %r12d, %r12d
.LBB36:
    cmpq %r13, %r12
jb .LBB45
.LBB37:
    movq %r14, 160(%rsp)
.LBB38:
    movq 160(%rsp), %rdx
    subq 88(%rsp), %rdx
    movl %edx, %r8d
    movl %edx, %r9d
    shlq $32, %r9
    movzbl dst_data(%rip), %eax
    xorq %rax, %r9
    shrl $1, %r8d
    leaq dst_data(%rip), %rcx
    movzbl (%rcx, %r8), %eax
    movl %eax, %r8d
    shlq $16, %r8
    xorq %r8, %r9
    addq %r9, 144(%rsp)
    movl 152(%rsp), %eax
    imull $4099, %eax, %eax
    movl %eax, %r9d
    andq $524287, %r9
    leaq src_data(%rip), %rsi
    addq %r9, %rsi
    movzbl (%rsi), %edx
    xorl $85, %edx
    movb %dl, (%rsi)
    movl 152(%rsp), %eax
    addl $1, %eax
    movq %rax, 152(%rsp)
    cmpl $24, %eax
jb .LBB5
    jmp .LBB55
.p2align 4,,10
.p2align 3
.LBB39:
    movzbl (%r15, %r13), %eax
    movq 192(%rsp), %rcx
    movb %al, (%rcx)
    leaq 1(%r13), %rax
    movq %rax, 24(%rsp)
    addq $1, 192(%rsp)
    movq 24(%rsp), %r13
    cmpq %rdi, %r13
jb .LBB39
    jmp .LBB26
.p2align 5,,15
.p2align 4
.LBB40:
    leaq 31(%r12), %rdx
    movq %r12, %r8
    orq $4095, %r8
    cmpq %r8, %rdx
ja .LBB44
.LBB41:
    movq 208(%rsp), %rax
    vmovdqu (%rax), %ymm2
    vmovdqu (%r12), %ymm3
    vpcmpeqb %ymm3, %ymm2, %ymm0
    vpmovmskb %ymm0, %eax
    movq %rax, 32(%rsp)
    cmpl $-1, %eax
jne .LBB43
.LBB42:
    addq $32, 208(%rsp)
    leaq 32(%r12), %rax
    movq %rax, %r12
    movq 208(%rsp), %rdi
    addq $31, %rdi
    cmpq %rbp, %rdi
jb .LBB40
    jmp .LBB14
.LBB43:
    movl 32(%rsp), %eax
    xorq $-1, %rax
    tzcntl %eax, %eax
    movl %eax, %edx
    movq %rdx, %rax
    addq 208(%rsp), %rax
    movq %rax, 24(%rsp)
    leaq (%r12, %rdx, 1), %r8
    movq %rax, %rbx
    movq %r8, %r14
    jmp .LBB15
.LBB44:
    movq 208(%rsp), %rbx
    movq %r12, %r14
    jmp .LBB15
.p2align 4,,10
.p2align 3
.LBB45:
    movzbl (%r15, %r12), %eax
    movb %al, (%r14)
    leaq 1(%r12), %rax
    movq %rax, 24(%rsp)
    leaq 1(%r14), %rax
    movq %rax, %r14
    movq 24(%rsp), %r12
    cmpq %r13, %r12
jb .LBB45
    jmp .LBB37
.LBB46:
    movzbl 56(%rsp), %edx
    movq 216(%rsp), %rcx
    movzbl (%rcx), %eax
    orl %eax, %edx
    movb %dl, (%rcx)
    movq %r14, %r15
    jmp .LBB32
.LBB47:
    movq 192(%rsp), %rdi
    movq %r15, %rsi
    movq %r11, %rdx
    call memmove@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movq 192(%rsp), %rcx
    movq 48(%rsp), %rax
    addq %rcx, %rax
    movq %rax, 192(%rsp)
    jmp .LBB27
.LBB48:
    movl 48(%rsp), %edi
    shll $4, %edi
    movq 216(%rsp), %rcx
    movb %dil, (%rcx)
    jmp .LBB23
.LBB49:
    leaq 1(%rsi), %rdx
    subq %r15, %rsi
    sarq $6, %rsi
    addq %rsi, %rdx
    movq %rdx, 24(%rsp)
    movq %rdx, %r12
    movq 216(%rsp), %r13
    movq %r15, 168(%rsp)
    jmp .LBB33
.LBB50:
    movq 40(%rsp), %rdi
    movq %r15, %rsi
    movq %r10, %rdx
    call memmove@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movq 40(%rsp), %rcx
    addq %rcx, %r14
    movq %r14, 160(%rsp)
    jmp .LBB38
.LBB51:
    leaq hash_table(%rip), %rdi
    xorl %esi, %esi
    movq %r12, %rdx
    call memset@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    jmp .LBB7
.LBB52:
    movl %r8d, %r10d
    shrl $24, %r10d
    movzbl %r10b, %esi
    jmp .LBB4
.LBB53:
    movq $0, 152(%rsp)
    movq $0, 144(%rsp)
.LBB54:
    movl $0, %eax
    cmpl $24, %eax
jb .LBB5
.LBB55:
    leaq .Lstr0(%rip), %rdi
    movq 144(%rsp), %rsi
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    vzeroupper
    addq $232, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

.section .rodata
.Lstr0:
    .byte 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 0
.Lstr1:
    .byte 37, 48, 49, 54, 108, 108, 120, 10, 0

.section .rodata
.align 16
.type sip24_valid.vectors.0, @object
.size sip24_valid.vectors.0, 512
sip24_valid.vectors.0:
    .byte 49
    .byte 14
    .byte 14
    .byte 221
    .byte 71
    .byte 219
    .byte 111
    .byte 114
    .byte 253
    .byte 103
    .byte 220
    .byte 147
    .byte 197
    .byte 57
    .byte 248
    .byte 116
    .byte 90
    .byte 79
    .byte 169
    .byte 217
    .byte 9
    .byte 128
    .byte 108
    .byte 13
    .byte 45
    .byte 126
    .byte 251
    .byte 215
    .byte 150
    .byte 102
    .byte 103
    .byte 133
    .byte 183
    .byte 135
    .byte 113
    .byte 39
    .byte 224
    .byte 148
    .byte 39
    .byte 207
    .byte 141
    .byte 166
    .byte 153
    .byte 205
    .byte 100
    .byte 85
    .byte 118
    .byte 24
    .byte 206
    .byte 227
    .byte 254
    .byte 88
    .byte 110
    .byte 70
    .byte 201
    .byte 203
    .byte 55
    .byte 209
    .byte 1
    .byte 139
    .byte 245
    .zero 1
    .byte 2
    .byte 171
    .byte 98
    .byte 36
    .byte 147
    .byte 154
    .byte 121
    .byte 245
    .byte 245
    .byte 147
    .byte 176
    .byte 228
    .byte 169
    .byte 11
    .byte 223
    .byte 130
    .zero 1
    .byte 158
    .byte 243
    .byte 185
    .byte 221
    .byte 148
    .byte 197
    .byte 187
    .byte 93
    .byte 122
    .byte 167
    .byte 173
    .byte 107
    .byte 34
    .byte 70
    .byte 47
    .byte 179
    .byte 244
    .byte 251
    .byte 229
    .byte 14
    .byte 134
    .byte 188
    .byte 143
    .byte 30
    .byte 117
    .byte 144
    .byte 61
    .byte 132
    .byte 192
    .byte 39
    .byte 86
    .byte 234
    .byte 20
    .byte 238
    .byte 242
    .byte 122
    .byte 142
    .byte 144
    .byte 202
    .byte 35
    .byte 247
    .byte 229
    .byte 69
    .byte 190
    .byte 73
    .byte 97
    .byte 202
    .byte 41
    .byte 161
    .byte 219
    .byte 155
    .byte 194
    .byte 87
    .byte 127
    .byte 204
    .byte 42
    .byte 63
    .byte 148
    .byte 71
    .byte 190
    .byte 44
    .byte 245
    .byte 233
    .byte 154
    .byte 105
    .byte 156
    .byte 211
    .byte 141
    .byte 150
    .byte 240
    .byte 179
    .byte 193
    .byte 75
    .byte 189
    .byte 97
    .byte 121
    .byte 167
    .byte 29
    .byte 201
    .byte 109
    .byte 187
    .byte 152
    .byte 238
    .byte 162
    .byte 26
    .byte 242
    .byte 92
    .byte 214
    .byte 190
    .byte 199
    .byte 103
    .byte 59
    .byte 46
    .byte 176
    .byte 203
    .byte 242
    .byte 208
    .byte 136
    .byte 62
    .byte 163
    .byte 227
    .byte 149
    .byte 103
    .byte 83
    .byte 147
    .byte 200
    .byte 206
    .byte 92
    .byte 205
    .byte 140
    .byte 3
    .byte 12
    .byte 168
    .byte 148
    .byte 175
    .byte 73
    .byte 246
    .byte 198
    .byte 80
    .byte 173
    .byte 184
    .byte 234
    .byte 184
    .byte 133
    .byte 138
    .byte 222
    .byte 146
    .byte 225
    .byte 188
    .byte 243
    .byte 21
    .byte 187
    .byte 91
    .byte 184
    .byte 53
    .byte 216
    .byte 23
    .byte 173
    .byte 207
    .byte 107
    .byte 7
    .byte 99
    .byte 97
    .byte 46
    .byte 47
    .byte 165
    .byte 201
    .byte 29
    .byte 167
    .byte 172
    .byte 170
    .byte 77
    .byte 222
    .byte 113
    .byte 101
    .byte 149
    .byte 135
    .byte 102
    .byte 80
    .byte 162
    .byte 166
    .byte 40
    .byte 239
    .byte 73
    .byte 92
    .byte 83
    .byte 163
    .byte 135
    .byte 173
    .byte 66
    .byte 195
    .byte 65
    .byte 216
    .byte 250
    .byte 146
    .byte 216
    .byte 50
    .byte 206
    .byte 124
    .byte 242
    .byte 114
    .byte 47
    .byte 81
    .byte 39
    .byte 113
    .byte 227
    .byte 120
    .byte 89
    .byte 249
    .byte 70
    .byte 35
    .byte 243
    .byte 167
    .byte 56
    .byte 18
    .byte 5
    .byte 187
    .byte 26
    .byte 176
    .byte 224
    .byte 18
    .byte 174
    .byte 151
    .byte 161
    .byte 15
    .byte 212
    .byte 52
    .byte 224
    .byte 21
    .byte 180
    .byte 163
    .byte 21
    .byte 8
    .byte 190
    .byte 255
    .byte 77
    .byte 49
    .byte 129
    .byte 57
    .byte 98
    .byte 41
    .byte 240
    .byte 144
    .byte 121
    .byte 2
    .byte 77
    .byte 12
    .byte 244
    .byte 158
    .byte 229
    .byte 212
    .byte 220
    .byte 202
    .byte 92
    .byte 115
    .byte 51
    .byte 106
    .byte 118
    .byte 216
    .byte 191
    .byte 154
    .byte 208
    .byte 167
    .byte 4
    .byte 83
    .byte 107
    .byte 169
    .byte 62
    .byte 14
    .byte 146
    .byte 89
    .byte 88
    .byte 252
    .byte 214
    .byte 66
    .byte 12
    .byte 173
    .byte 169
    .byte 21
    .byte 194
    .byte 155
    .byte 200
    .byte 6
    .byte 115
    .byte 24
    .byte 149
    .byte 43
    .byte 121
    .byte 243
    .byte 188
    .byte 10
    .byte 166
    .byte 212
    .byte 242
    .byte 29
    .byte 242
    .byte 228
    .byte 29
    .byte 69
    .byte 53
    .byte 249
    .byte 135
    .byte 87
    .byte 117
    .byte 25
    .byte 4
    .byte 143
    .byte 83
    .byte 169
    .byte 16
    .byte 165
    .byte 108
    .byte 245
    .byte 223
    .byte 205
    .byte 154
    .byte 219
    .byte 235
    .byte 117
    .byte 9
    .byte 92
    .byte 205
    .byte 152
    .byte 108
    .byte 208
    .byte 81
    .byte 169
    .byte 203
    .byte 158
    .byte 203
    .byte 163
    .byte 18
    .byte 230
    .byte 150
    .byte 175
    .byte 173
    .byte 252
    .byte 44
    .byte 230
    .byte 102
    .byte 199
    .byte 114
    .byte 254
    .byte 82
    .byte 151
    .byte 90
    .byte 67
    .byte 100
    .byte 238
    .byte 90
    .byte 22
    .byte 69
    .byte 178
    .byte 118
    .byte 213
    .byte 146
    .byte 161
    .byte 178
    .byte 116
    .byte 203
    .byte 142
    .byte 191
    .byte 135
    .byte 135
    .byte 10
    .byte 111
    .byte 155
    .byte 180
    .byte 32
    .byte 61
    .byte 231
    .byte 179
    .byte 129
    .byte 234
    .byte 236
    .byte 178
    .byte 163
    .byte 11
    .byte 34
    .byte 168
    .byte 127
    .byte 153
    .byte 36
    .byte 164
    .byte 60
    .byte 193
    .byte 49
    .byte 87
    .byte 36
    .byte 189
    .byte 131
    .byte 141
    .byte 58
    .byte 175
    .byte 191
    .byte 141
    .byte 183
    .byte 11
    .byte 26
    .byte 42
    .byte 50
    .byte 101
    .byte 213
    .byte 26
    .byte 234
    .byte 19
    .byte 80
    .byte 121
    .byte 163
    .byte 35
    .byte 28
    .byte 230
    .byte 96
    .byte 147
    .byte 43
    .byte 40
    .byte 70
    .byte 228
    .byte 215
    .byte 6
    .byte 102
    .byte 225
    .byte 145
    .byte 95
    .byte 92
    .byte 177
    .byte 236
    .byte 164
    .byte 108
    .byte 243
    .byte 37
    .byte 150
    .byte 92
    .byte 161
    .byte 109
    .byte 98
    .byte 159
    .byte 87
    .byte 95
    .byte 242
    .byte 142
    .byte 96
    .byte 56
    .byte 27
    .byte 229
    .byte 114
    .byte 69
    .byte 6
    .byte 235
    .byte 76
    .byte 50
    .byte 138
    .byte 149

.text
.p2align 4
.type sip24_init, @function
sip24_init:
.cfi_startproc
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movq (%rsi), %rax
    movabsq $8317987319222330741, %rcx
    xorq %rcx, %rax
    movq %rax, (%rdi)
    movq 8(%rsi), %rax
    movabsq $7237128888997146477, %rcx
    xorq %rcx, %rax
    movq %rax, 8(%rdi)
    movq (%rsi), %rax
    movabsq $7816392313619706465, %rcx
    xorq %rcx, %rax
    movq %rax, 16(%rdi)
    movq 8(%rsi), %rax
    movabsq $8387220255154660723, %rcx
    xorq %rcx, %rax
    movq %rax, 24(%rdi)
    leaq 32(%rdi), %rax
    movq %rax, 40(%rdi)
    movq $0, 48(%rdi)
    movq %rdi, %rax
    ret
.cfi_endproc
.size sip24_init, .-sip24_init

.p2align 4
.type sip24_update, @function
sip24_update:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r14
    .cfi_def_cfa_offset 32
    .cfi_offset %r14, -32
    pushq %r15
    .cfi_def_cfa_offset 40
    .cfi_offset %r15, -40
    pushq %rbp
    .cfi_def_cfa_offset 48
    .cfi_offset %rbp, -48
    subq $40, %rsp
    .cfi_def_cfa_offset 88
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    leaq (%rsi, %rdx, 1), %r9
    leaq 40(%rdi), %r10
    leaq 32(%rdi), %r14
.p2align 4,,10
.p2align 3
.LBB2:
.LBB3:
    cmpq %r9, %rsi
jae .LBB6
.p2align 4,,10
.p2align 3
.LBB4:
    cmpq %r10, (%r10)
jae .LBB6
.LBB5:
    movq (%r10), %r8
    leaq 1(%r8), %rax
    movq %rax, (%r10)
    movzbl (%rsi), %eax
    movb %al, (%r8)
    addq $1, %rsi
    cmpq %r9, %rsi
jb .LBB4
.LBB6:
    cmpq %r10, (%r10)
jb .LBB9
.LBB7:
    movq (%r14), %r8
    movq 24(%rdi), %r15
    xorq %r8, %r15
    movq 8(%rdi), %rbp
    movq (%rdi), %rbx
    leaq (%rbx, %rbp, 1), %r12
    rorxq $51, %rbp, %rbp
    xorq %r12, %rbp
    rorxq $32, %r12, %r12
    movq 16(%rdi), %rbx
    addq %r15, %rbx
    rorxq $48, %r15, %r15
    xorq %rbx, %r15
    addq %r15, %r12
    rorxq $43, %r15, %r15
    xorq %r12, %r15
    addq %rbp, %rbx
    rorxq $47, %rbp, %rbp
    xorq %rbx, %rbp
    rorxq $32, %rbx, %rbx
    addq %rbp, %r12
    rorxq $51, %rbp, %rbp
    xorq %r12, %rbp
    rorxq $32, %r12, %r12
    addq %r15, %rbx
    rorxq $48, %r15, %r15
    xorq %rbx, %r15
    addq %r15, %r12
    rorxq $43, %r15, %r15
    xorq %r12, %r15
    movq %r15, 24(%rdi)
    addq %rbp, %rbx
    rorxq $47, %rbp, %rbp
    movq %rbp, %rax
    xorq %rbx, %rax
    movq %rax, 8(%rdi)
    rorxq $32, %rbx, %rax
    movq %rax, 16(%rdi)
    xorq %r8, %r12
    movq %r12, (%rdi)
    movq %r14, (%r10)
    addq $8, 48(%rdi)
    cmpq %r9, %rsi
jae .LBB9
.LBB8:
    jmp .LBB2
.LBB9:
    movq %rdi, %rax
    addq $40, %rsp
    .cfi_def_cfa_offset 48
    popq %rbp
    .cfi_def_cfa_offset 40
    popq %r15
    .cfi_def_cfa_offset 32
    popq %r14
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size sip24_update, .-sip24_update

.p2align 4
.type sip24_final, @function
sip24_final:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r13
    .cfi_def_cfa_offset 24
    .cfi_offset %r13, -24
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movq %rdi, %rbx
    movq 40(%rbx), %r10
    leaq 32(%rbx), %r8
    subq %r8, %r10
    movsbl %r10b, %r9d
    movq 48(%rbx), %rsi
    movsbq %r9b, %r11
    addq %r11, %rsi
    shlq $56, %rsi
    movsbq %r9b, %r10
    movslq %r10d, %rax
    cmpq $8, %rax
    jae .LBB18
    leaq .Ljt_0(%rip), %rcx
    movslq (%rcx,%rax,4), %rdx
    addq %rcx, %rdx
    jmpq *%rdx
.section .rodata
.align 4
.Ljt_0:
    .long .LBB17 - .Ljt_0
    .long .LBB16 - .Ljt_0
    .long .LBB15 - .Ljt_0
    .long .LBB14 - .Ljt_0
    .long .LBB13 - .Ljt_0
    .long .LBB12 - .Ljt_0
    .long .LBB11 - .Ljt_0
    .long .LBB19 - .Ljt_0
.section .text,"ax",@progbits
.LBB11:
    movq %rsi, %r8
    jmp .LBB20
.LBB12:
    movq %rsi, %r9
    jmp .LBB21
.LBB13:
    movq %rsi, %rdi
    jmp .LBB22
.LBB14:
    movq %rsi, %r11
    jmp .LBB23
.LBB15:
    movq %rsi, %r10
    jmp .LBB24
.LBB16:
    movq %rsi, %r8
    jmp .LBB25
.LBB17:
    movq %rsi, %r9
    jmp .LBB26
.LBB18:
    movq %rsi, %rdi
    jmp .LBB27
.LBB19:
    movzbl 38(%rbx), %r10d
    shlq $48, %r10
    orq %r10, %rsi
    movq %rsi, %r8
.LBB20:
    movzbl 37(%rbx), %esi
    shlq $40, %rsi
    orq %r8, %rsi
    movq %rsi, %r9
.LBB21:
    movzbl 36(%rbx), %r8d
    shlq $32, %r8
    orq %r9, %r8
    movq %r8, %rdi
.LBB22:
    movzbl 35(%rbx), %esi
    shlq $24, %rsi
    orq %rdi, %rsi
    movq %rsi, %r11
.LBB23:
    movzbl 34(%rbx), %r9d
    shlq $16, %r9
    orq %r11, %r9
    movq %r9, %r10
.LBB24:
    movzbl 33(%rbx), %esi
    shlq $8, %rsi
    orq %r10, %rsi
    movq %rsi, %r8
.LBB25:
    movzbl 32(%rbx), %edi
    orq %r8, %rdi
    movq %rdi, %r9
.LBB26:
    movq %r9, %rdi
.LBB27:
    movq 24(%rbx), %r11
    xorq %rdi, %r11
    movq 8(%rbx), %r8
    movq (%rbx), %r9
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    movq 16(%rbx), %r13
    leaq (%r13, %r11, 1), %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    rorxq $32, %r10, %r10
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    addq %r11, %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    rorxq $32, %r10, %r10
    xorq %rdi, %r9
    xorq $255, %r10
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    addq %r11, %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    rorxq $32, %r10, %r10
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    addq %r11, %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    rorxq $32, %r10, %r10
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    addq %r11, %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    rorxq $32, %r10, %r10
    addq %r8, %r9
    rorxq $51, %r8, %r8
    xorq %r9, %r8
    rorxq $32, %r9, %r9
    addq %r11, %r10
    rorxq $48, %r11, %r11
    xorq %r10, %r11
    addq %r11, %r9
    movq %r9, (%rbx)
    rorxq $43, %r11, %r11
    xorq %r9, %r11
    movq %r11, 24(%rbx)
    addq %r8, %r10
    rorxq $47, %r8, %r8
    xorq %r10, %r8
    movq %r8, 8(%rbx)
    rorxq $32, %r10, %r10
    movq %r10, 16(%rbx)
    xorq %r8, %r9
    xorq %r10, %r9
    xorq %r11, %r9
    movq %r9, %rax
    popq %r13
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size sip24_final, .-sip24_final

.p2align 4
.type siphash24, @function
siphash24:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $120, %rsp
    .cfi_def_cfa_offset 176
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movq %rdi, %rbx
    movq %rsi, %r12
    movq %rdx, %r13
    vpxor %ymm0, %ymm0, %ymm0
    vmovdqu %ymm0, 56(%rsp)
    movq $0, 88(%rsp)
    movq $0, 56(%rsp)
    movq $0, 64(%rsp)
    movq $0, 72(%rsp)
    movq $0, 80(%rsp)
    movb $0, 88(%rsp)
    movq $0, 96(%rsp)
    movq $0, 104(%rsp)
    movq (%rdx), %rax
    movabsq $8317987319222330741, %rcx
    xorq %rcx, %rax
    movq %rax, 56(%rsp)
    movq 8(%rdx), %rax
    movabsq $7237128888997146477, %rcx
    xorq %rcx, %rax
    movq %rax, 64(%rsp)
    movq (%rdx), %rax
    movabsq $7816392313619706465, %rcx
    xorq %rcx, %rax
    movq %rax, 72(%rsp)
    movq 8(%rdx), %rax
    movabsq $8387220255154660723, %rcx
    xorq %rcx, %rax
    movq %rax, 80(%rsp)
    leaq 88(%rsp), %rax
    movq %rax, 96(%rsp)
    movq $0, 104(%rsp)
    leaq 56(%rsp), %rdi
    movq %rbx, %rsi
    movq %r12, %rdx
    call sip24_update
    movq %rax, %r11
    movq 40(%r11), %r8
    leaq 32(%r11), %r9
    subq %r9, %r8
    movsbl %r8b, %edi
    movq 48(%r11), %r10
    movsbq %dil, %r8
    addq %r8, %r10
    shlq $56, %r10
    movsbq %dil, %r9
    movslq %r9d, %rax
    cmpq $8, %rax
    jae .LBB36
    leaq .Ljt_1(%rip), %rcx
    movslq (%rcx,%rax,4), %rdx
    addq %rcx, %rdx
    jmpq *%rdx
.section .rodata
.align 4
.Ljt_1:
    .long .LBB35 - .Ljt_1
    .long .LBB34 - .Ljt_1
    .long .LBB33 - .Ljt_1
    .long .LBB32 - .Ljt_1
    .long .LBB31 - .Ljt_1
    .long .LBB30 - .Ljt_1
    .long .LBB29 - .Ljt_1
    .long .LBB37 - .Ljt_1
.section .text,"ax",@progbits
.LBB29:
    movq %r10, %rdi
    jmp .LBB38
.LBB30:
    movq %r10, %rsi
    jmp .LBB39
.LBB31:
    movq %r10, %r8
    jmp .LBB40
.LBB32:
    movq %r10, %r9
    jmp .LBB41
.LBB33:
    movq %r10, %rdi
    jmp .LBB42
.LBB34:
    movq %r10, %rsi
    jmp .LBB43
.LBB35:
    movq %r10, %r8
    jmp .LBB44
.LBB36:
    movq %r10, %r9
    jmp .LBB45
.LBB37:
    movzbl 38(%r11), %r8d
    shlq $48, %r8
    orq %r8, %r10
    movq %r10, %rdi
.LBB38:
    movzbl 37(%r11), %r10d
    shlq $40, %r10
    orq %rdi, %r10
    movq %r10, %rsi
.LBB39:
    movzbl 36(%r11), %edi
    shlq $32, %rdi
    orq %rsi, %rdi
    movq %rdi, %r8
.LBB40:
    movzbl 35(%r11), %r10d
    shlq $24, %r10
    orq %r8, %r10
    movq %r10, %r9
.LBB41:
    movzbl 34(%r11), %r10d
    shlq $16, %r10
    orq %r9, %r10
    movq %r10, %rdi
.LBB42:
    movzbl 33(%r11), %r10d
    shlq $8, %r10
    orq %rdi, %r10
    movq %r10, %rsi
.LBB43:
    movzbl 32(%r11), %edi
    orq %rsi, %rdi
    movq %rdi, %r8
.LBB44:
    movq %r8, %r9
.LBB45:
    leaq 24(%r11), %rsi
    movq (%rsi), %r10
    xorq %r9, %r10
    movq 8(%r11), %rdi
    movq (%r11), %r8
    addq %rdi, %r8
    leaq 8(%r11), %r14
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    leaq 16(%r11), %r15
    movq (%r15), %rbp
    leaq (%rbp, %r10, 1), %rdx
    rorxq $48, %r10, %r10
    xorq %rdx, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %rdx
    rorxq $47, %rdi, %rdi
    xorq %rdx, %rdi
    rorxq $32, %rdx, %rdx
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %rdx
    rorxq $48, %r10, %r10
    xorq %rdx, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %rdx
    rorxq $47, %rdi, %rdi
    xorq %rdx, %rdi
    rorxq $32, %rdx, %rdx
    xorq %r9, %r8
    movq %rdx, %r9
    xorq $255, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    movq %r8, (%r11)
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    movq %r10, (%rsi)
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    movq %rdi, (%r14)
    rorxq $32, %r9, %r9
    movq %r9, (%r15)
    xorq %rdi, %r8
    xorq %r9, %r8
    xorq %r10, %r8
    movq %r8, %rax
    vzeroupper
    addq $120, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size siphash24, .-siphash24

.globl expat_siphash24
.p2align 4
.type expat_siphash24, @function
expat_siphash24:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $120, %rsp
    .cfi_def_cfa_offset 176
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movq %rdi, %rbx
    movq %rsi, %r12
    movq %rdx, %r13
    vpxor %ymm0, %ymm0, %ymm0
    vmovdqu %ymm0, 56(%rsp)
    movq $0, 88(%rsp)
    movq $0, 56(%rsp)
    movq $0, 64(%rsp)
    movq $0, 72(%rsp)
    movq $0, 80(%rsp)
    movb $0, 88(%rsp)
    movq $0, 96(%rsp)
    movq $0, 104(%rsp)
    movq (%rdx), %rax
    movabsq $8317987319222330741, %rcx
    xorq %rcx, %rax
    movq %rax, 56(%rsp)
    movq 8(%rdx), %rax
    movabsq $7237128888997146477, %rcx
    xorq %rcx, %rax
    movq %rax, 64(%rsp)
    movq (%rdx), %rax
    movabsq $7816392313619706465, %rcx
    xorq %rcx, %rax
    movq %rax, 72(%rsp)
    movq 8(%rdx), %rax
    movabsq $8387220255154660723, %rcx
    xorq %rcx, %rax
    movq %rax, 80(%rsp)
    leaq 88(%rsp), %rax
    movq %rax, 96(%rsp)
    movq $0, 104(%rsp)
    leaq 56(%rsp), %rdi
    movq %rbx, %rsi
    movq %r12, %rdx
    call sip24_update
    movq %rax, %r11
    movq 40(%r11), %r8
    leaq 32(%r11), %r9
    subq %r9, %r8
    movsbl %r8b, %edi
    movq 48(%r11), %r10
    movsbq %dil, %r8
    addq %r8, %r10
    shlq $56, %r10
    movsbq %dil, %r9
    movslq %r9d, %rax
    cmpq $8, %rax
    jae .LBB54
    leaq .Ljt_2(%rip), %rcx
    movslq (%rcx,%rax,4), %rdx
    addq %rcx, %rdx
    jmpq *%rdx
.section .rodata
.align 4
.Ljt_2:
    .long .LBB53 - .Ljt_2
    .long .LBB52 - .Ljt_2
    .long .LBB51 - .Ljt_2
    .long .LBB50 - .Ljt_2
    .long .LBB49 - .Ljt_2
    .long .LBB48 - .Ljt_2
    .long .LBB47 - .Ljt_2
    .long .LBB55 - .Ljt_2
.section .text,"ax",@progbits
.LBB47:
    movq %r10, %rdi
    jmp .LBB56
.LBB48:
    movq %r10, %rsi
    jmp .LBB57
.LBB49:
    movq %r10, %r8
    jmp .LBB58
.LBB50:
    movq %r10, %r9
    jmp .LBB59
.LBB51:
    movq %r10, %rdi
    jmp .LBB60
.LBB52:
    movq %r10, %rsi
    jmp .LBB61
.LBB53:
    movq %r10, %r8
    jmp .LBB62
.LBB54:
    movq %r10, %r9
    jmp .LBB63
.LBB55:
    movzbl 38(%r11), %r8d
    shlq $48, %r8
    orq %r8, %r10
    movq %r10, %rdi
.LBB56:
    movzbl 37(%r11), %r10d
    shlq $40, %r10
    orq %rdi, %r10
    movq %r10, %rsi
.LBB57:
    movzbl 36(%r11), %edi
    shlq $32, %rdi
    orq %rsi, %rdi
    movq %rdi, %r8
.LBB58:
    movzbl 35(%r11), %r10d
    shlq $24, %r10
    orq %r8, %r10
    movq %r10, %r9
.LBB59:
    movzbl 34(%r11), %r10d
    shlq $16, %r10
    orq %r9, %r10
    movq %r10, %rdi
.LBB60:
    movzbl 33(%r11), %r10d
    shlq $8, %r10
    orq %rdi, %r10
    movq %r10, %rsi
.LBB61:
    movzbl 32(%r11), %edi
    orq %rsi, %rdi
    movq %rdi, %r8
.LBB62:
    movq %r8, %r9
.LBB63:
    leaq 24(%r11), %rsi
    movq (%rsi), %r10
    xorq %r9, %r10
    movq 8(%r11), %rdi
    movq (%r11), %r8
    addq %rdi, %r8
    leaq 8(%r11), %r14
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    leaq 16(%r11), %r15
    movq (%r15), %rbp
    leaq (%rbp, %r10, 1), %rdx
    rorxq $48, %r10, %r10
    xorq %rdx, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %rdx
    rorxq $47, %rdi, %rdi
    xorq %rdx, %rdi
    rorxq $32, %rdx, %rdx
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %rdx
    rorxq $48, %r10, %r10
    xorq %rdx, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %rdx
    rorxq $47, %rdi, %rdi
    xorq %rdx, %rdi
    rorxq $32, %rdx, %rdx
    xorq %r9, %r8
    movq %rdx, %r9
    xorq $255, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    rorxq $32, %r9, %r9
    addq %rdi, %r8
    rorxq $51, %rdi, %rdi
    xorq %r8, %rdi
    rorxq $32, %r8, %r8
    addq %r10, %r9
    rorxq $48, %r10, %r10
    xorq %r9, %r10
    addq %r10, %r8
    movq %r8, (%r11)
    rorxq $43, %r10, %r10
    xorq %r8, %r10
    movq %r10, (%rsi)
    addq %rdi, %r9
    rorxq $47, %rdi, %rdi
    xorq %r9, %rdi
    movq %rdi, (%r14)
    rorxq $32, %r9, %r9
    movq %r9, (%r15)
    xorq %rdi, %r8
    xorq %r9, %r8
    xorq %r10, %r8
    movq %r8, %rax
    vzeroupper
    addq $120, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size expat_siphash24, .-expat_siphash24

.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $424, %rsp
    .cfi_def_cfa_offset 480
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movabsq $506097522914230528, %rax
    movq %rax, 256(%rsp)
    movabsq $1084818905618843912, %rax
    movq %rax, 264(%rsp)
    movl $376, %r10d
    xorl %ebx, %ebx
.LBB65:
    cmpq $144, %rbx
jae .LBB67
.p2align 4,,10
.p2align 3
.LBB66:
    imull $1664525, %r10d, %r8d
    leal 1013904223(%r8), %r10d
    movq %rbx, %r9
    movl %r10d, %esi
    shrl $24, %esi
    movb %sil, 272(%rsp, %r9)
    addq $1, %rbx
    cmpq $144, %rbx
jb .LBB66
.LBB67:
    leaq sip24_valid.vectors.0(%rip), %r12
    movq .Lstr0(%rip), %rax
    movq %rax, 120(%rsp)
    movq .Lstr0+8(%rip), %rax
    movq %rax, 128(%rsp)
    xorl %r13d, %r13d
.LBB68:
    cmpq $64, %r13
jae .LBB71
.p2align 4,,10
.p2align 3
.LBB69:
    movq %r13, %r14
    movzbl %r13b, %r8d
    movb %r8b, 136(%rsp, %r14)
    leaq 136(%rsp), %rdi
    leaq 120(%rsp), %rdx
    movq %r13, %rsi
    call siphash24
    movq %rax, %r9
    cmpq (%r12, %r14, 8), %r9
jne .LBB85
.LBB70:
    addq $1, %r13
    cmpq $64, %r13
jb .LBB69
.LBB71:
    movl $1, %r11d
.LBB72:
    vpxor %ymm0, %ymm0, %ymm0
    vmovdqu %ymm0, 80(%rsp)
    vpxor %ymm0, %ymm0, %ymm0
    vmovdqu %ymm0, 32(%rsp)
    testl %r11d, %r11d
je .LBB84
.LBB73:
    xorl %r14d, %r14d
.LBB74:
    cmpq $128, %r14
ja .LBB80
.p2align 5,,15
.p2align 4
.LBB75:
    leaq 272(%rsp), %rdi
    leaq 256(%rsp), %rdx
    movq %r14, %rsi
    call expat_siphash24@PLT
    movq %rax, 8(%rsp)
    xorl %r13d, %r13d
.LBB76:
    cmpq %r14, %r13
ja .LBB79
.p2align 5,,15
.p2align 4
.LBB77:
    vmovdqu 80(%rsp), %ymm0
    vmovdqu %ymm0, 200(%rsp)
    movq $0, 232(%rsp)
    movq $0, 240(%rsp)
    movq $0, 248(%rsp)
    vmovdqu 32(%rsp), %ymm0
    vmovdqu %ymm0, 200(%rsp)
    movb $0, 232(%rsp)
    movq $0, 240(%rsp)
    movq $0, 248(%rsp)
    leaq 200(%rsp), %rdi
    leaq 256(%rsp), %rsi
    call sip24_init
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    leaq 200(%rsp), %rdi
    leaq 272(%rsp), %rsi
    movq %r13, %rdx
    call sip24_update
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    leaq 272(%rsp), %r11
    addq %r13, %r11
    movq %r14, %r10
    subq %r13, %r10
    leaq 200(%rsp), %rdi
    movq %r11, %rsi
    movq %r10, %rdx
    call sip24_update
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    leaq 200(%rsp), %rdi
    call sip24_final
    movq %rax, %r8
    cmpq 8(%rsp), %rax
jne .LBB84
.LBB78:
    addq $1, %r13
    cmpq %r14, %r13
jbe .LBB77
.LBB79:
    addq $1, %r14
    cmpq $128, %r14
jbe .LBB75
.LBB80:
    xorl %r15d, %r15d
    movabsq $-7046029254386353131, %rbp
.LBB81:
    cmpq $2000000, %r15
jae .LBB83
.p2align 4,,10
.p2align 3
.LBB82:
    movq %rbp, %r9
    shrq $32, %r9
    movq %r9, %r11
    andq $127, %r11
    movq %rbp, %rdi
    andq $7, %rdi
    movq %rbp, %rsi
    orq $1, %rsi
    movq 256(%rsp), %rdx
    leaq (%rdx, %rsi), %rax
    movq %rax, 256(%rsp)
    movq %rbp, %r10
    shrq $48, %r10
    movzbl %r10b, %r9d
    movq %r15, %rax
    andq $127, %rax
    movq %rax, %rsi
    movzbl 272(%rsp, %rsi), %eax
    xorl %eax, %r9d
    movzbl %r9b, %r8d
    movb %r8b, 272(%rsp, %rsi)
    movq %rdi, %r9
    leaq 272(%rsp), %rdi
    addq %r9, %rdi
    leaq 256(%rsp), %rdx
    movq %r11, %rsi
    call expat_siphash24@PLT
    xorq %rax, %rbp
    addq $1, %r15
    cmpq $2000000, %r15
jb .LBB82
.LBB83:
    leaq .Lstr1(%rip), %rdi
    movq %rbp, %rsi
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    vzeroupper
.L__lccc_epilogue_1:
    addq $424, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.LBB84:
    .cfi_def_cfa_offset 480
    movl $1, %eax
    vzeroupper
    jmp .L__lccc_epilogue_1
.LBB85:
    xorl %r11d, %r11d
    jmp .LBB72
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

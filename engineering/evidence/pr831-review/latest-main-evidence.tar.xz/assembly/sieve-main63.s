.section .rodata
.Lstr0:
    .byte 112, 114, 105, 109, 101, 115, 32, 117, 112, 32, 116, 111, 32, 37, 100, 58, 32, 37, 100, 10, 0

.section .bss
.align 16
.type sieve, @object
.size sieve, 10000001
sieve:
    .zero 10000001

.text
.globl count_primes
.p2align 4
.type count_primes, @function
count_primes:
.cfi_startproc
    subq $8, %rsp
    .cfi_def_cfa_offset 16
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    leaq sieve(%rip), %rdi
    movl $1, %esi
    movl $10000001, %edx
    call memset@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    leaq sieve(%rip), %r11
    movb $0, sieve+1(%rip)
    movb $0, (%r11)
    movl $2, %r10d
.p2align 4,,10
.p2align 3
.LBB1:
    movl %r10d, %r8d
    imull %r10d, %r8d
    cmpl $10000000, %r8d
jg .LBB7
.LBB2:
    movslq %r10d, %r9
    cmpb $0, (%r11, %r9)
je .LBB6
.LBB3:
    movslq %r8d, %rdx
    movslq %r10d, %r8
.LBB4:
    cmpq $10000000, %rdx
jg .LBB6
.p2align 4,,10
.p2align 3
.LBB5:
    movb $0, (%r11, %rdx)
    addq %r8, %rdx
    cmpq $10000000, %rdx
jle .LBB5
.LBB6:
    addl $1, %r10d
    jmp .LBB1
.LBB7:
    xorl %edi, %edi
    movl $2, %esi
.LBB8:
    cmpq $10000000, %rsi
jg .LBB10
.p2align 4,,10
.p2align 3
.LBB9:
    leal 1(%rdi), %r8d
    cmpb $0, (%r11, %rsi)
    cmovnel %r8d, %edi
    addq $1, %rsi
    cmpq $10000000, %rsi
jle .LBB9
.LBB10:
    movl %edi, %eax
    addq $8, %rsp
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size count_primes, .-count_primes

.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    subq $24, %rsp
    .cfi_def_cfa_offset 32
    # LCCC_VOLATILE_SLOT 16(%rsp)
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    call count_primes@PLT
    movl %eax, 16(%rsp)
    movslq 16(%rsp), %r11
    leaq .Lstr0(%rip), %rdi
    movl $10000000, %esi
    movq %r11, %rdx
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    addq $24, %rsp
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

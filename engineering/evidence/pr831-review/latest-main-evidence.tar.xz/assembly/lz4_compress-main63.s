.section .rodata
.Lstr0:
    .byte 37, 48, 49, 54, 108, 108, 120, 10, 0

.section .bss
.align 16
.type src_data, @object
.size src_data, 524352
src_data:
    .zero 524352
.align 16
.type dst_data, @object
.size dst_data, 1048576
dst_data:
    .zero 1048576
.align 16
.type hash_table, @object
.size hash_table, 65536
hash_table:
    .zero 65536

.text
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $216, %rsp
    .cfi_def_cfa_offset 272
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    leaq dst_data(%rip), %rax
    movq %rax, 72(%rsp)
    leaq src_data(%rip), %rax
    movq %rax, 64(%rsp)
    leaq 524288(%rax), %rbp
    movq 64(%rsp), %rax
    addq $524276, %rax
    movq %rax, 56(%rsp)
    movq 64(%rsp), %rax
    addq $1, %rax
    movq %rax, 48(%rsp)
    xorl %r11d, %r11d
    movl $1511734397, %r10d
.LBB1:
    cmpl $524288, %r11d
jb .LBB2
.LBB53:
    movq $0, 200(%rsp)
    movq $0, 192(%rsp)
    jmp .LBB54
.p2align 4,,10
.p2align 3
.LBB2:
    imull $1664525, %r10d, %r10d
    leal 1013904223(%r10), %r8d
    movl %r8d, %r9d
    andl $15, %r9d
    cmpl $6, %r9d
jae .LBB52
    cmpl $128, %r11d
jb .LBB52
.LBB3:
    leal -128(%r11), %edx
    movl %r8d, %r10d
    andl $63, %r10d
    addl %r10d, %edx
    leaq src_data(%rip), %rcx
    movzbl (%rcx, %rdx), %r14d
    jmp .LBB4
.LBB52:
    movl %r8d, %edi
    shrl $24, %edi
    movzbl %dil, %r14d
.LBB4:
    movl %r11d, %esi
    leaq src_data(%rip), %rcx
    movb %r14b, (%rcx, %rsi)
    addl $1, %r11d
    movq %r8, %r10
    cmpl $524288, %r11d
jb .LBB2
    jmp .LBB53
.LBB54:
    movl 200(%rsp), %eax
    cmpl $24, %eax
jae .LBB55
.p2align 5,,15
.p2align 4
.LBB5:
    jmp .LBB6
.LBB7:
    movq 48(%rsp), %r10
    movq 72(%rsp), %rax
    movq %rax, 184(%rsp)
    movq 64(%rsp), %r15
.LBB8:
    cmpq 56(%rsp), %r10
jae .LBB34
.p2align 5,,15
.p2align 4
.LBB9:
    movl (%r10), %r8d
    imull $-1640531535, %r8d, %r8d
    shrl $18, %r8d
    leaq hash_table(%rip), %rdi
    leaq (%rdi, %r8, 4), %rdi
    movl (%rdi), %esi
    leaq src_data(%rip), %rcx
    leaq (%rcx, %rsi), %rdx
    movq %r10, %r11
    subq 64(%rsp), %r11
    movl %r11d, (%rdi)
    cmpq %r10, %rdx
jae .LBB49
.LBB10:
    cmpq 64(%rsp), %rdx
jb .LBB49
.LBB11:
    movl (%rdx), %r11d
    cmpl (%r10), %r11d
jne .LBB49
.LBB12:
    movq %r10, %rax
    addq $4, %rax
    movq %rax, 176(%rsp)
    leaq 4(%rdx), %r12
    jmp .LBB13
.LBB15:
    cmpq %rbp, %rbx
jae .LBB18
.p2align 4,,10
.p2align 3
.LBB16:
    movzbl (%rbx), %r9d
    cmpb (%r14), %r9b
jne .LBB18
.LBB17:
    addq $1, %rbx
    addq $1, %r14
    cmpq %rbp, %rbx
jb .LBB16
.LBB18:
    movq %r14, %rsi
    subq %rdx, %rsi
    leaq -4(%rsi), %rax
    movq %rax, 40(%rsp)
    movq 184(%rsp), %rax
    addq $1, %rax
    movq %rax, 160(%rsp)
    subq %r15, %r10
    movl %r10d, %eax
    movq %rax, 32(%rsp)
    cmpl $15, %r10d
jb .LBB48
.LBB19:
    movq 184(%rsp), %rcx
    movb $240, (%rcx)
    movq 160(%rsp), %r12
    movl 32(%rsp), %r13d
    subl $15, %r13d
.LBB20:
    cmpl $255, %r13d
jb .LBB22
.p2align 4,,10
.p2align 3
.LBB21:
    movb $255, (%r12)
    subl $255, %r13d
    leaq 1(%r12), %rax
    movq %rax, 16(%rsp)
    movq %rax, %r12
    cmpl $255, %r13d
jae .LBB21
.LBB22:
    movq %r12, %rax
    addq $1, %rax
    movq %rax, 160(%rsp)
    movb %r13b, (%r12)
    jmp .LBB23
.LBB48:
    movl 32(%rsp), %r10d
    shll $4, %r10d
    movq 184(%rsp), %rcx
    movb %r10b, (%rcx)
.LBB23:
    movl 32(%rsp), %r11d
    movq %r11, %r9
    movq 160(%rsp), %rdi
    subq %r15, %rdi
    subq $1, %r9
    cmpq %r9, %rdi
    movl %r11d, %r13d
ja .LBB47
.LBB24:
    xorl %r12d, %r12d
.LBB25:
    cmpq %r13, %r12
jb .LBB39
.LBB26:
    jmp .LBB27
.p2align 4,,10
.p2align 3
.LBB39:
    movzbl (%r15, %r12), %eax
    movq 160(%rsp), %rcx
    movb %al, (%rcx)
    leaq 1(%r12), %rax
    movq %rax, 16(%rsp)
    addq $1, 160(%rsp)
    movq 16(%rsp), %r12
    cmpq %r13, %r12
jb .LBB39
    jmp .LBB27
.LBB27:
    movq %rbx, %r8
    subq %r14, %r8
    movzwl %r8w, %r9d
    movq 160(%rsp), %rdi
    addq $1, %rdi
    movl %r9d, %esi
    movq 160(%rsp), %rcx
    movb %r9b, (%rcx)
    movq 160(%rsp), %r13
    addq $2, %r13
    sarl $8, %esi
    movb %sil, (%rdi)
    movl 40(%rsp), %r14d
    cmpl $15, %r14d
jb .LBB46
.LBB28:
    movq 184(%rsp), %rcx
    movzbl (%rcx), %r9d
    orl $15, %r9d
    movb %r9b, (%rcx)
    movq %r13, %r15
    movl %r14d, %r12d
    subl $15, %r12d
.LBB29:
    cmpl $255, %r12d
jb .LBB31
.p2align 4,,10
.p2align 3
.LBB30:
    movb $255, (%r15)
    leal -255(%r12), %eax
    movl %eax, 20(%rsp)
    leaq 1(%r15), %rax
    movq %rax, %r15
    movl 20(%rsp), %r12d
    cmpl $255, %r12d
jae .LBB30
.LBB31:
    leaq 1(%r15), %r14
    movb %r12b, (%r15)
    jmp .LBB32
.LBB46:
    movzbl 40(%rsp), %r8d
    movq 184(%rsp), %rcx
    movzbl (%rcx), %eax
    orl %eax, %r8d
    movb %r8b, (%rcx)
    movq %r13, %r14
.LBB32:
    movq %rbx, %r12
    movq %rbx, 136(%rsp)
    jmp .LBB33
.LBB49:
    leaq 1(%r10), %rsi
    subq %r15, %r10
    sarq $6, %r10
    addq %r10, %rsi
    movq %rsi, 16(%rsp)
    movq %rsi, %r12
    movq 184(%rsp), %r14
    movq %r15, 136(%rsp)
.LBB33:
    movq %r12, %r10
    movq %r14, 184(%rsp)
    movq 136(%rsp), %r15
    cmpq 56(%rsp), %r12
jb .LBB9
.LBB34:
    movq %rbp, %r10
    subq %r15, %r10
    movl %r10d, %r13d
    movq 184(%rsp), %rax
    addq $1, %rax
    movq %rax, 24(%rsp)
    movl %r10d, %r9d
    shll $4, %r9d
    cmpl $15, %r10d
    movl $240, %edi
    cmovbl %r9d, %edi
    movq 184(%rsp), %rcx
    movb %dil, (%rcx)
    movl %r13d, %r10d
    movq %r10, %rdx
    movq 24(%rsp), %r8
    subq %r15, %r8
    subq $1, %rdx
    cmpq %rdx, %r8
    movl %r13d, %r12d
ja .LBB50
.LBB35:
    movq 24(%rsp), %r13
    xorl %r14d, %r14d
.LBB36:
    cmpq %r12, %r14
jb .LBB45
.LBB37:
    movq %r13, 128(%rsp)
    jmp .LBB38
.p2align 4,,10
.p2align 3
.LBB45:
    movzbl (%r15, %r14), %eax
    movb %al, (%r13)
    leaq 1(%r14), %rax
    movq %rax, 16(%rsp)
    leaq 1(%r13), %rax
    movq %rax, %r13
    movq 16(%rsp), %r14
    cmpq %r12, %r14
jb .LBB45
    jmp .LBB37
.LBB38:
    movq 128(%rsp), %rdx
    subq 72(%rsp), %rdx
    movl %edx, %r8d
    movl %edx, %r9d
    shlq $32, %r9
    movzbl dst_data(%rip), %eax
    xorq %rax, %r9
    shrl $1, %r8d
    leaq dst_data(%rip), %rcx
    movzbl (%rcx, %r8), %edx
    shlq $16, %rdx
    xorq %rdx, %r9
    addq %r9, 192(%rsp)
    movl 200(%rsp), %eax
    imull $4099, %eax, %eax
    movl %eax, %r8d
    andq $524287, %r8
    leaq src_data(%rip), %rdi
    addq %r8, %rdi
    movzbl (%rdi), %esi
    xorl $85, %esi
    movb %sil, (%rdi)
    movl 200(%rsp), %eax
    addl $1, %eax
    movq %rax, 200(%rsp)
    cmpl $24, %eax
    jb .LBB6
.LBB55:
    leaq .Lstr0(%rip), %rdi
    movq 192(%rsp), %rsi
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    addq $216, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.LBB47:
    .cfi_def_cfa_offset 272
    movq 160(%rsp), %rdi
    movq %r15, %rsi
    movq %r11, %rdx
    call memmove@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movq 160(%rsp), %rcx
    movq 32(%rsp), %rax
    addq %rcx, %rax
    movq %rax, 160(%rsp)
    jmp .LBB27
.LBB50:
    movq 24(%rsp), %rdi
    movq %r15, %rsi
    movq %r10, %rdx
    call memmove@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movq 24(%rsp), %rcx
    addq %rcx, %r13
    movq %r13, 128(%rsp)
    jmp .LBB38
.LBB13:
    movq 176(%rsp), %r11
    addq $31, %r11
    cmpq %rbp, %r11
jb .LBB40
.LBB14:
    movq 176(%rsp), %rbx
    movq %r12, %r14
    jmp .LBB15
.p2align 5,,15
.p2align 4
.LBB40:
    leaq 31(%r12), %r8
    movq %r12, %r9
    orq $4095, %r9
    cmpq %r9, %r8
jbe .LBB41
.LBB44:
    movq 176(%rsp), %rbx
    movq %r12, %r14
    jmp .LBB15
.LBB41:
    movq 176(%rsp), %rax
    vmovdqu (%rax), %ymm2
    vmovdqu (%r12), %ymm3
    vpcmpeqb %ymm3, %ymm2, %ymm0
    vpmovmskb %ymm0, %eax
    movq %rax, 40(%rsp)
    cmpl $-1, %eax
je .LBB42
.LBB43:
    xorq $-1, %rax
    tzcntl %eax, %eax
    movl %eax, %edi
    movq %rdi, %rax
    addq 176(%rsp), %rax
    movq %rax, 16(%rsp)
    leaq (%r12, %rdi, 1), %rsi
    movq %rax, %rbx
    movq %rsi, %r14
    jmp .LBB15
.LBB42:
    addq $32, 176(%rsp)
    addq $32, %r12
    movq 176(%rsp), %r11
    addq $31, %r11
    cmpq %rbp, %r11
jb .LBB40
    jmp .LBB14
.LBB6:
    movl $16384, %eax
    subq $0, %rax
    leaq 0(,%rax,4), %r11
    testq %rax, %rax
je .LBB7
.LBB51:
    leaq hash_table(%rip), %rdi
    xorl %esi, %esi
    movq %r11, %rdx
    call memset@PLT
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    jmp .LBB7
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

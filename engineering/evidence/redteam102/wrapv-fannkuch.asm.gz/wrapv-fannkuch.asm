
/home/user/.cache/redteam94/performance97/native45/fannkuch/lccc/benchmark.bin:     file format elf64-x86-64


Disassembly of section .plt:

0000000000401890 <printf@plt-0x10>:
  401890:	ff 35 12 33 00 00    	push   0x3312(%rip)        # 404ba8 <_GLOBAL_OFFSET_TABLE_+0x8>
  401896:	ff 25 14 33 00 00    	jmp    *0x3314(%rip)        # 404bb0 <_GLOBAL_OFFSET_TABLE_+0x10>
  40189c:	90                   	nop
  40189d:	90                   	nop
  40189e:	90                   	nop
  40189f:	90                   	nop

00000000004018a0 <printf@plt>:
  4018a0:	ff 25 12 33 00 00    	jmp    *0x3312(%rip)        # 404bb8 <printf@GLIBC_2.2.5>
  4018a6:	68 00 00 00 00       	push   $0x0
  4018ab:	e9 e0 ff ff ff       	jmp    401890 <_fini+0xc>

Disassembly of section .text:

0000000000401480 <_start>:
  401480:	31 ed                	xor    %ebp,%ebp
  401482:	49 89 d1             	mov    %rdx,%r9
  401485:	5e                   	pop    %rsi
  401486:	48 89 e2             	mov    %rsp,%rdx
  401489:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
  40148d:	50                   	push   %rax
  40148e:	54                   	push   %rsp
  40148f:	45 31 c0             	xor    %r8d,%r8d
  401492:	31 c9                	xor    %ecx,%ecx
  401494:	48 c7 c7 80 15 40 00 	mov    $0x401580,%rdi
  40149b:	ff 15 ef 26 00 00    	call   *0x26ef(%rip)        # 403b90 <__libc_start_main@GLIBC_2.34>
  4014a1:	f4                   	hlt
  4014a2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  4014a9:	00 00 00 
  4014ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000004014b0 <_dl_relocate_static_pie>:
  4014b0:	c3                   	ret
	...

00000000004014c0 <deregister_tm_clones>:
  4014c0:	b8 d0 4b 40 00       	mov    $0x404bd0,%eax
  4014c5:	48 3d d0 4b 40 00    	cmp    $0x404bd0,%rax
  4014cb:	74 13                	je     4014e0 <deregister_tm_clones+0x20>
  4014cd:	b8 00 00 00 00       	mov    $0x0,%eax
  4014d2:	48 85 c0             	test   %rax,%rax
  4014d5:	74 09                	je     4014e0 <deregister_tm_clones+0x20>
  4014d7:	bf d0 4b 40 00       	mov    $0x404bd0,%edi
  4014dc:	ff e0                	jmp    *%rax
  4014de:	66 90                	xchg   %ax,%ax
  4014e0:	c3                   	ret
  4014e1:	0f 1f 40 00          	nopl   0x0(%rax)
  4014e5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4014ec:	00 00 00 00 

00000000004014f0 <register_tm_clones>:
  4014f0:	be d0 4b 40 00       	mov    $0x404bd0,%esi
  4014f5:	48 81 ee d0 4b 40 00 	sub    $0x404bd0,%rsi
  4014fc:	48 89 f0             	mov    %rsi,%rax
  4014ff:	48 c1 ee 3f          	shr    $0x3f,%rsi
  401503:	48 c1 f8 03          	sar    $0x3,%rax
  401507:	48 01 c6             	add    %rax,%rsi
  40150a:	48 d1 fe             	sar    $1,%rsi
  40150d:	74 11                	je     401520 <register_tm_clones+0x30>
  40150f:	b8 00 00 00 00       	mov    $0x0,%eax
  401514:	48 85 c0             	test   %rax,%rax
  401517:	74 07                	je     401520 <register_tm_clones+0x30>
  401519:	bf d0 4b 40 00       	mov    $0x404bd0,%edi
  40151e:	ff e0                	jmp    *%rax
  401520:	c3                   	ret
  401521:	0f 1f 40 00          	nopl   0x0(%rax)
  401525:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40152c:	00 00 00 00 

0000000000401530 <__do_global_dtors_aux>:
  401530:	f3 0f 1e fa          	endbr64
  401534:	80 3d 95 36 00 00 00 	cmpb   $0x0,0x3695(%rip)        # 404bd0 <__TMC_END__>
  40153b:	75 13                	jne    401550 <__do_global_dtors_aux+0x20>
  40153d:	55                   	push   %rbp
  40153e:	48 89 e5             	mov    %rsp,%rbp
  401541:	e8 7a ff ff ff       	call   4014c0 <deregister_tm_clones>
  401546:	c6 05 83 36 00 00 01 	movb   $0x1,0x3683(%rip)        # 404bd0 <__TMC_END__>
  40154d:	5d                   	pop    %rbp
  40154e:	c3                   	ret
  40154f:	90                   	nop
  401550:	c3                   	ret
  401551:	0f 1f 40 00          	nopl   0x0(%rax)
  401555:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40155c:	00 00 00 00 

0000000000401560 <frame_dummy>:
  401560:	f3 0f 1e fa          	endbr64
  401564:	eb 8a                	jmp    4014f0 <register_tm_clones>
	...

0000000000401580 <main>:
  401580:	53                   	push   %rbx
  401581:	41 54                	push   %r12
  401583:	41 55                	push   %r13
  401585:	41 56                	push   %r14
  401587:	41 57                	push   %r15
  401589:	55                   	push   %rbp
  40158a:	48 83 ec 38          	sub    $0x38,%rsp
  40158e:	c7 05 08 37 00 00 00 	movl   $0x0,0x3708(%rip)        # 404ca0 <maxflips>
  401595:	00 00 00 
  401598:	c7 05 02 37 00 00 00 	movl   $0x0,0x3702(%rip)        # 404ca4 <checksum>
  40159f:	00 00 00 
  4015a2:	4c 8d 1d 77 36 00 00 	lea    0x3677(%rip),%r11        # 404c20 <perm1>
  4015a9:	41 c7 03 00 00 00 00 	movl   $0x0,(%r11)
  4015b0:	c7 05 6a 36 00 00 01 	movl   $0x1,0x366a(%rip)        # 404c24 <perm1+0x4>
  4015b7:	00 00 00 
  4015ba:	c7 05 64 36 00 00 02 	movl   $0x2,0x3664(%rip)        # 404c28 <perm1+0x8>
  4015c1:	00 00 00 
  4015c4:	c7 05 5e 36 00 00 03 	movl   $0x3,0x365e(%rip)        # 404c2c <perm1+0xc>
  4015cb:	00 00 00 
  4015ce:	c7 05 58 36 00 00 04 	movl   $0x4,0x3658(%rip)        # 404c30 <perm1+0x10>
  4015d5:	00 00 00 
  4015d8:	c7 05 52 36 00 00 05 	movl   $0x5,0x3652(%rip)        # 404c34 <perm1+0x14>
  4015df:	00 00 00 
  4015e2:	c7 05 4c 36 00 00 06 	movl   $0x6,0x364c(%rip)        # 404c38 <perm1+0x18>
  4015e9:	00 00 00 
  4015ec:	c7 05 46 36 00 00 07 	movl   $0x7,0x3646(%rip)        # 404c3c <perm1+0x1c>
  4015f3:	00 00 00 
  4015f6:	c7 05 40 36 00 00 08 	movl   $0x8,0x3640(%rip)        # 404c40 <perm1+0x20>
  4015fd:	00 00 00 
  401600:	c7 05 3a 36 00 00 09 	movl   $0x9,0x363a(%rip)        # 404c44 <perm1+0x24>
  401607:	00 00 00 
  40160a:	c7 05 34 36 00 00 0a 	movl   $0xa,0x3634(%rip)        # 404c48 <perm1+0x28>
  401611:	00 00 00 
  401614:	4c 8d 05 c5 35 00 00 	lea    0x35c5(%rip),%r8        # 404be0 <perm>
  40161b:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
  401620:	48 c7 44 24 28 0b 00 	movq   $0xb,0x28(%rsp)
  401627:	00 00 
  401629:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
  401630:	00 00 
  401632:	0f 1f 00             	nopl   (%rax)
  401635:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40163c:	00 00 00 00 
  401640:	48 63 44 24 28       	movslq 0x28(%rsp),%rax
  401645:	83 f8 01             	cmp    $0x1,%eax
  401648:	0f 8f f2 00 00 00    	jg     401740 <main+0x1c0>
  40164e:	31 ff                	xor    %edi,%edi
  401650:	48 83 ff 20          	cmp    $0x20,%rdi
  401654:	7d 24                	jge    40167a <main+0xfa>
  401656:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  40165d:	00 00 00 
  401660:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
  401665:	c5 fe 6f 14 38       	vmovdqu (%rax,%rdi,1),%ymm2
  40166a:	c4 c1 7e 7f 14 38    	vmovdqu %ymm2,(%r8,%rdi,1)
  401670:	48 83 c7 20          	add    $0x20,%rdi
  401674:	48 83 ff 20          	cmp    $0x20,%rdi
  401678:	7c e6                	jl     401660 <main+0xe0>
  40167a:	48 c1 ef 02          	shr    $0x2,%rdi
  40167e:	48 63 f7             	movslq %edi,%rsi
  401681:	83 fe 0b             	cmp    $0xb,%esi
  401684:	7c 7a                	jl     401700 <main+0x180>
  401686:	45 31 ed             	xor    %r13d,%r13d
  401689:	41 8b 38             	mov    (%r8),%edi
  40168c:	85 ff                	test   %edi,%edi
  40168e:	0f 84 d7 00 00 00    	je     40176b <main+0x1eb>
  401694:	44 8d 77 01          	lea    0x1(%rdi),%r14d
  401698:	41 d1 fe             	sar    $1,%r14d
  40169b:	45 31 d2             	xor    %r10d,%r10d
  40169e:	45 39 f2             	cmp    %r14d,%r10d
  4016a1:	7d 41                	jge    4016e4 <main+0x164>
  4016a3:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  4016aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016b1:	00 00 00 00 
  4016b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016bc:	00 00 00 00 
  4016c0:	4d 63 fa             	movslq %r10d,%r15
  4016c3:	43 8b 2c b8          	mov    (%r8,%r15,4),%ebp
  4016c7:	89 fe                	mov    %edi,%esi
  4016c9:	44 29 d6             	sub    %r10d,%esi
  4016cc:	48 63 f6             	movslq %esi,%rsi
  4016cf:	41 8b 04 b0          	mov    (%r8,%rsi,4),%eax
  4016d3:	43 89 04 b8          	mov    %eax,(%r8,%r15,4)
  4016d7:	41 89 2c b0          	mov    %ebp,(%r8,%rsi,4)
  4016db:	41 83 c2 01          	add    $0x1,%r10d
  4016df:	45 39 f2             	cmp    %r14d,%r10d
  4016e2:	7c dc                	jl     4016c0 <main+0x140>
  4016e4:	41 83 c5 01          	add    $0x1,%r13d
  4016e8:	eb 9f                	jmp    401689 <main+0x109>
  4016ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016f1:	00 00 00 00 
  4016f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016fc:	00 00 00 00 
  401700:	48 63 d6             	movslq %esi,%rdx
  401703:	41 8b 04 93          	mov    (%r11,%rdx,4),%eax
  401707:	41 89 04 90          	mov    %eax,(%r8,%rdx,4)
  40170b:	83 c6 01             	add    $0x1,%esi
  40170e:	83 fe 0b             	cmp    $0xb,%esi
  401711:	7c ed                	jl     401700 <main+0x180>
  401713:	e9 6e ff ff ff       	jmp    401686 <main+0x106>
  401718:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  40171f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  401726:	00 00 00 00 
  40172a:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  401731:	00 00 00 00 
  401735:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40173c:	00 00 00 00 
  401740:	8b 74 24 28          	mov    0x28(%rsp),%esi
  401744:	83 ee 01             	sub    $0x1,%esi
  401747:	48 63 f6             	movslq %esi,%rsi
  40174a:	48 8d 0d 0f 35 00 00 	lea    0x350f(%rip),%rcx        # 404c60 <count>
  401751:	48 63 44 24 28       	movslq 0x28(%rsp),%rax
  401756:	89 04 b1             	mov    %eax,(%rcx,%rsi,4)
  401759:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
  40175e:	48 63 c6             	movslq %esi,%rax
  401761:	83 f8 01             	cmp    $0x1,%eax
  401764:	7f da                	jg     401740 <main+0x1c0>
  401766:	e9 e3 fe ff ff       	jmp    40164e <main+0xce>
  40176b:	44 3b 2d 2e 35 00 00 	cmp    0x352e(%rip),%r13d        # 404ca0 <maxflips>
  401772:	7e 07                	jle    40177b <main+0x1fb>
  401774:	44 89 2d 25 35 00 00 	mov    %r13d,0x3525(%rip)        # 404ca0 <maxflips>
  40177b:	8b 7c 24 20          	mov    0x20(%rsp),%edi
  40177f:	83 e7 01             	and    $0x1,%edi
  401782:	44 89 ee             	mov    %r13d,%esi
  401785:	f7 de                	neg    %esi
  401787:	85 ff                	test   %edi,%edi
  401789:	4c 89 ea             	mov    %r13,%rdx
  40178c:	0f 45 d6             	cmovne %esi,%edx
  40178f:	4c 63 15 0e 35 00 00 	movslq 0x350e(%rip),%r10        # 404ca4 <checksum>
  401796:	41 8d 04 12          	lea    (%r10,%rdx,1),%eax
  40179a:	89 05 04 35 00 00    	mov    %eax,0x3504(%rip)        # 404ca4 <checksum>
  4017a0:	8b 5c 24 20          	mov    0x20(%rsp),%ebx
  4017a4:	83 c3 01             	add    $0x1,%ebx
  4017a7:	48 8b 7c 24 28       	mov    0x28(%rsp),%rdi
  4017ac:	83 ff 0b             	cmp    $0xb,%edi
  4017af:	74 7f                	je     401830 <main+0x2b0>
  4017b1:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  4017b8:	45 8b 23             	mov    (%r11),%r12d
  4017bb:	31 d2                	xor    %edx,%edx
  4017bd:	45 31 ed             	xor    %r13d,%r13d
  4017c0:	39 fa                	cmp    %edi,%edx
  4017c2:	7d 34                	jge    4017f8 <main+0x278>
  4017c4:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  4017ca:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4017d1:	00 00 00 00 
  4017d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4017dc:	00 00 00 00 
  4017e0:	83 c2 01             	add    $0x1,%edx
  4017e3:	4c 63 f2             	movslq %edx,%r14
  4017e6:	48 63 d2             	movslq %edx,%rdx
  4017e9:	41 8b 04 93          	mov    (%r11,%rdx,4),%eax
  4017ed:	43 89 04 ab          	mov    %eax,(%r11,%r13,4)
  4017f1:	4d 89 f5             	mov    %r14,%r13
  4017f4:	39 fa                	cmp    %edi,%edx
  4017f6:	7c e8                	jl     4017e0 <main+0x260>
  4017f8:	4c 63 cf             	movslq %edi,%r9
  4017fb:	47 89 24 8b          	mov    %r12d,(%r11,%r9,4)
  4017ff:	4c 8d 15 5a 34 00 00 	lea    0x345a(%rip),%r10        # 404c60 <count>
  401806:	4f 8d 14 8a          	lea    (%r10,%r9,4),%r10
  40180a:	41 8b 12             	mov    (%r10),%edx
  40180d:	83 ea 01             	sub    $0x1,%edx
  401810:	41 89 12             	mov    %edx,(%r10)
  401813:	85 d2                	test   %edx,%edx
  401815:	7f 0a                	jg     401821 <main+0x2a1>
  401817:	83 c7 01             	add    $0x1,%edi
  40181a:	83 ff 0b             	cmp    $0xb,%edi
  40181d:	74 11                	je     401830 <main+0x2b0>
  40181f:	eb 97                	jmp    4017b8 <main+0x238>
  401821:	48 89 7c 24 28       	mov    %rdi,0x28(%rsp)
  401826:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
  40182b:	e9 10 fe ff ff       	jmp    401640 <main+0xc0>
  401830:	4c 63 1d 6d 34 00 00 	movslq 0x346d(%rip),%r11        # 404ca4 <checksum>
  401837:	4c 63 15 62 34 00 00 	movslq 0x3462(%rip),%r10        # 404ca0 <maxflips>
  40183e:	48 8d 3d 8f 11 00 00 	lea    0x118f(%rip),%rdi        # 4029d4 <_IO_stdin_used+0x4>
  401845:	4c 89 de             	mov    %r11,%rsi
  401848:	ba 0b 00 00 00       	mov    $0xb,%edx
  40184d:	4c 89 d1             	mov    %r10,%rcx
  401850:	31 c0                	xor    %eax,%eax
  401852:	e8 49 00 00 00       	call   4018a0 <printf@plt>
  401857:	31 c0                	xor    %eax,%eax
  401859:	c5 f8 77             	vzeroupper
  40185c:	48 83 c4 38          	add    $0x38,%rsp
  401860:	5d                   	pop    %rbp
  401861:	41 5f                	pop    %r15
  401863:	41 5e                	pop    %r14
  401865:	41 5d                	pop    %r13
  401867:	41 5c                	pop    %r12
  401869:	5b                   	pop    %rbx
  40186a:	c3                   	ret

Disassembly of section .init:

000000000040186c <_init>:
  40186c:	48 83 ec 08          	sub    $0x8,%rsp
  401870:	48 8b 05 21 23 00 00 	mov    0x2321(%rip),%rax        # 403b98 <_DYNAMIC+0x198>
  401877:	48 85 c0             	test   %rax,%rax
  40187a:	74 02                	je     40187e <_init+0x12>
  40187c:	ff d0                	call   *%rax
  40187e:	48 83 c4 08          	add    $0x8,%rsp
  401882:	c3                   	ret

Disassembly of section .fini:

0000000000401884 <_fini>:
  401884:	48 83 ec 08          	sub    $0x8,%rsp
  401888:	48 83 c4 08          	add    $0x8,%rsp
  40188c:	c3                   	ret

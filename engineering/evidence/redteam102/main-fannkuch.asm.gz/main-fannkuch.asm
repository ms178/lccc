
/home/user/.cache/redteam94/performance97/native45/fannkuch/main/benchmark.bin:     file format elf64-x86-64


Disassembly of section .plt:

0000000000401870 <printf@plt-0x10>:
  401870:	ff 35 12 33 00 00    	push   0x3312(%rip)        # 404b88 <_GLOBAL_OFFSET_TABLE_+0x8>
  401876:	ff 25 14 33 00 00    	jmp    *0x3314(%rip)        # 404b90 <_GLOBAL_OFFSET_TABLE_+0x10>
  40187c:	90                   	nop
  40187d:	90                   	nop
  40187e:	90                   	nop
  40187f:	90                   	nop

0000000000401880 <printf@plt>:
  401880:	ff 25 12 33 00 00    	jmp    *0x3312(%rip)        # 404b98 <printf@GLIBC_2.2.5>
  401886:	68 00 00 00 00       	push   $0x0
  40188b:	e9 e0 ff ff ff       	jmp    401870 <_fini+0x14>

Disassembly of section .text:

0000000000401480 <_start>:
  401480:	31 ed                	xor    %ebp,%ebp
  401482:	49 89 d1             	mov    %rdx,%r9
  401485:	5e                   	pop    %rsi
  401486:	48 89 e2             	mov    %rsp,%rdx
  401489:	48 83 e4 f0          	and    $0xfffffffffffffff0,%rsp
  40148d:	50                   	push   %rax
  40148e:	54                   	push   %rsp
  40148f:	45 31 c0             	xor    %r8d,%r8d
  401492:	31 c9                	xor    %ecx,%ecx
  401494:	48 c7 c7 80 15 40 00 	mov    $0x401580,%rdi
  40149b:	ff 15 cf 26 00 00    	call   *0x26cf(%rip)        # 403b70 <__libc_start_main@GLIBC_2.34>
  4014a1:	f4                   	hlt
  4014a2:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
  4014a9:	00 00 00 
  4014ac:	0f 1f 40 00          	nopl   0x0(%rax)

00000000004014b0 <_dl_relocate_static_pie>:
  4014b0:	c3                   	ret
	...

00000000004014c0 <deregister_tm_clones>:
  4014c0:	b8 b0 4b 40 00       	mov    $0x404bb0,%eax
  4014c5:	48 3d b0 4b 40 00    	cmp    $0x404bb0,%rax
  4014cb:	74 13                	je     4014e0 <deregister_tm_clones+0x20>
  4014cd:	b8 00 00 00 00       	mov    $0x0,%eax
  4014d2:	48 85 c0             	test   %rax,%rax
  4014d5:	74 09                	je     4014e0 <deregister_tm_clones+0x20>
  4014d7:	bf b0 4b 40 00       	mov    $0x404bb0,%edi
  4014dc:	ff e0                	jmp    *%rax
  4014de:	66 90                	xchg   %ax,%ax
  4014e0:	c3                   	ret
  4014e1:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4014e8:	00 00 00 00 
  4014ec:	0f 1f 40 00          	nopl   0x0(%rax)

00000000004014f0 <register_tm_clones>:
  4014f0:	be b0 4b 40 00       	mov    $0x404bb0,%esi
  4014f5:	48 81 ee b0 4b 40 00 	sub    $0x404bb0,%rsi
  4014fc:	48 89 f0             	mov    %rsi,%rax
  4014ff:	48 c1 ee 3f          	shr    $0x3f,%rsi
  401503:	48 c1 f8 03          	sar    $0x3,%rax
  401507:	48 01 c6             	add    %rax,%rsi
  40150a:	48 d1 fe             	sar    $1,%rsi
  40150d:	74 11                	je     401520 <register_tm_clones+0x30>
  40150f:	b8 00 00 00 00       	mov    $0x0,%eax
  401514:	48 85 c0             	test   %rax,%rax
  401517:	74 07                	je     401520 <register_tm_clones+0x30>
  401519:	bf b0 4b 40 00       	mov    $0x404bb0,%edi
  40151e:	ff e0                	jmp    *%rax
  401520:	c3                   	ret
  401521:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  401528:	00 00 00 00 
  40152c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000401530 <__do_global_dtors_aux>:
  401530:	f3 0f 1e fa          	endbr64
  401534:	80 3d 75 36 00 00 00 	cmpb   $0x0,0x3675(%rip)        # 404bb0 <__TMC_END__>
  40153b:	75 13                	jne    401550 <__do_global_dtors_aux+0x20>
  40153d:	55                   	push   %rbp
  40153e:	48 89 e5             	mov    %rsp,%rbp
  401541:	e8 7a ff ff ff       	call   4014c0 <deregister_tm_clones>
  401546:	c6 05 63 36 00 00 01 	movb   $0x1,0x3663(%rip)        # 404bb0 <__TMC_END__>
  40154d:	5d                   	pop    %rbp
  40154e:	c3                   	ret
  40154f:	90                   	nop
  401550:	c3                   	ret
  401551:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  401558:	00 00 00 00 
  40155c:	0f 1f 40 00          	nopl   0x0(%rax)

0000000000401560 <frame_dummy>:
  401560:	f3 0f 1e fa          	endbr64
  401564:	eb 8a                	jmp    4014f0 <register_tm_clones>
	...

0000000000401580 <main>:
  401580:	53                   	push   %rbx
  401581:	41 54                	push   %r12
  401583:	41 55                	push   %r13
  401585:	41 56                	push   %r14
  401587:	41 57                	push   %r15
  401589:	55                   	push   %rbp
  40158a:	48 83 ec 28          	sub    $0x28,%rsp
  40158e:	c7 05 e8 36 00 00 00 	movl   $0x0,0x36e8(%rip)        # 404c80 <maxflips>
  401595:	00 00 00 
  401598:	c7 05 e2 36 00 00 00 	movl   $0x0,0x36e2(%rip)        # 404c84 <checksum>
  40159f:	00 00 00 
  4015a2:	4c 8d 1d 57 36 00 00 	lea    0x3657(%rip),%r11        # 404c00 <perm1>
  4015a9:	41 c7 03 00 00 00 00 	movl   $0x0,(%r11)
  4015b0:	c7 05 4a 36 00 00 01 	movl   $0x1,0x364a(%rip)        # 404c04 <perm1+0x4>
  4015b7:	00 00 00 
  4015ba:	c7 05 44 36 00 00 02 	movl   $0x2,0x3644(%rip)        # 404c08 <perm1+0x8>
  4015c1:	00 00 00 
  4015c4:	c7 05 3e 36 00 00 03 	movl   $0x3,0x363e(%rip)        # 404c0c <perm1+0xc>
  4015cb:	00 00 00 
  4015ce:	c7 05 38 36 00 00 04 	movl   $0x4,0x3638(%rip)        # 404c10 <perm1+0x10>
  4015d5:	00 00 00 
  4015d8:	c7 05 32 36 00 00 05 	movl   $0x5,0x3632(%rip)        # 404c14 <perm1+0x14>
  4015df:	00 00 00 
  4015e2:	c7 05 2c 36 00 00 06 	movl   $0x6,0x362c(%rip)        # 404c18 <perm1+0x18>
  4015e9:	00 00 00 
  4015ec:	c7 05 26 36 00 00 07 	movl   $0x7,0x3626(%rip)        # 404c1c <perm1+0x1c>
  4015f3:	00 00 00 
  4015f6:	c7 05 20 36 00 00 08 	movl   $0x8,0x3620(%rip)        # 404c20 <perm1+0x20>
  4015fd:	00 00 00 
  401600:	c7 05 1a 36 00 00 09 	movl   $0x9,0x361a(%rip)        # 404c24 <perm1+0x24>
  401607:	00 00 00 
  40160a:	c7 05 14 36 00 00 0a 	movl   $0xa,0x3614(%rip)        # 404c28 <perm1+0x28>
  401611:	00 00 00 
  401614:	4c 8d 05 a5 35 00 00 	lea    0x35a5(%rip),%r8        # 404bc0 <perm>
  40161b:	41 bc 0b 00 00 00    	mov    $0xb,%r12d
  401621:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
  401628:	00 00 
  40162a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
  401630:	41 83 fc 01          	cmp    $0x1,%r12d
  401634:	0f 8f e6 00 00 00    	jg     401720 <main+0x1a0>
  40163a:	31 ff                	xor    %edi,%edi
  40163c:	48 83 ff 20          	cmp    $0x20,%rdi
  401640:	7d 24                	jge    401666 <main+0xe6>
  401642:	0f 1f 00             	nopl   (%rax)
  401645:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40164c:	00 00 00 00 
  401650:	c4 c1 7e 6f 14 3b    	vmovdqu (%r11,%rdi,1),%ymm2
  401656:	c4 c1 7e 7f 14 38    	vmovdqu %ymm2,(%r8,%rdi,1)
  40165c:	48 83 c7 20          	add    $0x20,%rdi
  401660:	48 83 ff 20          	cmp    $0x20,%rdi
  401664:	7c ea                	jl     401650 <main+0xd0>
  401666:	48 c1 ef 02          	shr    $0x2,%rdi
  40166a:	48 63 d7             	movslq %edi,%rdx
  40166d:	48 83 fa 0b          	cmp    $0xb,%rdx
  401671:	0f 8c 89 00 00 00    	jl     401700 <main+0x180>
  401677:	45 31 f6             	xor    %r14d,%r14d
  40167a:	41 8b 30             	mov    (%r8),%esi
  40167d:	85 f6                	test   %esi,%esi
  40167f:	0f 84 b8 00 00 00    	je     40173d <main+0x1bd>
  401685:	44 8d 7e 01          	lea    0x1(%rsi),%r15d
  401689:	41 d1 ff             	sar    $1,%r15d
  40168c:	45 31 d2             	xor    %r10d,%r10d
  40168f:	45 39 fa             	cmp    %r15d,%r10d
  401692:	7d 4e                	jge    4016e2 <main+0x162>
  401694:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  40169b:	00 00 00 00 
  40169f:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016a6:	00 00 00 00 
  4016aa:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016b1:	00 00 00 00 
  4016b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016bc:	00 00 00 00 
  4016c0:	43 8b 2c 90          	mov    (%r8,%r10,4),%ebp
  4016c4:	41 89 f1             	mov    %esi,%r9d
  4016c7:	45 29 d1             	sub    %r10d,%r9d
  4016ca:	4d 63 c9             	movslq %r9d,%r9
  4016cd:	43 8b 04 88          	mov    (%r8,%r9,4),%eax
  4016d1:	43 89 04 90          	mov    %eax,(%r8,%r10,4)
  4016d5:	43 89 2c 88          	mov    %ebp,(%r8,%r9,4)
  4016d9:	41 83 c2 01          	add    $0x1,%r10d
  4016dd:	45 39 fa             	cmp    %r15d,%r10d
  4016e0:	7c de                	jl     4016c0 <main+0x140>
  4016e2:	41 83 c6 01          	add    $0x1,%r14d
  4016e6:	eb 92                	jmp    40167a <main+0xfa>
  4016e8:	66 90                	xchg   %ax,%ax
  4016ea:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016f1:	00 00 00 00 
  4016f5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4016fc:	00 00 00 00 
  401700:	41 8b 04 93          	mov    (%r11,%rdx,4),%eax
  401704:	41 89 04 90          	mov    %eax,(%r8,%rdx,4)
  401708:	48 83 c2 01          	add    $0x1,%rdx
  40170c:	48 83 fa 0b          	cmp    $0xb,%rdx
  401710:	7c ee                	jl     401700 <main+0x180>
  401712:	e9 60 ff ff ff       	jmp    401677 <main+0xf7>
  401717:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
  40171e:	00 00 
  401720:	41 8d 74 24 ff       	lea    -0x1(%r12),%esi
  401725:	48 8d 0d 14 35 00 00 	lea    0x3514(%rip),%rcx        # 404c40 <count>
  40172c:	44 89 24 b1          	mov    %r12d,(%rcx,%rsi,4)
  401730:	41 89 f4             	mov    %esi,%r12d
  401733:	83 fe 01             	cmp    $0x1,%esi
  401736:	7f e8                	jg     401720 <main+0x1a0>
  401738:	e9 fd fe ff ff       	jmp    40163a <main+0xba>
  40173d:	44 3b 35 3c 35 00 00 	cmp    0x353c(%rip),%r14d        # 404c80 <maxflips>
  401744:	7e 07                	jle    40174d <main+0x1cd>
  401746:	44 89 35 33 35 00 00 	mov    %r14d,0x3533(%rip)        # 404c80 <maxflips>
  40174d:	8b 7c 24 18          	mov    0x18(%rsp),%edi
  401751:	83 e7 01             	and    $0x1,%edi
  401754:	44 89 f6             	mov    %r14d,%esi
  401757:	f7 de                	neg    %esi
  401759:	85 ff                	test   %edi,%edi
  40175b:	4c 89 f2             	mov    %r14,%rdx
  40175e:	0f 45 d6             	cmovne %esi,%edx
  401761:	4c 63 15 1c 35 00 00 	movslq 0x351c(%rip),%r10        # 404c84 <checksum>
  401768:	41 8d 04 12          	lea    (%r10,%rdx,1),%eax
  40176c:	89 05 12 35 00 00    	mov    %eax,0x3512(%rip)        # 404c84 <checksum>
  401772:	8b 44 24 18          	mov    0x18(%rsp),%eax
  401776:	83 c0 01             	add    $0x1,%eax
  401779:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
  40177e:	49 63 fc             	movslq %r12d,%rdi
  401781:	48 c1 e7 02          	shl    $0x2,%rdi
  401785:	48 8d 0d 74 34 00 00 	lea    0x3474(%rip),%rcx        # 404c00 <perm1>
  40178c:	4c 8d 2c 39          	lea    (%rcx,%rdi,1),%r13
  401790:	4c 8d 35 a9 34 00 00 	lea    0x34a9(%rip),%r14        # 404c40 <count>
  401797:	49 01 fe             	add    %rdi,%r14
  40179a:	41 83 fc 0b          	cmp    $0xb,%r12d
  40179e:	74 68                	je     401808 <main+0x288>
  4017a0:	45 8b 3b             	mov    (%r11),%r15d
  4017a3:	49 63 ec             	movslq %r12d,%rbp
  4017a6:	31 ff                	xor    %edi,%edi
  4017a8:	48 39 ef             	cmp    %rbp,%rdi
  4017ab:	7d 27                	jge    4017d4 <main+0x254>
  4017ad:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  4017b4:	00 
  4017b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
  4017bc:	00 00 00 00 
  4017c0:	48 8d 57 01          	lea    0x1(%rdi),%rdx
  4017c4:	41 8b 04 93          	mov    (%r11,%rdx,4),%eax
  4017c8:	41 89 04 bb          	mov    %eax,(%r11,%rdi,4)
  4017cc:	48 89 d7             	mov    %rdx,%rdi
  4017cf:	48 39 ea             	cmp    %rbp,%rdx
  4017d2:	7c ec                	jl     4017c0 <main+0x240>
  4017d4:	45 89 7d 00          	mov    %r15d,0x0(%r13)
  4017d8:	41 8b 36             	mov    (%r14),%esi
  4017db:	83 ee 01             	sub    $0x1,%esi
  4017de:	41 89 36             	mov    %esi,(%r14)
  4017e1:	85 f6                	test   %esi,%esi
  4017e3:	0f 8f 47 fe ff ff    	jg     401630 <main+0xb0>
  4017e9:	41 8d 44 24 01       	lea    0x1(%r12),%eax
  4017ee:	48 63 c0             	movslq %eax,%rax
  4017f1:	4d 8d 6d 04          	lea    0x4(%r13),%r13
  4017f5:	4d 8d 76 04          	lea    0x4(%r14),%r14
  4017f9:	49 89 c4             	mov    %rax,%r12
  4017fc:	83 f8 0b             	cmp    $0xb,%eax
  4017ff:	74 07                	je     401808 <main+0x288>
  401801:	eb 9d                	jmp    4017a0 <main+0x220>
  401803:	e9 28 fe ff ff       	jmp    401630 <main+0xb0>
  401808:	4c 63 1d 75 34 00 00 	movslq 0x3475(%rip),%r11        # 404c84 <checksum>
  40180f:	4c 63 15 6a 34 00 00 	movslq 0x346a(%rip),%r10        # 404c80 <maxflips>
  401816:	48 8d 3d 97 11 00 00 	lea    0x1197(%rip),%rdi        # 4029b4 <_IO_stdin_used+0x4>
  40181d:	4c 89 de             	mov    %r11,%rsi
  401820:	ba 0b 00 00 00       	mov    $0xb,%edx
  401825:	4c 89 d1             	mov    %r10,%rcx
  401828:	31 c0                	xor    %eax,%eax
  40182a:	e8 51 00 00 00       	call   401880 <printf@plt>
  40182f:	31 c0                	xor    %eax,%eax
  401831:	c5 f8 77             	vzeroupper
  401834:	48 83 c4 28          	add    $0x28,%rsp
  401838:	5d                   	pop    %rbp
  401839:	41 5f                	pop    %r15
  40183b:	41 5e                	pop    %r14
  40183d:	41 5d                	pop    %r13
  40183f:	41 5c                	pop    %r12
  401841:	5b                   	pop    %rbx
  401842:	c3                   	ret

Disassembly of section .init:

0000000000401844 <_init>:
  401844:	48 83 ec 08          	sub    $0x8,%rsp
  401848:	48 8b 05 29 23 00 00 	mov    0x2329(%rip),%rax        # 403b78 <_DYNAMIC+0x198>
  40184f:	48 85 c0             	test   %rax,%rax
  401852:	74 02                	je     401856 <_init+0x12>
  401854:	ff d0                	call   *%rax
  401856:	48 83 c4 08          	add    $0x8,%rsp
  40185a:	c3                   	ret

Disassembly of section .fini:

000000000040185c <_fini>:
  40185c:	48 83 ec 08          	sub    $0x8,%rsp
  401860:	48 83 c4 08          	add    $0x8,%rsp
  401864:	c3                   	ret

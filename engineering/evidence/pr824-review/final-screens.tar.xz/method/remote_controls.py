"""Fresh CE version probes and execution controls; run from repository root."""
import gzip,json,os,sys,hashlib
from pathlib import Path
os.environ['GODBOLT_CACHE']='/home/user/.cache/pr824-review/ce-fresh'
sys.path.insert(0,'scripts')
import godbolt as g
out=Path('/home/user/.cache/pr824-review/remote-controls');out.mkdir(parents=True,exist_ok=True)
rows=[]
for cid in ['cg162','cclang2310','cicxlatest']:
 v=g._request_json(g.API+'/compiler/'+cid+'/compile',body={'source':'int main(void){return 0;}','lang':'c','options':{'userArguments':'--version'}},timeout=90)
 (out/(cid+'-version.json')).write_text(json.dumps(v,indent=2)+'\n')
 for name in ['byte_load_preinline.c','affine_exit_bound.c','rotation_signed_wrap.c','affine_optional_exit.c']:
  source=(Path('tests/regression')/name).read_text()
  result=g.compile_on_godbolt(cid,source,'-O2 -march=x86-64-v3 -fwrapv',execute=True)
  if result is None:raise RuntimeError(cid+' failed '+name)
  (out/(cid+'-'+name+'.json.gz')).write_bytes(gzip.compress(json.dumps(result,indent=2).encode(),mtime=0))
  e=result.get('execResult',{})
  if not e.get('didExecute') or e.get('timedOut') or e.get('code')!=0:raise RuntimeError((cid,name,e))
  rows.append({'compiler':cid,'source':name,'source_sha256':hashlib.sha256(source.encode()).hexdigest(),'exit':e['code'],'passed':True})
  (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
  print('PASS',cid,name,flush=True)

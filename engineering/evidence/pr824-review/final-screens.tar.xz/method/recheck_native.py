"""Predeclared 31-round recheck of pilot >1% slowdowns, plus amplified byte work."""
import json,sys,os,subprocess,hashlib
from pathlib import Path
sys.path.insert(0,'.')
from tests.benchmark import run_benchmarks as b
root=Path('/home/user/.cache/pr824-review/native-recheck');root.mkdir(parents=True,exist_ok=True)
prev=json.loads(Path('/home/user/.cache/pr824-review/native-pairs/report.json').read_text())
selected=[e['name'] for e in prev['entries'] if e['ratios_from_lccc']['baseline']['median']>1.01]
# Fannkuch was found by the whole-registry counter screen, not by selecting
# a favorable timing result. Keep the larger native workload as a control.
selected+=['fannkuch']
flags=('-O2','-march=x86-64-v3','-fwrapv','-I'+b.detect_gcc_include('/home/user/.cache/toolchains/gcc-16.2.0/bin/gcc'))
compilers=[b.CompilerSpec('baseline','Prior S36 LCCC','/home/user/.cache/pr824-baseline/lccc',flags),b.CompilerSpec('lccc','Reviewed candidate',str(Path('target/fastbuild/lccc').resolve()),flags)]
prefix,pinning,warnings=b.choose_affinity('auto');env=b.controlled_environment()
report={'complete':False,'class':'VM screening, not EPYC 7763','selection_rule':'all pilot medians >1.01, plus whole-corpus Fannkuch regression and amplified byte control','selected':selected,'pinning':pinning,'warnings':warnings,'compiler_sha256':{c.key:b.sha256_file(Path(c.executable)) for c in compilers},'rows':[]}
def save():
 q=root/'report.tmp';q.write_text(json.dumps(report,indent=2)+'\n');q.replace(root/'report.json')
def measure(name,binaries):
 expected=None
 for k in binaries:
  r=b.run_binary(binaries[k],prefix,180,env);assert r['ok']
  expected=r['stdout'] if expected is None else expected;assert r['stdout']==expected
 rounds=[]
 for n in range(31):
  order=['baseline','lccc'] if n%2==0 else ['lccc','baseline'];runs={}
  for k in order:
   r=b.run_binary(binaries[k],prefix,180,env);assert r['ok'] and r['stdout']==expected;runs[k]=r
  rounds.append({'round':n,'order':order,'runs':runs})
 row={'name':name,'rounds':rounds,'paired':b.pair_ratios(rounds,'lccc','baseline',20261014),'binaries':{k:{'path':str(v),'sha256':b.sha256_file(v)} for k,v in binaries.items()}}
 report['rows'].append(row);save();print(name,row['paired']['median'],row['paired']['median_ci95_bootstrap'],flush=True)
save()
for item in b.BENCHMARKS:
 if item.name not in selected:continue
 bins={}
 for c in compilers:
  folder=root/item.name/c.key;folder.mkdir(parents=True,exist_ok=True);p=folder/'run'
  result=b.compile_one(c,item,b.source_for(item),p,None);assert result['ok'],result
  bins[c.key]=p
 measure(item.name,bins)
# Twenty independent calls per process reduce startup contamination without
# changing the kernel's input size, loops, or outputs. Both arms get the same
# separate wrapper; no cross-TU inlining or LTO is involved.
source=Path('tests/benchmark/programs/byte_load_reassembly.c').resolve()
driver=root/'repeat.c';driver.write_text('int workload_main(void); int main(void){for(int i=0;i<20;i++)if(workload_main())return 1;return 0;}\n')
bins={}
for c in compilers:
 d=root/'byte-repeat20'/c.key;d.mkdir(parents=True,exist_ok=True)
 commands=[[c.executable,*flags,'-Dmain=workload_main','-c',str(source),'-o',str(d/'kernel.o')],[c.executable,*flags,str(driver),str(d/'kernel.o'),'-o',str(d/'run')]]
 for cmd in commands:
  p=subprocess.run(cmd,capture_output=True,text=True,timeout=120);assert p.returncode==0,(cmd,p.stderr)
 (d/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');bins[c.key]=d/'run'
measure('byte_load_reassembly-repeat20',bins)
report['complete']=True;save()

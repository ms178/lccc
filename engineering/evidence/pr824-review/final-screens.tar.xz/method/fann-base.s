.section .rodata
.Lstr0:
    .byte 37, 100, 10, 80, 102, 97, 110, 110, 107, 117, 99, 104, 101, 110, 40, 37, 100, 41, 32, 61, 32, 37, 100, 10, 0

.section .bss
.align 16
.type perm, @object
.size perm, 64
perm:
    .zero 64
.align 16
.type perm1, @object
.size perm1, 64
perm1:
    .zero 64
.align 16
.type count, @object
.size count, 64
count:
    .zero 64
.align 4
.type maxflips, @object
.size maxflips, 4
maxflips:
    .zero 4
.align 4
.type checksum, @object
.size checksum, 4
checksum:
    .zero 4

.text
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $40, %rsp
    .cfi_def_cfa_offset 96
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movl $0, maxflips(%rip)
    movl $0, checksum(%rip)
    leaq perm1(%rip), %r11
    movl $0, (%r11)
    movl $1, perm1+4(%rip)
    movl $2, perm1+8(%rip)
    movl $3, perm1+12(%rip)
    movl $4, perm1+16(%rip)
    movl $5, perm1+20(%rip)
    movl $6, perm1+24(%rip)
    leaq perm(%rip), %r8
    movl $7, %r12d
    movq $0, 24(%rsp)
.p2align 5,,15
.p2align 4
.LBB1:
.LBB2:
    cmpl $1, %r12d
jle .LBB4
.p2align 4,,10
.p2align 3
.LBB3:
    leal -1(%r12), %edi
    leaq count(%rip), %rcx
    movl %r12d, (%rcx, %rdi, 4)
    movl %edi, %r12d
    cmpl $1, %edi
jg .LBB3
.LBB4:
    movdqu (%r11), %xmm2
    movdqu %xmm2, (%r8)
    movslq perm1+16(%rip), %rax
    movl %eax, perm+16(%rip)
    movslq perm1+20(%rip), %rax
    movl %eax, perm+20(%rip)
    movslq perm1+24(%rip), %rax
    movl %eax, perm+24(%rip)
    xorl %r14d, %r14d
.LBB5:
    movl (%r8), %esi
    testl %esi, %esi
je .LBB10
.LBB6:
    leal 1(%rsi), %r15d
    sarl $1, %r15d
    xorl %r10d, %r10d
.LBB7:
    cmpl %r15d, %r10d
jge .LBB9
.p2align 4,,10
.p2align 3
.LBB8:
    movl (%r8, %r10, 4), %ebp
    movl %esi, %r9d
    subl %r10d, %r9d
    movslq %r9d, %r9
    movl (%r8, %r9, 4), %eax
    movl %eax, (%r8, %r10, 4)
    movl %ebp, (%r8, %r9, 4)
    addl $1, %r10d
    cmpl %r15d, %r10d
jl .LBB8
.LBB9:
    addl $1, %r14d
    jmp .LBB5
.LBB10:
    cmpl maxflips(%rip), %r14d
jle .LBB12
.LBB11:
    movl %r14d, maxflips(%rip)
.LBB12:
    movl 24(%rsp), %r9d
    andl $1, %r9d
    movl %r14d, %edi
    negl %edi
    testl %r9d, %r9d
    movq %r14, %rsi
    cmovnel %edi, %esi
    movslq checksum(%rip), %rdx
    leal (%rdx, %rsi), %eax
    movl %eax, checksum(%rip)
    movl 24(%rsp), %ebx
    addl $1, %ebx
    movslq %r12d, %r9
    shlq $2, %r9
    leaq perm1(%rip), %rcx
    leaq (%rcx, %r9), %r13
    leaq count(%rip), %r14
    addq %r9, %r14
.LBB13:
    cmpl $7, %r12d
je .LBB20
.p2align 4,,10
.p2align 3
.LBB14:
    movl (%r11), %r15d
    movslq %r12d, %rbp
    xorl %r9d, %r9d
.LBB15:
    cmpq %rbp, %r9
jge .LBB17
.p2align 4,,10
.p2align 3
.LBB16:
    leaq 1(%r9), %r10
    movl (%r11, %r10, 4), %edx
    movl %edx, (%r11, %r9, 4)
    movq %r10, %r9
    cmpq %rbp, %r10
jl .LBB16
.LBB17:
    movl %r15d, (%r13)
    movl (%r14), %edx
    subl $1, %edx
    movl %edx, (%r14)
    testl %edx, %edx
jg .LBB19
.LBB18:
    leal 1(%r12), %eax
    movslq %eax, %rax
    movq %rax, 16(%rsp)
    leaq 4(%r13), %r13
    leaq 4(%r14), %r14
    movq 16(%rsp), %r12
    cmpl $7, %r12d
je .LBB20
    jmp .LBB14
.LBB19:
    movq %rbx, 24(%rsp)
    jmp .LBB1
.LBB20:
    movslq checksum(%rip), %r11
    movslq maxflips(%rip), %r10
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    movl $7, %edx
    movq %r10, %rcx
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 4
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    addq $40, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main


.section .note.GNU-stack,"",@progbits

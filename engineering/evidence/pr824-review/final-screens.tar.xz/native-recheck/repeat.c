int workload_main(void); int main(void){for(int i=0;i<20;i++)if(workload_main())return 1;return 0;}

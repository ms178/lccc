.Lstr0:

main.buf.0:
main.fr.1:

main:
    pushq %rbx
    subq $16, %rsp
    leaq main.buf.0(%rip), %r11
    xorl %r10d, %r10d
.LBB1:
    cmpq $4096, %r10
jae .LBB3
.LBB2:
    imulq $37, %r10, %rdi
    leaq 11(%rdi), %rsi
    movb %sil, (%r11, %r10)
    addq $1, %r10
    cmpq $4096, %r10
jb .LBB2
.LBB3:
    movb $1, main.fr.1(%rip)
    movb $240, main.fr.1+8(%rip)
    movb $2, main.fr.1+1(%rip)
    movb $241, main.fr.1+9(%rip)
    movb $3, main.fr.1+2(%rip)
    movb $242, main.fr.1+10(%rip)
    movb $4, main.fr.1+3(%rip)
    movb $243, main.fr.1+11(%rip)
    movb $5, main.fr.1+4(%rip)
    movb $244, main.fr.1+12(%rip)
    movb $6, main.fr.1+5(%rip)
    movb $245, main.fr.1+13(%rip)
    movb $7, main.fr.1+6(%rip)
    movb $246, main.fr.1+14(%rip)
    movb $8, main.fr.1+7(%rip)
    movb $247, main.fr.1+15(%rip)
    movl $287454020, main.fr.1+16(%rip)
    movb $1, main.buf.0(%rip)
    movb $2, main.buf.0+1(%rip)
    movb $3, main.buf.0+2(%rip)
    movb $4, main.buf.0+3(%rip)
    movb $5, main.buf.0+4(%rip)
    movb $6, main.buf.0+5(%rip)
    movb $7, main.buf.0+6(%rip)
    movb $8, main.buf.0+7(%rip)
    movzwl main.buf.0(%rip), %r11d
    cmpw $513, %r11w
je .LBB5
.LBB4:
    movl $2, %eax
.L__lccc_epilogue_1:
    addq $16, %rsp
    popq %rbx
    ret
.LBB5:
    movzbl main.buf.0(%rip), %r10d
    movl %r10d, %r8d
    movzbl main.buf.0+1(%rip), %r9d
    movl %r9d, %edi
    shll $8, %edi
    orl %edi, %r8d
    movzbl main.buf.0+2(%rip), %esi
    movl %esi, %edx
    shll $16, %edx
    orl %edx, %r8d
    movzbl main.buf.0+3(%rip), %r11d
    movl %r11d, %edi
    shll $24, %edi
    orl %edi, %r8d
    cmpl $67305985, %r8d
je .LBB7
.LBB6:
    movl $3, %eax
    jmp .L__lccc_epilogue_1
.LBB7:
    movzbl %r10b, %edx
    movzbl %r9b, %r10d
    shlq $8, %r10
    orq %r10, %rdx
    movzbl %sil, %r8d
    shlq $16, %r8
    orq %r8, %rdx
    movzbl %r11b, %r9d
    shlq $24, %r9
    orq %r9, %rdx
    movzbl main.buf.0+4(%rip), %edi
    movl %edi, %esi
    shlq $32, %rsi
    orq %rsi, %rdx
    movzbl main.buf.0+5(%rip), %r11d
    movl %r11d, %r10d
    shlq $40, %r10
    orq %r10, %rdx
    movzbl main.buf.0+6(%rip), %r8d
    movl %r8d, %r9d
    shlq $48, %r9
    orq %r9, %rdx
    movabsq $576460752303423488, %rax
    orq %rax, %rdx
    movabsq $578437695752307201, %rcx
    cmpq %rcx, %rdx
je .LBB9
.LBB8:
    movl $4, %eax
    jmp .L__lccc_epilogue_1
.LBB9:
    movzbl main.buf.0(%rip), %esi
    shlq $56, %rsi
    movzbl main.buf.0+1(%rip), %edx
    shlq $48, %rdx
    orq %rdx, %rsi
    movzbl main.buf.0+2(%rip), %r10d
    shlq $40, %r10
    orq %r10, %rsi
    movzbl main.buf.0+3(%rip), %r9d
    shlq $32, %r9
    orq %r9, %rsi
    movzbl %dil, %edx
    shlq $24, %rdx
    orq %rdx, %rsi
    movzbl %r11b, %r10d
    shlq $16, %r10
    orq %r10, %rsi
    movzbl %r8b, %r9d
    shlq $8, %r9
    orq %r9, %rsi
    orq $8, %rsi
    movabsq $72623859790382856, %rcx
    cmpq %rcx, %rsi
je .LBB11
.LBB10:
    movl $5, %eax
    jmp .L__lccc_epilogue_1
.LBB11:
    movabsq $-579005069656919568, %rcx
    cmpq %rcx, main.fr.1+8(%rip)
jne .LBB19
.LBB12:
    xorl %r11d, %r11d
    xorl %ebx, %ebx
    xorl %r10d, %r10d
.LBB13:
    cmpq $20000, %rbx
jae .LBB18
.LBB14:
    xorl %r8d, %r8d
    movq %r11, %r9
    leaq main.buf.0(%rip), %rdi
.LBB15:
    cmpq $4088, %r8
ja .LBB17
.LBB16:
    movl (%rdi), %esi
    xorl %r8d, %esi
    addl %esi, %r9d
    addq $8, %r8
    leaq 8(%rdi), %rdi
    cmpq $4088, %r8
jbe .LBB16
.LBB17:
    addq main.fr.1+8(%rip), %r10
    addq $1, %rbx
    movq %r9, %r11
    cmpq $20000, %rbx
jb .LBB14
.LBB18:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    movq %r10, %rdx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    jmp .L__lccc_epilogue_1
.LBB19:
    movl $6, %eax
    jmp .L__lccc_epilogue_1



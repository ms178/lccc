type RegId = u8;
const REG_NAMES: [[&str;16];2] = [["";16];2];
const FUSIBLE_OPS: &[&str] = &["add","sub","and","or","xor","cmp","test","imul"];
fn plain_gp_operand(_: &str)->Option<RegId>{panic!("operand helper reached")}
fn split_two_operands(_: &str)->Option<(&str,&str)>{panic!("operand helper reached")}
fn parse_reg_reg_alu(t: &str) -> Option<(&'static str, bool, RegId, RegId)> {
    let mnemonic = t.split_whitespace().next()?;
    let (op, suffix) = mnemonic.split_at(mnemonic.len().checked_sub(1)?);
    let is_q = match suffix {
        "q" => true,
        "l" => false,
        _ => return None,
    };
    let op = *FUSIBLE_OPS.iter().find(|o| **o == op)?;
    let rest = t[mnemonic.len()..].trim();
    let (a, b) = split_two_operands(rest)?;
    let src = plain_gp_operand(a)?;
    let dst = plain_gp_operand(b)?;
    let width = if is_q { 0 } else { 1 };
    if a != REG_NAMES[width][src as usize] || b != REG_NAMES[width][dst as usize] {
        return None;
    }
    Some((op, is_q, src, dst))
}


fn parse_imm_reg_flag(t: &str) -> Option<(&'static str, bool, &str, RegId)> {
    let mnemonic = t.split_whitespace().next()?;
    let (op, suffix) = mnemonic.split_at(mnemonic.len().checked_sub(1)?);
    let is_q = match suffix {
        "q" => true,
        "l" => false,
        _ => return None,
    };
    if op != "cmp" && op != "test" {
        return None;
    }
    // Reborrow from the static spelling (the split borrows `t`).
    let op: &'static str = if op == "cmp" { "cmp" } else { "test" };
    let rest = t[mnemonic.len()..].trim();
    let (a, b) = split_two_operands(rest)?;
    if !a.starts_with('$') {
        return None;
    }
    // Backend-emitted immediates: optional minus, then digits/hex; no
    // spaces or expression syntax (those never fold).
    let digits = &a[1..];
    if digits.is_empty()
        || !digits
            .bytes()
            .all(|c| c.is_ascii_hexdigit() || c == b'-' || c == b'x')
    {
        return None;
    }
    let dst = plain_gp_operand(b)?;
    let width = if is_q { 0 } else { 1 };
    if b != REG_NAMES[width][dst as usize] {
        return None;
    }
    Some((op, is_q, a, dst))
}
fn main() {
 for mnemonic in ["cmpé", "λ", "add界"] {
   let text=format!("{} %eax, %ecx",mnemonic);
   let a=std::panic::catch_unwind(||parse_reg_reg_alu(&text));
   let b=std::panic::catch_unwind(||parse_imm_reg_flag(&text));
   println!("{mnemonic}: register_parser_panicked={} immediate_parser_panicked={}",a.is_err(),b.is_err());
 }
}

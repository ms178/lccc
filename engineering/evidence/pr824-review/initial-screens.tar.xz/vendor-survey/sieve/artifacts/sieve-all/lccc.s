.Lstr0:

sieve:

count_primes:
    subq $8, %rsp
    leaq sieve(%rip), %rdi
    movl $1, %esi
    movl $10000001, %edx
    call memset@PLT
    leaq sieve(%rip), %r11
    movb $0, sieve+1(%rip)
    movb $0, (%r11)
    movl $2, %r10d
.LBB1:
    movl %r10d, %r8d
    imull %r10d, %r8d
    cmpl $10000000, %r8d
jg .LBB7
.LBB2:
    movslq %r10d, %r9
    cmpb $0, (%r11, %r9)
je .LBB6
.LBB3:
    movslq %r8d, %rdx
    movslq %r10d, %r8
.LBB4:
    cmpq $10000000, %rdx
jg .LBB6
.LBB5:
    movb $0, (%r11, %rdx)
    addq %r8, %rdx
    cmpq $10000000, %rdx
jle .LBB5
.LBB6:
    addl $1, %r10d
    jmp .LBB1
.LBB7:
    xorl %edi, %edi
    movl $2, %esi
.LBB8:
    cmpq $10000000, %rsi
jg .LBB10
.LBB9:
    leal 1(%rdi), %r8d
    cmpb $0, (%r11, %rsi)
    cmovnel %r8d, %edi
    addq $1, %rsi
    cmpq $10000000, %rsi
jle .LBB9
.LBB10:
    movl %edi, %eax
    addq $8, %rsp
    ret

main:
    subq $24, %rsp
    call count_primes@PLT
    movl %eax, 16(%rsp)
    movslq 16(%rsp), %r11
    leaq .Lstr0(%rip), %rdi
    movl $10000000, %esi
    movq %r11, %rdx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $24, %rsp
    ret



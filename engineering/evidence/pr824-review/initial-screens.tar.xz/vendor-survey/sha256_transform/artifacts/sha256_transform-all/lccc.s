.Lstr0:

K:

sha256_transform:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $280, %rsp
    movq %rdi, %rbx
    xorl %edi, %edi
.LBB1:
    cmpq $64, %rdi
jge .LBB3
.LBB2:
    vmovdqu (%rsi,%rdi), %ymm2
    vmovdqu %ymm2, 16(%rsp, %rdi)
    addq $32, %rdi
    cmpq $64, %rdi
jl .LBB2
.LBB3:
    leaq 80(%rsp), %rsi
    movl $16, %edx
.LBB4:
    cmpl $64, %edx
jge .LBB6
.LBB5:
    addl $2, %edx
    vmovq -8(%rsi), %xmm3
    vpslld $15, %xmm3, %xmm15
    vpsrld $17, %xmm3, %xmm14
    vpor %xmm14, %xmm15, %xmm15
    vpslld $13, %xmm3, %xmm14
    vpsrld $19, %xmm3, %xmm13
    vpor %xmm13, %xmm14, %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    vpsrld $10, %xmm3, %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    vmovq -28(%rsi), %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq -60(%rsi), %xmm4
    vpslld $25, %xmm4, %xmm14
    vpsrld $7, %xmm4, %xmm13
    vpor %xmm13, %xmm14, %xmm14
    vpslld $14, %xmm4, %xmm13
    vpsrld $18, %xmm4, %xmm12
    vpor %xmm12, %xmm13, %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    vpsrld $3, %xmm4, %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq -64(%rsi), %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq %xmm15, (%rsi)
    leaq 8(%rsi), %rsi
    cmpl $64, %edx
jl .LBB5
.LBB6:
    movl (%rbx), %r12d
    movl 4(%rbx), %r11d
    movl 8(%rbx), %edi
    movl 12(%rbx), %r13d
    movl 16(%rbx), %r14d
    movl 20(%rbx), %r9d
    movl 24(%rbx), %r10d
    movl 28(%rbx), %ebp
    xorl %r8d, %r8d
    movq %rbp, %rdx
.LBB7:
    cmpq $64, %r8
jge .LBB9
    leaq K(%rip), %rcx
.LBB8:
    movl (%rcx, %r8, 4), %ebp
    addl 16(%rsp, %r8, 4), %ebp
    leal (%rbp, %rdx), %esi
    movq %r14, %rbp
    andl %r9d, %ebp
    andnl %r10d, %r14d, %r15d
    xorl %r15d, %ebp
    addl %ebp, %esi
    rorxl $6, %r14d, %ebp
    rorxl $11, %r14d, %r15d
    xorl %r15d, %ebp
    rorxl $25, %r14d, %r15d
    xorl %r15d, %ebp
    addl %esi, %ebp
    rorxl $2, %r12d, %esi
    rorxl $13, %r12d, %r15d
    xorl %r15d, %esi
    rorxl $22, %r12d, %r15d
    xorl %r15d, %esi
    movl %r12d, %r15d
    andl %r11d, %r15d
    movl %r12d, %eax
    xorl %r11d, %eax
    andl %edi, %eax
    xorl %eax, %r15d
    addl %r15d, %esi
    addq $1, %r8
    movq %r10, %rdx
    movq %r9, %r10
    movq %r14, %r9
    leal (%r13, %rbp), %r14d
    movq %rdi, %r13
    movq %r11, %rdi
    movq %r12, %r11
    leal (%rbp, %rsi), %r12d
    cmpq $64, %r8
jl .LBB8
.LBB9:
    vmovdqu (%rbx), %xmm15
    vmovd %r12d, %xmm0
    vmovd %r11d, %xmm1
    vpunpckldq %xmm1, %xmm0, %xmm0
    movq %rdi, %rax
    shlq $32, %r13
    orq %r13, %rax
    vmovq %rax, %xmm1
    vpunpcklqdq %xmm1, %xmm0, %xmm0
    vpaddd %xmm0, %xmm15, %xmm15
    vmovdqu %xmm15, (%rbx)
    vmovdqu 16(%rbx), %xmm15
    vmovd %r14d, %xmm0
    vmovd %r9d, %xmm1
    vpunpckldq %xmm1, %xmm0, %xmm0
    movq %r10, %rax
    shlq $32, %rdx
    orq %rdx, %rax
    vmovq %rax, %xmm1
    vpunpcklqdq %xmm1, %xmm0, %xmm0
    vpaddd %xmm0, %xmm15, %xmm15
    vmovdqu %xmm15, 16(%rbx)
    vzeroupper
    addq $280, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $472, %rsp
    movl $1779033703, 336(%rsp)
    movl $3144134277, 340(%rsp)
    movl $1013904242, 344(%rsp)
    movl $2773480762, 348(%rsp)
    movl $1359893119, 352(%rsp)
    movl $2600822924, 356(%rsp)
    movl $528734635, 360(%rsp)
    movl $1541459225, 364(%rsp)
    movl $1633837952, 272(%rsp)
    movl $0, 276(%rsp)
    movl $0, 280(%rsp)
    movl $0, 284(%rsp)
    pxor %xmm0, %xmm0
    movdqu %xmm0, 288(%rsp)
    movdqu %xmm0, 304(%rsp)
    movl $0, 320(%rsp)
    movl $0, 324(%rsp)
    movl $0, 328(%rsp)
    movl $24, 332(%rsp)
    leaq 336(%rsp), %rdi
    leaq 272(%rsp), %rsi
    call sha256_transform
    movl 336(%rsp), %r8d
    cmpl $3128432319, %r8d
je .LBB21
.LBB11:
    xorl %r9d, %r9d
    jmp .LBB12
.LBB21:
    movl 340(%rsp), %esi
    cmpl $2399260650, %esi
je .LBB23
.LBB22:
    xorl %r9d, %r9d
    jmp .LBB12
.LBB23:
    movl 364(%rsp), %r10d
    cmpl $4060091821, %r10d
    movl $0, %ecx
    movl $1, %r9d
    cmovnel %ecx, %r9d
.LBB12:
    movl $1664525, %eax
    movd %eax, %xmm0
    pshufd $0x00, %xmm0, %xmm0
    movdqu %xmm0, 176(%rsp)
    vmovdqa .LCVEC_0(%rip), %xmm0
    movdqu %xmm0, 144(%rsp)
    vmovdqa .LCVEC_1(%rip), %xmm0
    movdqu %xmm0, 112(%rsp)
    vmovdqa .LCVEC_2(%rip), %xmm0
    movdqu %xmm0, 80(%rsp)
    vmovdqa .LCVEC_3(%rip), %xmm0
    movdqu %xmm0, 48(%rsp)
    testl %r9d, %r9d
je .LBB20
.LBB13:
    xorl %r11d, %r11d
    xorl %r14d, %r14d
    jmp .LBB14
.LBB20:
    movl $2, %eax
.L__lccc_epilogue_1:
    addq $472, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB14:
    cmpl $8, %r14d
jae .LBB19
.LBB15:
    movq %r14, %rax
    xorq $1779033703, %rax
    movl %eax, 432(%rsp)
    movl $3144134277, 436(%rsp)
    movl $1013904242, 440(%rsp)
    movl $2773480762, 444(%rsp)
    movl $1359893119, 448(%rsp)
    movl $2600822924, 452(%rsp)
    movl $528734635, 456(%rsp)
    movl $1541459225, 460(%rsp)
    movq %r11, %rbx
    xorl %r15d, %r15d
.LBB16:
    cmpl $131072, %r15d
jb .LBB18
.LBB17:
    addl $1, %r14d
    movq %rbx, %r11
    cmpl $8, %r14d
jb .LBB15
.LBB19:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    jmp .L__lccc_epilogue_1
.LBB18:
    movd %r15d, %xmm0
    pshufd $0x00, %xmm0, %xmm0
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 144(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 432(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 368(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 112(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 448(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 384(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 80(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 432(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 400(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm15
    movdqu 48(%rsp), %xmm1
    vpaddd %xmm1, %xmm15, %xmm15
    movdqu 448(%rsp), %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    movdqu %xmm15, 416(%rsp)
    leaq 432(%rsp), %rdi
    leaq 368(%rsp), %rsi
    call sha256_transform
    movl 432(%rsp), %r8d
    shlq $32, %r8
    movl 460(%rsp), %eax
    xorq %rax, %r8
    movl 444(%rsp), %edi
    shlq $16, %rdi
    xorq %rdi, %r8
    addq %r8, %rbx
    addl $1, %r15d
    cmpl $131072, %r15d
jb .LBB18
    jmp .LBB17

.LCVEC_0:
.LCVEC_1:
.LCVEC_2:
.LCVEC_3:


.Lstr0:

.LCA_0:

data:
checks:

zng_combine:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $88, %rsp
    movq %rdi, %rbx
    movq %rsi, %r12
    movq %rdx, %r13
    testq %rdx, %rdx
jge .LBB2
.LBB1:
    movl $-1, %eax
.L__lccc_epilogue_1:
    addq $88, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB2:
    movq %r13, %rax
    cqto
    movq %rdx, %rcx
    movq %rax, %rsi
    movabsq $-9221260491235007769, %r8
    mulq %r8
    imulq %r8, %rcx
    addq %rcx, %rdx
    movabsq $-1, %r8
    imulq %r8, %rsi
    addq %rsi, %rdx
    movq %rdx, %rax
    sarq $63, %rdx
    leaq (%rax, %r13), %r11
    sarq $15, %r11
    movq %r11, %r10
    shrq $63, %r10
    addq %r10, %r11
    imulq $65521, %r11, %r11
    subq %r11, %r13
    movl %r13d, %r11d
    movzwl %bx, %r10d
    movl %r13d, %r14d
    imull %r10d, %r14d
    movl %r14d, %r15d
    movl $2147975281, %eax
    imulq %rax, %r15
    shrq $47, %r15
    movl %r15d, %ebp
    imull $65521, %ebp, %ebp
    subl %ebp, %r14d
    movzwl %r12w, %r13d
    addl $65520, %r13d
    addl %r13d, %r10d
    shrl $16, %ebx
    andl $65535, %ebx
    shrl $16, %r12d
    andl $65535, %r12d
    addl %r12d, %ebx
    addl $65521, %ebx
    subl %r11d, %ebx
    leal (%r14, %rbx), %r11d
    leal -65521(%r10), %r15d
    cmpl $65521, %r10d
    movq %r10, %rbp
    cmovael %r15d, %ebp
    leal -65521(%rbp), %ebx
    cmpl $65521, %ebp
    movq %rbp, %r12
    cmovael %ebx, %r12d
    leal -131042(%r11), %r13d
    cmpl $131042, %r11d
    movq %r11, %r14
    cmovael %r13d, %r14d
    leal -65521(%r14), %r10d
    cmpl $65521, %r14d
    movq %r14, %r15
    cmovael %r10d, %r15d
    shll $16, %r15d
    orl %r12d, %r15d
    movl %r15d, %eax
    jmp .L__lccc_epilogue_1

reference:
    pushq %r12
    pushq %r14
    pushq %r15
    movl %esi, %edx
    movl $2147975281, %r8d
    movl $1, %r9d
    xorl %r11d, %r11d
    xorl %r10d, %r10d
.LBB4:
    cmpq %rdx, %r10
jae .LBB6
.LBB5:
    movzbl (%rdi, %r10), %eax
    leal (%r9, %rax), %r12d
    movl %r12d, %esi
    imulq %r8, %rsi
    shrq $47, %rsi
    imull $65521, %esi, %esi
    movl %r12d, %r9d
    subl %esi, %r9d
    leal (%r11, %r9), %esi
    movl %esi, %r14d
    imulq %r8, %r14
    shrq $47, %r14
    movl %r14d, %r15d
    imull $65521, %r15d, %r15d
    movl %esi, %r11d
    subl %r15d, %r11d
    addq $1, %r10
    cmpq %rdx, %r10
jb .LBB5
.LBB6:
    shll $16, %r11d
    orl %r9d, %r11d
    movl %r11d, %eax
    popq %r15
    popq %r14
    popq %r12
    ret

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $88, %rsp
    leaq .LCA_0(%rip), %rbx
    leaq data(%rip), %r11
    xorl %r12d, %r12d
.LBB8:
    cmpq $1024, %r12
jae .LBB10
.LBB9:
    imulq $37, %r12, %r13
    leaq 11(%r13), %r14
    movb %r14b, (%r11, %r12)
    addq $1, %r12
    cmpq $1024, %r12
jb .LBB9
.LBB10:
    leaq data(%rip), %r13
    movl $2147975281, %r14d
    movl $1, %r11d
    movq $0, 72(%rsp)
    xorl %r15d, %r15d
.LBB11:
    cmpq $1024, %r15
jae .LBB13
.LBB12:
    movzbl (%r13, %r15), %eax
    leal (%r11, %rax), %r12d
    movl %r12d, %r10d
    imulq %r14, %r10
    shrq $47, %r10
    movl %r10d, %ebp
    imull $65521, %ebp, %r10d
    movl %r12d, %r11d
    subl %r10d, %r11d
    movl 72(%rsp), %r10d
    addl %r11d, %r10d
    movl %r10d, %ebp
    imulq %r14, %rbp
    shrq $47, %rbp
    movl %ebp, %ebp
    imull $65521, %ebp, %ebp
    subl %ebp, %r10d
    movq %r10, 72(%rsp)
    addq $1, %r15
    cmpq $1024, %r15
jb .LBB12
.LBB13:
    movl 72(%rsp), %r10d
    shll $16, %r10d
    movq %r10, %rbp
    orl %r11d, %ebp
    xorl %r12d, %r12d
.LBB14:
    cmpl $1024, %r12d
ja .LBB17
.LBB15:
    movq %r13, %rdi
    movl %r12d, %esi
    call reference
    movl %eax, %r14d
    movl %r12d, %ecx
    leaq data(%rip), %rax
    addq %rcx, %rax
    movl %r12d, %r10d
    movl $1024, %r15d
    subq %r10, %r15
    movq %rax, %rdi
    movl %r15d, %esi
    call reference
    movl %r14d, %edi
    movl %eax, %esi
    movq %r15, %rdx
    call zng_combine@PLT
    cmpl %ebp, %eax
jne .LBB31
.LBB16:
    addl $1, %r12d
    cmpl $1024, %r12d
jbe .LBB15
.LBB17:
    movl $1, %edi
    movl $1, %esi
    movq $-1, %rdx
    call zng_combine@PLT
    cmpl $4294967295, %eax
jne .LBB30
.LBB18:
    xorl %ebp, %ebp
.LBB19:
    cmpq $7, %rbp
jae .LBB22
.LBB20:
    movq %rbp, %r10
    movq (%rbx, %r10, 8), %r12
    movq %r12, %rax
    cqto
    movq %rdx, %rcx
    movq %rax, %rsi
    movabsq $-9221260491235007769, %r8
    mulq %r8
    imulq %r8, %rcx
    addq %rcx, %rdx
    movabsq $-1, %r8
    imulq %r8, %rsi
    addq %rsi, %rdx
    movq %rdx, %rax
    leaq (%rax, %r12), %r10
    sarq $15, %r10
    movq %r10, %r11
    shrq $63, %r11
    addq %r11, %r10
    imulq $65521, %r10, %r10
    movq %r12, %r11
    subq %r10, %r11
    shll $16, %r11d
    movl %r11d, %r14d
    orl $1, %r14d
    movl $1, %edi
    movl %r14d, %esi
    movq %r12, %rdx
    call zng_combine@PLT
    cmpl %r14d, %eax
jne .LBB29
.LBB21:
    addq $1, %rbp
    cmpq $7, %rbp
jb .LBB20
.LBB22:
    leaq checks(%rip), %r15
    xorl %ebp, %ebp
.LBB23:
    cmpl $64, %ebp
jae .LBB25
.LBB24:
    movl %ebp, %ebx
    movl %ebp, %r10d
    shll $4, %r10d
    movq %r13, %rdi
    movl %r10d, %esi
    call reference
    movl %eax, (%r15, %rbx, 4)
    addl $1, %ebp
    cmpl $64, %ebp
jb .LBB24
.LBB25:
    leaq checks(%rip), %r15
    movl $1, %ebp
    xorl %ebx, %ebx
.LBB26:
    cmpl $50000000, %ebx
jae .LBB28
.LBB27:
    movl %ebp, %r10d
    xorl %ebx, %r10d
    andl $63, %r10d
    movl (%r15, %r10, 4), %r11d
    movl %r10d, %eax
    shll $4, %eax
    movl %eax, %r10d
    movq %rbp, %rdi
    movq %r11, %rsi
    movq %r10, %rdx
    call zng_combine@PLT
    movq %rax, %rbp
    addl $1, %ebx
    cmpl $50000000, %ebx
jb .LBB27
.LBB28:
    leaq .Lstr0(%rip), %rdi
    movq %rbp, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
.L__lccc_epilogue_2:
    addq $88, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB29:
    movl $3, %eax
    jmp .L__lccc_epilogue_2
.LBB30:
    movl $2, %eax
    jmp .L__lccc_epilogue_2
.LBB31:
    movl $1, %eax
    jmp .L__lccc_epilogue_2



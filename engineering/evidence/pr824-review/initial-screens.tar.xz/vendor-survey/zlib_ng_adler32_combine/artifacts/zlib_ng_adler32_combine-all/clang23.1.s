zng_combine:
  testq %rdx, %rdx
  js .LBB0_1
  movabsq $4223091239536077, %rax
  mulxq %rax, %rax, %rax
  movq %rdx, %rcx
  subq %rax, %rcx
  shrq %rcx
  addq %rax, %rcx
  shrq $15, %rcx
  imull $65521, %ecx, %eax
  subl %eax, %edx
  movzwl %di, %eax
  movl %eax, %ecx
  imull %edx, %eax
  movl $2147975281, %r8d
  imulq %rax, %r8
  shrq $47, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %eax
  movzwl %si, %r8d
  leal (%rcx,%r8), %r9d
  addl $65520, %r9d
  shrl $16, %edi
  shrl $16, %esi
  addl %edi, %esi
  subl %edx, %esi
  leal (%rsi,%rax), %edx
  addl $65521, %edx
  cmpl $65521, %r9d
  leal -1(%rcx,%r8), %ecx
  movl $65520, %edi
  cmovael %ecx, %edi
  movl %edi, %ecx
  subl $65521, %ecx
  cmovbl %edi, %ecx
  cmpl $131042, %edx
  leal -65521(%rsi,%rax), %esi
  cmovbl %edx, %esi
  movl %esi, %edx
  shll $16, %edx
  leal 983040(%rdx), %eax
  cmpl $65521, %esi
  cmovbl %edx, %eax
  orl %ecx, %eax
  retq
.LBB0_1:
  movl $-1, %eax
  retq

.LCPI1_0:
.LCPI1_1:
.LCPI1_2:
.LCPI1_3:
.LCPI1_4:
.LCPI1_5:
.LCPI1_6:
.LCPI1_7:
main:
  pushq %rbp
  pushq %r15
  pushq %r14
  pushq %r13
  pushq %r12
  pushq %rbx
  pushq %rax
  vmovaps .LCPI1_0(%rip), %ymm0
  vmovaps %ymm0, data(%rip)
  vmovaps .LCPI1_1(%rip), %ymm1
  vmovaps %ymm1, data+32(%rip)
  vmovaps .LCPI1_2(%rip), %ymm2
  vmovaps %ymm2, data+64(%rip)
  vmovaps .LCPI1_3(%rip), %ymm3
  vmovaps %ymm3, data+96(%rip)
  vmovaps .LCPI1_4(%rip), %ymm4
  vmovaps %ymm4, data+128(%rip)
  vmovaps .LCPI1_5(%rip), %ymm5
  vmovaps %ymm5, data+160(%rip)
  vmovaps .LCPI1_6(%rip), %ymm6
  vmovaps %ymm6, data+192(%rip)
  vmovaps .LCPI1_7(%rip), %ymm7
  vmovaps %ymm7, data+224(%rip)
  vmovaps %ymm0, data+256(%rip)
  vmovaps %ymm1, data+288(%rip)
  vmovaps %ymm2, data+320(%rip)
  vmovaps %ymm3, data+352(%rip)
  vmovaps %ymm4, data+384(%rip)
  vmovaps %ymm5, data+416(%rip)
  vmovaps %ymm6, data+448(%rip)
  vmovaps %ymm7, data+480(%rip)
  vmovaps %ymm0, data+512(%rip)
  vmovaps %ymm1, data+544(%rip)
  vmovaps %ymm2, data+576(%rip)
  vmovaps %ymm3, data+608(%rip)
  vmovaps %ymm4, data+640(%rip)
  vmovaps %ymm5, data+672(%rip)
  vmovaps %ymm6, data+704(%rip)
  vmovaps %ymm7, data+736(%rip)
  vmovaps %ymm0, data+768(%rip)
  vmovaps %ymm1, data+800(%rip)
  vmovaps %ymm2, data+832(%rip)
  vmovaps %ymm3, data+864(%rip)
  vmovaps %ymm4, data+896(%rip)
  vmovaps %ymm5, data+928(%rip)
  vmovaps %ymm6, data+960(%rip)
  vmovaps %ymm7, data+992(%rip)
  movl $1, %edx
  xorl %ebx, %ebx
  leaq data(%rip), %r14
  movl $2147975281, %eax
  xorl %ecx, %ecx
.LBB1_1:
  movzbl (%rcx,%r14), %esi
  addl %esi, %edx
  movq %rdx, %rsi
  imulq %rax, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %ebx
  movq %rbx, %rsi
  imulq %rax, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %ebx
  movzbl 1(%rcx,%r14), %esi
  addl %edx, %esi
  imulq $131103, %rsi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %esi
  addl %esi, %ebx
  imulq $131103, %rbx, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %ebx
  movzbl 2(%rcx,%r14), %edi
  addl %esi, %edi
  imulq $131103, %rdi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %edi
  addl %edi, %ebx
  imulq $131103, %rbx, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %ebx
  movzbl 3(%rcx,%r14), %edx
  addl %edi, %edx
  imulq $131103, %rdx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %ebx
  imulq $131103, %rbx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %ebx
  addq $4, %rcx
  cmpq $1024, %rcx
  jne .LBB1_1
  shll $16, %ebx
  orl %edx, %ebx
  leaq data+3(%rip), %r15
  xorl %r12d, %r12d
  movl $2147975281, %r13d
  movq %r14, %rbp
.LBB1_3:
  movl $1, %eax
  testq %r12, %r12
  je .LBB1_6
  cmpq $4, %r12
  jae .LBB1_7
  movl $1, %edx
  xorl %ecx, %ecx
  xorl %edi, %edi
  jmp .LBB1_10
.LBB1_6:
  movl $1024, %edx
  movl $1, %edi
  jmp .LBB1_15
.LBB1_7:
  movq %r12, %rsi
  andq $-4, %rsi
  movl $1, %edx
  xorl %ecx, %ecx
  xorl %edi, %edi
.LBB1_8:
  movzbl (%rcx,%r14), %r8d
  addl %r8d, %edx
  movq %rdx, %r8
  imulq %r13, %r8
  shrq $47, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edx
  addl %edx, %edi
  movq %rdi, %r8
  imulq %r13, %r8
  shrq $47, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  movzbl 1(%rcx,%r14), %r8d
  addl %edx, %r8d
  imulq $131103, %r8, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r8d
  addl %r8d, %edi
  imulq $131103, %rdi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %edi
  movzbl 2(%rcx,%r14), %r9d
  addl %r8d, %r9d
  imulq $131103, %r9, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r9d
  addl %r9d, %edi
  imulq $131103, %rdi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %edi
  movzbl 3(%rcx,%r14), %edx
  addl %r9d, %edx
  imulq $131103, %rdx, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edx
  addl %edx, %edi
  imulq $131103, %rdi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  addq $4, %rcx
  cmpq %rcx, %rsi
  jne .LBB1_8
  testb $3, %r12b
  je .LBB1_12
.LBB1_10:
  movl %r12d, %esi
  andl $3, %esi
  xorl %r8d, %r8d
.LBB1_11:
  leaq (%rcx,%r8), %r9
  movzbl (%r14,%r9), %r9d
  addl %r9d, %edx
  movq %rdx, %r9
  imulq %r13, %r9
  shrq $47, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %edx
  addl %edx, %edi
  movq %rdi, %r9
  imulq %r13, %r9
  shrq $47, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %edi
  incq %r8
  cmpq %r8, %rsi
  jne .LBB1_11
.LBB1_12:
  shll $16, %edi
  orl %edx, %edi
  movq %r12, %rdx
  subq $1024, %rdx
  jne .LBB1_14
  movl $1, %esi
  xorl %edx, %edx
  jmp .LBB1_23
.LBB1_14:
  negq %rdx
.LBB1_15:
  leaq -1(%rdx), %rsi
  movl %edx, %ecx
  andl $3, %ecx
  cmpq $3, %rsi
  jae .LBB1_17
  xorl %r8d, %r8d
  xorl %esi, %esi
  jmp .LBB1_20
.LBB1_17:
  movl %edx, %r9d
  andl $2044, %r9d
  movl $1, %eax
  xorl %r8d, %r8d
  xorl %esi, %esi
.LBB1_18:
  movzbl -3(%r15,%r8), %r10d
  addl %r10d, %eax
  movq %rax, %r10
  imulq %r13, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %eax
  addl %eax, %esi
  movq %rsi, %r10
  imulq %r13, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %esi
  movzbl -2(%r15,%r8), %r10d
  addl %eax, %r10d
  imulq $131103, %r10, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %r10d
  addl %r10d, %esi
  imulq $131103, %rsi, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl -1(%r15,%r8), %r11d
  addl %r10d, %r11d
  imulq $131103, %r11, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %r11d
  addl %r11d, %esi
  imulq $131103, %rsi, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl (%r15,%r8), %eax
  addl %r11d, %eax
  imulq $131103, %rax, %r10
  shrq $33, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %eax
  addl %eax, %esi
  imulq $131103, %rsi, %r10
  shrq $33, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %esi
  addq $4, %r8
  cmpq %r8, %r9
  jne .LBB1_18
  testq %rcx, %rcx
  je .LBB1_22
.LBB1_20:
  addq %rbp, %r8
  xorl %r9d, %r9d
.LBB1_21:
  movzbl (%r8,%r9), %r10d
  addl %r10d, %eax
  movq %rax, %r10
  imulq %r13, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %eax
  addl %eax, %esi
  movq %rsi, %r10
  imulq %r13, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %esi
  incq %r9
  cmpq %r9, %rcx
  jne .LBB1_21
.LBB1_22:
  shll $16, %esi
  orl %eax, %esi
.LBB1_23:
  vzeroupper
  callq zng_combine
  cmpl %ebx, %eax
  jne .LBB1_34
  incq %r12
  incq %r15
  incq %rbp
  cmpq $1025, %r12
  jne .LBB1_3
  movl $1, %edi
  movl $1, %esi
  movq $-1, %rdx
  callq zng_combine
  movl %eax, %ecx
  movl $2, %eax
  cmpl $-1, %ecx
  jne .LBB1_35
  movl $1, %edi
  movl $1, %esi
  xorl %edx, %edx
  callq zng_combine
  movl %eax, %ecx
  movl $3, %eax
  cmpl $1, %ecx
  jne .LBB1_35
  movl $1, %edx
  movl $1, %edi
  movl $65537, %esi
  callq zng_combine
  cmpl $65537, %eax
  jne .LBB1_36
  movl $65520, %edx
  movl $1, %edi
  movl $-1048575, %esi
  callq zng_combine
  cmpl $-1048575, %eax
  jne .LBB1_36
  movl $65521, %edx
  movl $1, %edi
  movl $1, %esi
  callq zng_combine
  cmpl $1, %eax
  jne .LBB1_36
  movl $65522, %edx
  movl $1, %edi
  movl $65537, %esi
  callq zng_combine
  cmpl $65537, %eax
  jne .LBB1_36
  movl $2147483648, %edx
  movl $1, %edi
  movl $-2140602367, %esi
  callq zng_combine
  cmpl $-2140602367, %eax
  jne .LBB1_36
  movabsq $9223372036854775807, %rdx
  movl $1, %edi
  movl $-489160703, %esi
  callq zng_combine
  cmpl $-489160703, %eax
  movl $3, %eax
  jne .LBB1_35
  xorl %eax, %eax
  leaq checks(%rip), %rbx
  leaq data(%rip), %rcx
  movl $2147975281, %edx
  xorl %esi, %esi
  jmp .LBB1_40
.LBB1_34:
  movl $1, %eax
.LBB1_35:
  addq $8, %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  popq %rbp
  retq
.LBB1_36:
  movl $3, %eax
  jmp .LBB1_35
.LBB1_38:
  movl $1, %edi
.LBB1_39:
  movl %edi, (%rbx,%rsi,4)
  incq %rsi
  addq $16, %rax
  cmpq $64, %rsi
  je .LBB1_47
.LBB1_40:
  testq %rsi, %rsi
  je .LBB1_38
  movl $1, %r9d
  xorl %edi, %edi
  xorl %r8d, %r8d
.LBB1_42:
  movzbl (%r8,%rcx), %r10d
  addl %r10d, %r9d
  movq %r9, %r10
  imulq %rdx, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %r9d
  addl %r9d, %edi
  movq %rdi, %r10
  imulq %rdx, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %edi
  movzbl 1(%r8,%rcx), %r10d
  addl %r9d, %r10d
  imulq $131103, %r10, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r10d
  addl %r10d, %edi
  imulq $131103, %rdi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %edi
  movzbl 2(%r8,%rcx), %r11d
  addl %r10d, %r11d
  imulq $131103, %r11, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r11d
  addl %r11d, %edi
  imulq $131103, %rdi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %edi
  movzbl 3(%r8,%rcx), %r9d
  addl %r11d, %r9d
  imulq $131103, %r9, %r10
  shrq $33, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %r9d
  addl %r9d, %edi
  imulq $131103, %rdi, %r10
  shrq $33, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %edi
  addq $4, %r8
  cmpq %r8, %rax
  jne .LBB1_42
  shll $16, %edi
  orl %r9d, %edi
  jmp .LBB1_39
.LBB1_47:
  movl $1, %eax
  xorl %ebp, %ebp
.LBB1_48:
  movl %ebp, %edx
  xorl %eax, %edx
  andl $63, %edx
  movl (%rbx,%rdx,4), %esi
  shll $4, %edx
  movl %eax, %edi
  callq zng_combine
  incl %ebp
  cmpl $50000000, %ebp
  jne .LBB1_48
  leaq .L.str(%rip), %rdi
  movl %eax, %esi
  xorl %eax, %eax
  callq printf@PLT
  xorl %eax, %eax
  jmp .LBB1_35

.L.str:


zng_combine:
  testq %rdx, %rdx
  js .LBB0_1
  movabsq $4223091239536077, %rax
  mulxq %rax, %rax, %rax
  movq %rdx, %rcx
  subq %rax, %rcx
  shrq %rcx
  addq %rax, %rcx
  shrq $15, %rcx
  imull $65521, %ecx, %eax
  subl %eax, %edx
  movzwl %di, %eax
  movzwl %si, %ecx
  leal (%rax,%rcx), %r8d
  addl $65520, %r8d
  leal (%rax,%rcx), %r9d
  decl %r9d
  addl %eax, %ecx
  addl $-65522, %ecx
  imull %edx, %eax
  movl $2147975281, %r10d
  imulq %rax, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r10d
  subl %r10d, %eax
  shrl $16, %edi
  shrl $16, %esi
  addl %edi, %esi
  subl %edx, %esi
  leal (%rsi,%rax), %edx
  addl $65521, %edx
  cmpl $65521, %r9d
  cmovbl %r9d, %ecx
  cmpl $65521, %r8d
  movl $65520, %edi
  cmovael %ecx, %edi
  cmpl $131042, %edx
  leal -65521(%rsi,%rax), %ecx
  cmovbl %edx, %ecx
  movl %ecx, %edx
  shll $16, %edx
  leal 983040(%rdx), %eax
  cmpl $65521, %ecx
  cmovbl %edx, %eax
  orl %edi, %eax
  retq
.LBB0_1:
  movl $-1, %eax
  retq

.LCPI1_0:
main:
  pushq %rbp
  pushq %r15
  pushq %r14
  pushq %r12
  pushq %rbx
  subq $16, %rsp
  vstmxcsr 12(%rsp)
  orl $32832, 12(%rsp)
  vldmxcsr 12(%rsp)
  xorl %eax, %eax
  vmovdqu .LCPI1_0(%rip), %xmm0
.LBB1_1:
  vmovd %eax, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, data(%rax)
  leal 80(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, data+16(%rax)
  leal -96(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, data+32(%rax)
  leal -16(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, data+48(%rax)
  leaq 48(%rax), %rcx
  addq $64, %rax
  cmpq $1008, %rcx
  jb .LBB1_1
  xorl %r14d, %r14d
  movl $1, %edx
  movq $-1024, %rax
  movl $2147975281, %ecx
.LBB1_3:
  movzbl data+1024(%rax), %esi
  addl %edx, %esi
  movq %rsi, %rdx
  imulq %rcx, %rdx
  shrq $47, %rdx
  imull $65521, %edx, %edx
  subl %edx, %esi
  addl %esi, %r14d
  movq %r14, %rdx
  imulq %rcx, %rdx
  shrq $47, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r14d
  movzbl data+1025(%rax), %edx
  addl %esi, %edx
  imulq $131103, %rdx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %r14d
  imulq $131103, %r14, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r14d
  movzbl data+1026(%rax), %esi
  addl %edx, %esi
  imulq $131103, %rsi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %esi
  addl %esi, %r14d
  imulq $131103, %r14, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r14d
  movzbl data+1027(%rax), %edx
  addl %esi, %edx
  imulq $131103, %rdx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %r14d
  imulq $131103, %r14, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r14d
  movzbl data+1028(%rax), %esi
  addl %edx, %esi
  imulq $131103, %rsi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %esi
  addl %esi, %r14d
  imulq $131103, %r14, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r14d
  movzbl data+1029(%rax), %edx
  addl %esi, %edx
  imulq $131103, %rdx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %r14d
  imulq $131103, %r14, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r14d
  movzbl data+1030(%rax), %esi
  addl %edx, %esi
  imulq $131103, %rsi, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %esi
  addl %esi, %r14d
  imulq $131103, %r14, %rdx
  shrq $33, %rdx
  imull $65521, %edx, %edx
  subl %edx, %r14d
  movzbl data+1031(%rax), %edx
  addl %esi, %edx
  imulq $131103, %rdx, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %r14d
  imulq $131103, %r14, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r14d
  addq $8, %rax
  jne .LBB1_3
  movabsq $9223372036854775800, %rbx
  shll $16, %r14d
  orl %edx, %r14d
  xorl %r15d, %r15d
  movl $2147975281, %r12d
.LBB1_6:
  movl $1, %eax
  testq %r15, %r15
  je .LBB1_7
  cmpq $8, %r15
  jae .LBB1_32
  movl $1, %esi
  xorl %edi, %edi
  jmp .LBB1_34
.LBB1_7:
  movl $1024, %edx
  movl $1, %edi
  jmp .LBB1_8
.LBB1_32:
  movq %r15, %rcx
  andq $-8, %rcx
  movl $1, %esi
  xorl %edx, %edx
  xorl %edi, %edi
.LBB1_33:
  movzbl data(%rdx), %r8d
  addl %esi, %r8d
  movq %r8, %rsi
  imulq %r12, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r8d
  addl %r8d, %edi
  movq %rdi, %rsi
  imulq %r12, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edi
  movzbl data+1(%rdx), %esi
  addl %r8d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  addl %esi, %edi
  imulq $131103, %rdi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  movzbl data+2(%rdx), %r8d
  addl %esi, %r8d
  imulq $131103, %r8, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r8d
  addl %r8d, %edi
  imulq $131103, %rdi, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edi
  movzbl data+3(%rdx), %esi
  addl %r8d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  addl %esi, %edi
  imulq $131103, %rdi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  movzbl data+4(%rdx), %r8d
  addl %esi, %r8d
  imulq $131103, %r8, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r8d
  addl %r8d, %edi
  imulq $131103, %rdi, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edi
  movzbl data+5(%rdx), %esi
  addl %r8d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  addl %esi, %edi
  imulq $131103, %rdi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  movzbl data+6(%rdx), %r8d
  addl %esi, %r8d
  imulq $131103, %r8, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %r8d
  addl %r8d, %edi
  imulq $131103, %rdi, %rsi
  shrq $33, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edi
  movzbl data+7(%rdx), %esi
  addl %r8d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  addl %esi, %edi
  imulq $131103, %rdi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %edi
  addq $8, %rdx
  cmpq %rdx, %rcx
  jne .LBB1_33
.LBB1_34:
  movq %r15, %rcx
  andq %rbx, %rcx
  cmpq %r15, %rcx
  jae .LBB1_35
.LBB1_36:
  movzbl data(%rcx), %edx
  addl %esi, %edx
  movq %rdx, %rsi
  imulq %r12, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edx
  addl %edx, %edi
  movq %rdi, %rsi
  imulq %r12, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %esi
  subl %esi, %edi
  incq %rcx
  movl %edx, %esi
  cmpq %rcx, %r15
  jne .LBB1_36
  jmp .LBB1_37
.LBB1_35:
  movl %esi, %edx
.LBB1_37:
  shll $16, %edi
  orl %edx, %edi
  movq %r15, %rdx
  subq $1024, %rdx
  jne .LBB1_38
  movl $1, %esi
  xorl %edx, %edx
  jmp .LBB1_14
.LBB1_38:
  negq %rdx
.LBB1_8:
  xorl %esi, %esi
  cmpq $8, %rdx
  jb .LBB1_11
  movq %rdx, %rcx
  shrq $3, %rcx
  movl $1, %eax
  xorl %r8d, %r8d
  xorl %esi, %esi
.LBB1_10:
  movzbl data(%r15,%r8,8), %r9d
  addl %eax, %r9d
  movq %r9, %rax
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %eax
  subl %eax, %r9d
  addl %r9d, %esi
  movq %rsi, %rax
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl data+1(%r15,%r8,8), %eax
  addl %r9d, %eax
  imulq $131103, %rax, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %eax
  addl %eax, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+2(%r15,%r8,8), %r9d
  addl %eax, %r9d
  imulq $131103, %r9, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl data+3(%r15,%r8,8), %eax
  addl %r9d, %eax
  imulq $131103, %rax, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %eax
  addl %eax, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+4(%r15,%r8,8), %r9d
  addl %eax, %r9d
  imulq $131103, %r9, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl data+5(%r15,%r8,8), %eax
  addl %r9d, %eax
  imulq $131103, %rax, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %eax
  addl %eax, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+6(%r15,%r8,8), %r9d
  addl %eax, %r9d
  imulq $131103, %r9, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %rax
  shrq $33, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  movzbl data+7(%r15,%r8,8), %eax
  addl %r9d, %eax
  imulq $131103, %rax, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %eax
  addl %eax, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  incq %r8
  cmpq %r8, %rcx
  jne .LBB1_10
.LBB1_11:
  movq %rdx, %rcx
  andq $-8, %rcx
  cmpq %rdx, %rcx
  jae .LBB1_12
.LBB1_39:
  movzbl data(%r15,%rcx), %r8d
  addl %eax, %r8d
  movq %r8, %rax
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %eax
  subl %eax, %r8d
  addl %r8d, %esi
  movq %rsi, %rax
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %eax
  subl %eax, %esi
  incq %rcx
  movl %r8d, %eax
  cmpq %rcx, %rdx
  jne .LBB1_39
  jmp .LBB1_40
.LBB1_12:
  movl %eax, %r8d
.LBB1_40:
  shll $16, %esi
  orl %r8d, %esi
.LBB1_14:
  callq zng_combine
  cmpl %r14d, %eax
  jne .LBB1_15
  incq %r15
  cmpq $1025, %r15
  jne .LBB1_6
  movl $1, %edi
  movl $1, %esi
  movq $-1, %rdx
  callq zng_combine
  movl $2, %ebp
  cmpl $-1, %eax
  jne .LBB1_29
  movl $1, %edi
  movl $1, %esi
  xorl %edx, %edx
  callq zng_combine
  movl $3, %ebp
  cmpl $1, %eax
  jne .LBB1_29
  movl $1, %edx
  movl $1, %edi
  movl $65537, %esi
  callq zng_combine
  cmpl $65537, %eax
  jne .LBB1_29
  movl $65520, %edx
  movl $1, %edi
  movl $-1048575, %esi
  callq zng_combine
  cmpl $-1048575, %eax
  jne .LBB1_29
  movl $65521, %edx
  movl $1, %edi
  movl $1, %esi
  callq zng_combine
  cmpl $1, %eax
  jne .LBB1_29
  movl $65522, %edx
  movl $1, %edi
  movl $65537, %esi
  callq zng_combine
  cmpl $65537, %eax
  jne .LBB1_29
  movl $2147483648, %edx
  movl $1, %edi
  movl $-2140602367, %esi
  callq zng_combine
  cmpl $-2140602367, %eax
  jne .LBB1_29
  addq $7, %rbx
  movl $1, %edi
  movl $-489160703, %esi
  movq %rbx, %rdx
  callq zng_combine
  cmpl $-489160703, %eax
  jne .LBB1_29
  xorl %eax, %eax
  movl $2147975281, %ecx
  xorl %edx, %edx
  jmp .LBB1_25
.LBB1_15:
  movl $1, %ebp
.LBB1_29:
  movl %ebp, %eax
  addq $16, %rsp
  popq %rbx
  popq %r12
  popq %r14
  popq %r15
  popq %rbp
  retq
.LBB1_26:
  movl $1, %esi
.LBB1_44:
  movl %esi, checks(,%rdx,4)
  leaq 1(%rdx), %rsi
  addq $2, %rax
  cmpq $63, %rdx
  movq %rsi, %rdx
  je .LBB1_45
.LBB1_25:
  testq %rdx, %rdx
  je .LBB1_26
  movl $1, %r8d
  xorl %esi, %esi
  xorl %edi, %edi
.LBB1_42:
  movzbl data(,%rdi,8), %r9d
  addl %r8d, %r9d
  movq %r9, %r8
  imulq %rcx, %r8
  shrq $47, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %r9d
  addl %r9d, %esi
  movq %rsi, %r8
  imulq %rcx, %r8
  shrq $47, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  movzbl data+1(,%rdi,8), %r8d
  addl %r9d, %r8d
  imulq $131103, %r8, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r8d
  addl %r8d, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+2(,%rdi,8), %r9d
  addl %r8d, %r9d
  imulq $131103, %r9, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  movzbl data+3(,%rdi,8), %r8d
  addl %r9d, %r8d
  imulq $131103, %r8, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r8d
  addl %r8d, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+4(,%rdi,8), %r9d
  addl %r8d, %r9d
  imulq $131103, %r9, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  movzbl data+5(,%rdi,8), %r8d
  addl %r9d, %r8d
  imulq $131103, %r8, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r8d
  addl %r8d, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  movzbl data+6(,%rdi,8), %r9d
  addl %r8d, %r9d
  imulq $131103, %r9, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %r9d
  addl %r9d, %esi
  imulq $131103, %rsi, %r8
  shrq $33, %r8
  imull $65521, %r8d, %r8d
  subl %r8d, %esi
  movzbl data+7(,%rdi,8), %r8d
  addl %r9d, %r8d
  imulq $131103, %r8, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %r8d
  addl %r8d, %esi
  imulq $131103, %rsi, %r9
  shrq $33, %r9
  imull $65521, %r9d, %r9d
  subl %r9d, %esi
  incq %rdi
  cmpq %rdi, %rax
  jne .LBB1_42
  shll $16, %esi
  orl %r8d, %esi
  jmp .LBB1_44
.LBB1_45:
  movl $1, %eax
  xorl %ebx, %ebx
.LBB1_27:
  movl %ebx, %edx
  xorl %eax, %edx
  andl $63, %edx
  movl checks(,%rdx,4), %esi
  shll $4, %edx
  movl %eax, %edi
  callq zng_combine
  incl %ebx
  cmpl $50000000, %ebx
  jne .LBB1_27
  xorl %ebp, %ebp
  movl $.L.str, %edi
  movl %eax, %esi
  xorl %eax, %eax
  callq printf
  jmp .LBB1_29

.L.str:


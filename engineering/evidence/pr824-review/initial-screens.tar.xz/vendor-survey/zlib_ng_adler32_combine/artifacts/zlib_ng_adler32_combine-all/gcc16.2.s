zng_combine:
  movl %esi, %r8d
  movq %rdx, %rsi
  testq %rdx, %rdx
  js .L6
  movabsq $-9221260491235007769, %rax
  imulq %rdx
  movq %rsi, %rax
  sarq $63, %rax
  leaq (%rdx,%rsi), %rcx
  movzwl %r8w, %edx
  shrl $16, %r8d
  sarq $15, %rcx
  subq %rax, %rcx
  imulq $65521, %rcx, %rcx
  subq %rcx, %rsi
  movzwl %di, %ecx
  shrl $16, %edi
  movl %ecx, %r9d
  addl %r8d, %edi
  imull %esi, %r9d
  subl %esi, %edi
  movl $2147975281, %esi
  movl %r9d, %eax
  imulq %rsi, %rax
  movl $65520, %esi
  shrq $47, %rax
  imull $65521, %eax, %eax
  subl %eax, %r9d
  addl %r9d, %edi
  leal 65521(%rdi), %eax
  addl %ecx, %edx
  je .L3
  leal -1(%rdx), %esi
  subl $65522, %edx
  cmpl $65520, %esi
  cmova %edx, %esi
.L3:
  subl $65521, %edi
  cmpl $131041, %eax
  cmova %edi, %eax
  cmpl $65520, %eax
  leal -65521(%rax), %edx
  cmova %edx, %eax
  sall $16, %eax
  orl %esi, %eax
  ret
.L6:
  movl $-1, %eax
  ret
.LC10:
main:
  pushq %rbp
  movl $8, %ecx
  vpcmpeqd %ymm3, %ymm3, %ymm3
  movl $data+1024, %edx
  vmovd %ecx, %xmm9
  movl $16, %ecx
  movl $data, %eax
  vmovd %ecx, %xmm8
  movl $24, %ecx
  vpbroadcastd %xmm9, %ymm9
  vmovd %ecx, %xmm7
  movq %rsp, %rbp
  pushq %r15
  movl $-117901064, %ecx
  pushq %r14
  vmovd %ecx, %xmm6
  movl $185273099, %ecx
  vpxor %xmm2, %xmm2, %xmm2
  pushq %r13
  vmovd %ecx, %xmm5
  movl $32, %ecx
  vpbroadcastd %xmm8, %ymm8
  pushq %r12
  vmovd %ecx, %xmm4
  vpbroadcastd %xmm7, %ymm7
  vpbroadcastd %xmm6, %ymm6
  pushq %rbx
  vpsrlw $8, %ymm3, %ymm3
  vpbroadcastd %xmm5, %ymm5
  vpbroadcastd %xmm4, %ymm4
  andq $-32, %rsp
  subq $64, %rsp
  vmovdqa .LC0(%rip), %ymm1
.L11:
  vpaddd %ymm9, %ymm1, %ymm0
  vpblendw $170, %ymm2, %ymm1, %ymm10
  vpaddd %ymm7, %ymm1, %ymm11
  addq $32, %rax
  vpblendw $170, %ymm2, %ymm0, %ymm0
  vpblendw $170, %ymm2, %ymm11, %ymm11
  vpackusdw %ymm0, %ymm10, %ymm10
  vpaddd %ymm8, %ymm1, %ymm0
  vpaddd %ymm4, %ymm1, %ymm1
  vpblendw $170, %ymm2, %ymm0, %ymm0
  vpermq $216, %ymm10, %ymm10
  vpackusdw %ymm11, %ymm0, %ymm0
  vpand %ymm10, %ymm3, %ymm10
  vpermq $216, %ymm0, %ymm0
  vpand %ymm0, %ymm3, %ymm0
  vpackuswb %ymm0, %ymm10, %ymm10
  vpermq $216, %ymm10, %ymm10
  vpsllw $3, %ymm10, %ymm0
  vpand %ymm0, %ymm6, %ymm0
  vpaddb %ymm10, %ymm0, %ymm0
  vpaddb %ymm0, %ymm0, %ymm0
  vpaddb %ymm0, %ymm0, %ymm0
  vpaddb %ymm10, %ymm0, %ymm0
  vpaddb %ymm5, %ymm0, %ymm0
  vmovdqa %ymm0, -32(%rax)
  cmpq %rax, %rdx
  jne .L11
  movl $data, %esi
  xorl %r10d, %r10d
  movl $1, %eax
  movl $2147975281, %edi
.L12:
  movzbl (%rsi), %ecx
  addq $1, %rsi
  addl %ecx, %eax
  movq %rax, %rcx
  imulq %rdi, %rax
  shrq $47, %rax
  imull $65521, %eax, %r8d
  movl %ecx, %eax
  subl %r8d, %eax
  addl %eax, %r10d
  movl %r10d, %r10d
  movq %r10, %rcx
  imulq %rdi, %r10
  shrq $47, %r10
  imull $65521, %r10d, %r8d
  subl %r8d, %ecx
  movl %ecx, %r10d
  cmpq %rsi, %rdx
  jne .L12
  sall $16, %r10d
  movl $data, %r13d
  xorl %r14d, %r14d
  movl $2147975281, %r12d
  orl %eax, %r10d
.L13:
  movl $data, %ecx
  xorl %edi, %edi
  movl $1, %eax
  testq %r14, %r14
  je .L42
.L14:
  movzbl (%rcx), %edx
  addq $1, %rcx
  addl %edx, %eax
  movq %rax, %rdx
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %esi
  movl %edx, %eax
  subl %esi, %eax
  addl %eax, %edi
  movl %edi, %edi
  movq %rdi, %rdx
  imulq %r12, %rdi
  shrq $47, %rdi
  imull $65521, %edi, %esi
  movl %edx, %edi
  subl %esi, %edi
  cmpq %rcx, %r13
  jne .L14
  sall $16, %edi
  orl %eax, %edi
  cmpq $1024, %r14
  je .L15
  movl $1024, %ecx
  movl $1024, %r9d
  movq %r14, %rax
  subq %r14, %rcx
  subl %r14d, %r9d
.L18:
  leaq data(%rax), %r8
  xorl %esi, %esi
  movl $1, %eax
  addq %r8, %r9
.L16:
  movzbl (%r8), %edx
  addq $1, %r8
  addl %edx, %eax
  movq %rax, %rdx
  imulq %r12, %rax
  shrq $47, %rax
  imull $65521, %eax, %r15d
  movl %edx, %eax
  subl %r15d, %eax
  addl %eax, %esi
  movl %esi, %esi
  movq %rsi, %rdx
  imulq %r12, %rsi
  shrq $47, %rsi
  imull $65521, %esi, %r15d
  movl %edx, %esi
  subl %r15d, %esi
  cmpq %r8, %r9
  jne .L16
  sall $16, %esi
  movq %rcx, %rdx
  orl %eax, %esi
  call zng_combine
  cmpl %r10d, %eax
  jne .L17
  addq $1, %r14
  addq $1, %r13
  jmp .L13
.L15:
  xorl %edx, %edx
  movl $1, %esi
  call zng_combine
  cmpl %eax, %r10d
  je .L27
.L17:
  movl $1, %eax
  vzeroupper
.L10:
  leaq -40(%rbp), %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  popq %rbp
  ret
.L42:
  xorl %eax, %eax
  movl $1024, %ecx
  movl $1, %edi
  movl $1024, %r9d
  jmp .L18
.L27:
  movq $-1, %rdx
  movl $1, %esi
  movl $1, %edi
  call zng_combine
  addl $1, %eax
  jne .L29
  vmovdqa .LC8(%rip), %ymm0
  movq %rsp, %r11
  leaq 56(%rsp), %r12
  movabsq $9223372036854775807, %rax
  movq %rax, 48(%rsp)
  movl $65521, %ebx
  vmovdqa %ymm0, (%rsp)
  vmovdqa .LC9(%rip), %xmm0
  vmovdqa %xmm0, 32(%rsp)
.L20:
  movq (%r11), %rcx
  movl $1, %edi
  movq %rcx, %rax
  cqto
  idivq %rbx
  sall $16, %edx
  orl $1, %edx
  movl %edx, %r10d
  movq %rcx, %rdx
  movl %r10d, %esi
  call zng_combine
  cmpl %r10d, %eax
  jne .L30
  addq $8, %r11
  cmpq %r11, %r12
  jne .L20
  movl $checks, %r9d
  xorl %r8d, %r8d
  movl $2147975281, %edi
.L25:
  testl %r8d, %r8d
  je .L21
.L24:
  xorl %esi, %esi
  xorl %edx, %edx
  movl $1, %eax
.L22:
  movzbl data(%rsi), %ecx
  addq $1, %rsi
  addl %ecx, %eax
  movq %rax, %rcx
  imulq %rdi, %rax
  shrq $47, %rax
  imull $65521, %eax, %r10d
  movl %ecx, %eax
  subl %r10d, %eax
  addl %eax, %edx
  movl %edx, %edx
  movq %rdx, %rcx
  imulq %rdi, %rdx
  shrq $47, %rdx
  imull $65521, %edx, %r10d
  subl %r10d, %ecx
  movl %ecx, %edx
  cmpl %r8d, %esi
  jb .L22
  sall $16, %edx
  addl $16, %r8d
  addq $4, %r9
  orl %eax, %edx
  movl %edx, -4(%r9)
  cmpl $1024, %r8d
  jne .L25
  xorl %r10d, %r10d
  movl $1, %edi
.L26:
  movl %edi, %edx
  xorl %r10d, %edx
  addl $1, %r10d
  andl $63, %edx
  movl %edx, %eax
  movl checks(,%rdx,4), %esi
  sall $4, %eax
  movq %rax, %rdx
  call zng_combine
  movl %eax, %edi
  cmpl $50000000, %r10d
  jne .L26
  movl %eax, %esi
  movl $.LC10, %edi
  xorl %eax, %eax
  vzeroupper
  call printf
  xorl %eax, %eax
  jmp .L10
.L21:
  movl $1, (%r9)
  movl $16, %r8d
  addq $4, %r9
  jmp .L24
.L29:
  movl $2, %eax
  vzeroupper
  jmp .L10
.L30:
  movl $3, %eax
  vzeroupper
  jmp .L10
.LC0:
.LC8:
.LC9:

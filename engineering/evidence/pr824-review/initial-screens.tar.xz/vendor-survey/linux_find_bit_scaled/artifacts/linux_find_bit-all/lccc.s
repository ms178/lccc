.Lstr0:

.LCA_0:
.LCA_1:
.LCA_2:
.LCA_3:

linux_bitmap_a:
linux_bitmap_b:

linux_find_next_andnot_bit:
    pushq %r12
    pushq %rbp
    subq $24, %rsp
    cmpq %rdx, %rcx
jb .LBB2
.LBB1:
    movq %rdx, %rax
.L__lccc_epilogue_1:
    addq $24, %rsp
    popq %rbp
    popq %r12
    ret
.LBB2:
    movq %rcx, %r9
    andq $63, %r9
    movq $-1, %r11
    shlxq %r9, %r11, %r11
    movq %rcx, %r10
    shrq $6, %r10
    movq (%rdi, %r10, 8), %r12
    movq (%rsi, %r10, 8), %rax
    andnq %r12, %rax, %r9
    movq %r9, %rcx
    andq %r11, %rcx
.LBB3:
    testq %rcx, %rcx
jne .LBB6
.LBB4:
    leaq 1(%r10), %r9
    shlq $6, %r9
    cmpq %rdx, %r9
jb .LBB5
.LBB7:
    movq %rdx, %rax
    jmp .L__lccc_epilogue_1
.LBB5:
    addq $1, %r10
    movq (%rdi, %r10, 8), %rbp
    movq (%rsi, %r10, 8), %rax
    andnq %rbp, %rax, %rcx
    testq %rcx, %rcx
je .LBB4
.LBB6:
    shlq $6, %r10
    tzcntq %rcx, %r11
    movl %r11d, %edi
    addq %rdi, %r10
    cmpq %rdx, %r10
    movq %rdx, %rcx
    cmovbq %r10, %rcx
    movq %rcx, %rax
    jmp .L__lccc_epilogue_1

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $24, %rsp
    leaq .LCA_2(%rip), %rdi
    leaq .LCA_3(%rip), %rsi
    movl $192, %edx
    xorl %ecx, %ecx
    call linux_find_next_andnot_bit
    cmpq $5, %rax
jne .LBB10
.LBB9:
    leaq .LCA_2(%rip), %rdi
    leaq .LCA_3(%rip), %rsi
    movl $192, %edx
    movl $6, %ecx
    call linux_find_next_andnot_bit
    cmpq $192, %rax
    movl $0, %ecx
    movl $1, %r8d
    cmovnel %ecx, %r8d
    testl %r8d, %r8d
jne .LBB11
.LBB10:
    movl $2, %eax
.L__lccc_epilogue_2:
    addq $24, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB11:
    leaq linux_bitmap_b(%rip), %rbx
    leaq linux_bitmap_a(%rip), %r12
    xorl %r13d, %r13d
.LBB12:
    cmpq $16384, %r13
jae .LBB16
.LBB13:
    movq $0, (%r12, %r13, 8)
    movq $-1, (%rbx, %r13, 8)
    movq %r13, %r11
    andq $63, %r11
    cmpq $5, %r11
jne .LBB15
.LBB14:
    imulq $13, %r13, %r10
    leaq 7(%r10), %r8
    andq $63, %r8
    movq %r13, %rdi
    shlq $3, %rdi
    movl $1, %eax
    movq %r8, %rcx
    shlxq %rcx, %rax, %rax
    movq %rax, (%r12, %r13, 8)
    movq $0, (%rbx, %r13, 8)
.LBB15:
    addq $1, %r13
    cmpq $16384, %r13
jb .LBB13
.LBB16:
    xorl %r14d, %r14d
    xorl %r11d, %r11d
.LBB17:
    cmpl $65536, %r14d
jae .LBB21
.LBB18:
    movq %r14, %rax
    andq $63, %rax
    movl %eax, %r15d
    movl %r14d, %ebp
    shlq $19, %rbp
    movq %r11, %r12
.LBB19:
    leaq linux_bitmap_a(%rip), %rdi
    leaq linux_bitmap_b(%rip), %rsi
    movl $1048576, %edx
    movq %r15, %rcx
    call linux_find_next_andnot_bit
    leaq (%rax, %rbp, 1), %rdi
    movq %r12, %rsi
    xorq %rdi, %rsi
    leaq 1(%rax), %rdx
    cmpq $1048576, %rax
    movq %r12, %r11
    cmovbq %rsi, %r11
    cmovbq %rdx, %r15
    movq %r11, %r12
jb .LBB19
.LBB20:
    movl %r14d, %r10d
    imulq $13, %r10, %r10
    andq $255, %r10
    shlq $6, %r10
    addq $5, %r10
    imull $7, %r14d, %r8d
    andl $63, %r8d
    movl $1, %r9d
    shlxq %r8, %r9, %r9
    xorq (%rbx, %r10, 8), %r9
    movq %r9, (%rbx, %r10, 8)
    addl $1, %r14d
    cmpl $65536, %r14d
jb .LBB18
.LBB21:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    jmp .L__lccc_epilogue_2



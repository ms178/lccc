.LC0:
main:
  pushq %r15
  xorl %r8d, %r8d
  movl $42, %edx
  xorl %edi, %edi
  pushq %r14
  pushq %r13
  pushq %r12
  pushq %rbp
  pushq %rbx
  subq $248, %rsp
.L3:
  imull $1664525, %edx, %edx
  addl $1013904223, %edx
  movl %edx, %eax
  shrl $2, %eax
  imulq $381774871, %rax, %rax
  shrq $34, %rax
  imull $180, %eax, %ecx
  movl %edx, %eax
  subl %ecx, %eax
  leaq strings(%r8), %rcx
  leal 10(%rax), %r10d
  leaq strings+10(%r8,%rax), %r9
.L2:
  imull $1664525, %edx, %edx
  addq $1, %rcx
  leal 1013904223(%rdx), %eax
  movq %rax, %rdx
  imulq $1321528399, %rax, %rax
  movl %edx, %esi
  shrq $35, %rax
  imull $26, %eax, %eax
  subl %eax, %esi
  leal 97(%rsi), %eax
  movb %al, -1(%rcx)
  cmpq %r9, %rcx
  jne .L2
  movl %edi, %eax
  movl %r10d, %ecx
  addl $1, %edi
  addq $200, %r8
  imulq $200, %rax, %rax
  movb $0, strings(%rcx,%rax)
  cmpl $100000, %edi
  jne .L3
  movl $50, %r14d
  xorl %r13d, %r13d
  movl $strings+20000000, %ebp
.L4:
  movl $strings, %r12d
.L5:
  movq %r12, %rdi
  addq $200, %r12
  call strlen
  leaq 0(%r13,%rax), %rbx
  movq %rbx, %r13
  cmpq %rbp, %r12
  jne .L5
  subl $1, %r14d
  jne .L4
  movl $strings+19999800, %r12d
  movl $strings, %r14d
  xorl %r13d, %r13d
.L7:
  movq %r14, %rdi
  addq $200, %r14
  movq %r14, %rsi
  call strcmp
  xorl %edx, %edx
  testl %eax, %eax
  setg %dl
  shrl $31, %eax
  subl %eax, %edx
  movslq %edx, %rdx
  addq %rdx, %r13
  cmpq %r12, %r14
  jne .L7
  movl $6513249, 28(%rsp)
  movl $strings, %r8d
  xorl %r15d, %r15d
  leaq 28(%rsp), %rdi
.L16:
  movq %r8, %rsi
  movq %rdi, %rax
.L8:
  addq $1, %rax
  cmpb $0, (%rax)
  jne .L8
  cmpb $0, (%r8)
  je .L20
.L9:
  movzbl (%rsi), %edx
  movl $97, %ecx
  xorl %eax, %eax
  testb %dl, %dl
  je .L14
.L15:
  cmpb %cl, %dl
  jne .L14
  movzbl 1(%rsi,%rax), %edx
  addq $1, %rax
  movzbl (%rdi,%rax), %ecx
  testb %dl, %dl
  je .L11
  testb %cl, %cl
  jne .L15
.L12:
  addq $1, %r15
.L20:
  addq $200, %r8
  cmpq %rbp, %r8
  jne .L16
  movl $50, 12(%rsp)
  xorl %r12d, %r12d
.L17:
  movl $strings, %r14d
.L18:
  movq %r14, %rdi
  call strlen
  movq %r14, %rsi
  leaq 32(%rsp), %rdi
  addq $200, %r14
  leal 1(%rax), %edx
  call memcpy
  movsbq 32(%rsp), %rax
  addq %rax, %r12
  cmpq %r14, %rbp
  jne .L18
  subl $1, 12(%rsp)
  jne .L17
  movq %r12, %r8
  movq %r15, %rcx
  movq %r13, %rdx
  movq %rbx, %rsi
  movl $.LC0, %edi
  xorl %eax, %eax
  call printf
  addq $248, %rsp
  xorl %eax, %eax
  popq %rbx
  popq %rbp
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  ret
.L11:
  testb %cl, %cl
  je .L12
.L14:
  addq $1, %rsi
  cmpb $0, (%rsi)
  jne .L9
  jmp .L20

.LCPI0_0:
.LCPI0_1:
.LCPI0_2:
.LCPI0_6:
.LCPI0_3:
.LCPI0_4:
main:
  pushq %rbp
  pushq %r15
  pushq %r14
  pushq %r13
  pushq %r12
  pushq %rbx
  subq $88, %rsp
  vstmxcsr 8(%rsp)
  orl $32832, 8(%rsp)
  vldmxcsr 8(%rsp)
  leaq -7(%rsp), %r12
  xorl %r13d, %r13d
  leaq 24(%rsp), %rbx
  leaq 40(%rsp), %r14
  vmovdqu .LCPI0_4(%rip), %xmm4
  vpbroadcastq .LCPI0_2(%rip), %ymm0
  vmovdqu %ymm0, 48(%rsp)
.LBB0_1:
  movq $0, 40(%rsp)
  movq check_known_values.values(,%r13,8), %rbp
  cmpq $1, %r13
  ja .LBB0_3
  movb %bpl, 24(%rsp)
  movl $1, %r15d
  jmp .LBB0_14
.LBB0_3:
  cmpq $3, %r13
  ja .LBB0_5
  movl %ebp, %eax
  shrl $7, %eax
  orb $-128, %al
  movb %al, 24(%rsp)
  movl %ebp, %eax
  andb $127, %al
  movb %al, 25(%rsp)
  movl $2, %r15d
  jmp .LBB0_14
.LBB0_5:
  cmpq $8, %r13
  ja .LBB0_13
  movl $1, %r8d
  movq %r12, %r9
  xorl %r15d, %r15d
  movq %rbp, %rdi
  movq %rbp, %rcx
.LBB0_7:
  movq %r15, %rax
  movl %r8d, %esi
  movq %r9, %rdx
  movl %edi, %r8d
  orb $-128, %r8b
  incq %r15
  movb %r8b, 8(%rsp,%rax)
  shrq $7, %rcx
  leal 1(%rsi), %r8d
  incq %r9
  cmpq $127, %rdi
  movq %rcx, %rdi
  ja .LBB0_7
  andb $127, 8(%rsp)
  testl %eax, %eax
  js .LBB0_14
  movl %esi, %esi
  movq %rsi, %rcx
  andq $2147483632, %rcx
  je .LBB0_10
  xorl %edi, %edi
.LBB0_47:
  vmovdqu (%rdx), %xmm0
  vpshufb %xmm4, %xmm0, %xmm0
  vmovdqu %xmm0, 24(%rsp,%rdi)
  addq $16, %rdi
  addq $-16, %rdx
  cmpq %rcx, %rdi
  jb .LBB0_47
  cmpq %rcx, %rsi
  jne .LBB0_11
  jmp .LBB0_14
.LBB0_13:
  movb %bpl, 32(%rsp)
  vmovq %rbp, %xmm0
  vpbroadcastq %xmm0, %ymm0
  vpsrlvq .LCPI0_0(%rip), %ymm0, %ymm1
  vpsrlvq .LCPI0_1(%rip), %ymm0, %ymm0
  vmovdqu 48(%rsp), %ymm2
  vpand %ymm2, %ymm0, %ymm0
  vpand %ymm2, %ymm1, %ymm1
  vpackusdw %ymm0, %ymm1, %ymm0
  vextracti128 $1, %ymm0, %xmm1
  vpackusdw %xmm1, %xmm0, %xmm0
  vpshufd $216, %xmm0, %xmm0
  vpackuswb %xmm0, %xmm0, %xmm0
  vpor .LCPI0_3(%rip), %xmm0, %xmm0
  vmovq %xmm0, 24(%rsp)
  movl $9, %r15d
  jmp .LBB0_14
.LBB0_10:
  xorl %ecx, %ecx
.LBB0_11:
  incq %rax
  leaq 7(%rsp), %rdx
  subq %rcx, %rdx
.LBB0_12:
  movzbl (%rdx,%r15), %esi
  movb %sil, 24(%rsp,%rcx)
  incq %rcx
  decq %rdx
  cmpq %rcx, %rax
  jne .LBB0_12
.LBB0_14:
  movq %rbx, %rdi
  movq %r14, %rsi
  vzeroupper
  callq sqlite_get_varint
  movzbl %al, %eax
  cmpl %eax, %r15d
  jne .LBB0_16
  cmpq %rbp, 40(%rsp)
  jne .LBB0_16
  incq %r13
  cmpq $11, %r13
  vmovdqu .LCPI0_4(%rip), %xmm4
  jne .LBB0_1
  movl $0, sqlite_varint_offsets(%rip)
  movb $80, sqlite_varint_bytes(%rip)
  leaq -7(%rsp), %rax
  movl $53002960, %ecx
  movl $1, %edi
  movl $262143, %edx
  vpbroadcastq .LCPI0_6(%rip), %xmm0
  movl $1, %esi
  leaq 7(%rsp), %r13
  vmovdqu .LCPI0_0(%rip), %ymm5
  vmovdqu .LCPI0_1(%rip), %ymm6
.LBB0_27:
  movl %edi, %r8d
  cmpl $262144, %edi
  cmovbl %edx, %edi
  incl %edi
  jmp .LBB0_19
.LBB0_28:
  movl %esi, sqlite_varint_offsets(,%r8,4)
  movl %esi, %r9d
  movl %ecx, %r10d
  shrl $7, %r10d
  orb $-127, %r10b
  movb %r10b, sqlite_varint_bytes(%r9)
  movl %ecx, %r10d
  andb $127, %r10b
  movb %r10b, sqlite_varint_bytes+1(%r9)
  movl $2, %r12d
.LBB0_29:
  addl %esi, %r12d
  incq %r8
  movl %r12d, %esi
  cmpl %r8d, %edi
  je .LBB0_30
.LBB0_19:
  imull $1664525, %ecx, %ecx
  addl $1013904223, %ecx
  movl %r8d, %r9d
  imulq $954437177, %r9, %r9
  shrq $33, %r9
  leal (%r9,%r9,8), %r10d
  movl %r8d, %r9d
  subl %r10d, %r9d
  cmpl $7, %r9d
  ja .LBB0_52
  jmpq *.LJTI0_0(,%r9,8)
.LBB0_36:
  movl %ecx, %r10d
  andl $2080767, %r10d
  orl $16384, %r10d
  jmp .LBB0_37
.LBB0_52:
  movl %ecx, %r9d
  shlq $25, %r9
  orq %r8, %r9
  movl %esi, sqlite_varint_offsets(,%r8,4)
  movl %esi, %r10d
  movb %r8b, sqlite_varint_bytes+8(%r10)
  vmovq %r9, %xmm1
  vpbroadcastq %xmm1, %xmm1
  vmovq %r8, %xmm2
  vpbroadcastq %xmm2, %xmm2
  vpunpcklqdq %xmm1, %xmm2, %xmm3
  vinserti128 $1, %xmm1, %ymm3, %ymm3
  vinserti128 $1, %xmm2, %ymm1, %ymm1
  vpsrlvq %ymm5, %ymm3, %ymm2
  vpsrlvq %ymm6, %ymm1, %ymm1
  vmovdqu 48(%rsp), %ymm3
  vpand %ymm3, %ymm2, %ymm2
  vpand %ymm3, %ymm1, %ymm1
  vpackusdw %ymm1, %ymm2, %ymm1
  vextracti128 $1, %ymm1, %xmm2
  vpackusdw %xmm2, %xmm1, %xmm1
  vpshufd $216, %xmm1, %xmm1
  vpackuswb %xmm1, %xmm1, %xmm1
  vpor %xmm0, %xmm1, %xmm1
  vmovq %xmm1, sqlite_varint_bytes(%r10)
  movl $9, %r12d
  jmp .LBB0_29
.LBB0_21:
  movl %ecx, %r10d
  andl $266338303, %r10d
  orl $2097152, %r10d
  jmp .LBB0_37
.LBB0_22:
  movl %ecx, %r10d
  shlq $3, %r10
  orq $268435456, %r10
  jmp .LBB0_37
.LBB0_23:
  movl %ecx, %r10d
  orq $33554432, %r10
  shlq $10, %r10
  jmp .LBB0_37
.LBB0_24:
  movl %ecx, %r10d
  orq $33554432, %r10
  shlq $17, %r10
  jmp .LBB0_37
.LBB0_25:
  movl %ecx, %r10d
  orq $33554432, %r10
  shlq $24, %r10
.LBB0_37:
  movl %esi, sqlite_varint_offsets(,%r8,4)
  movl $1, %ebp
  movq %rax, %r15
  xorl %r12d, %r12d
  movq %r10, %r14
.LBB0_38:
  movq %r12, %r9
  movl %ebp, %ebx
  movq %r15, %r11
  movl %r10d, %ebp
  orb $-128, %bpl
  incq %r12
  movb %bpl, 8(%rsp,%r9)
  shrq $7, %r14
  leal 1(%rbx), %ebp
  incq %r15
  cmpq $127, %r10
  movq %r14, %r10
  ja .LBB0_38
  andb $127, 8(%rsp)
  testl %r9d, %r9d
  js .LBB0_29
  movl %esi, %r10d
  movl %ebx, %r14d
  movq %r14, %rbx
  andq $2147483632, %rbx
  je .LBB0_41
  xorl %r15d, %r15d
.LBB0_50:
  vmovdqu (%r11), %xmm1
  vpshufb %xmm4, %xmm1, %xmm1
  vmovdqu %xmm1, sqlite_varint_bytes(%r10,%r15)
  addq $16, %r15
  addq $-16, %r11
  cmpq %rbx, %r15
  jb .LBB0_50
  cmpq %rbx, %r14
  je .LBB0_29
  jmp .LBB0_42
.LBB0_41:
  xorl %ebx, %ebx
.LBB0_42:
  incq %r9
  movq %r13, %r11
  subq %rbx, %r11
.LBB0_43:
  movzbl (%r11,%r12), %ebp
  movb %bpl, sqlite_varint_bytes(%r10,%rbx)
  incq %rbx
  decq %r11
  cmpq %rbx, %r9
  jne .LBB0_43
  jmp .LBB0_29
.LBB0_26:
  movl %r8d, %edi
  movl %esi, sqlite_varint_offsets(,%rdi,4)
  movl %esi, %edi
  movl %ecx, %r9d
  andb $127, %r9b
  movb %r9b, sqlite_varint_bytes(%rdi)
  incl %esi
  leal 1(%r8), %edi
  movl %esi, %r12d
  cmpl $262142, %r8d
  jbe .LBB0_27
.LBB0_30:
  xorl %ebx, %ebx
  leaq 8(%rsp), %r14
  xorl %ebp, %ebp
.LBB0_31:
  xorl %r15d, %r15d
.LBB0_32:
  movq $0, 8(%rsp)
  movl sqlite_varint_offsets(,%r15,4), %eax
  leaq sqlite_varint_bytes(%rax), %rdi
  movq %r14, %rsi
  vzeroupper
  callq sqlite_get_varint
  movzbl %al, %eax
  movl %r15d, %ecx
  andb $31, %cl
  shlxq %rcx, %rax, %rax
  xorq 8(%rsp), %rax
  addq %rax, %rbx
  incq %r15
  cmpq $262144, %r15
  jne .LBB0_32
  imull $104729, %ebp, %eax
  andl $262143, %eax
  movl sqlite_varint_offsets(,%rax,4), %eax
  xorb $1, sqlite_varint_bytes(%rax)
  incl %ebp
  cmpl $24, %ebp
  jne .LBB0_31
  testl %r12d, %r12d
  je .LBB0_35
  xorl %ebp, %ebp
  movl $.L.str, %edi
  movq %rbx, %rsi
  xorl %eax, %eax
  callq printf
  jmp .LBB0_45
.LBB0_16:
  movl $2, %ebp
  jmp .LBB0_45
.LBB0_35:
  movl $3, %ebp
.LBB0_45:
  movl %ebp, %eax
  addq $88, %rsp
  popq %rbx
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  popq %rbp
  retq
.LJTI0_0:

sqlite_get_varint:
  movzbl (%rdi), %ecx
  testb %cl, %cl
  js .LBB1_2
  movb $1, %al
  movq %rcx, (%rsi)
  retq
.LBB1_2:
  movzbl 1(%rdi), %eax
  testb %al, %al
  js .LBB1_4
  andl $127, %ecx
  shlq $7, %rcx
  orq %rax, %rcx
  movb $2, %al
  movq %rcx, (%rsi)
  retq
.LBB1_4:
  shll $14, %ecx
  movzbl 2(%rdi), %edx
  orl %edx, %ecx
  andl $2080895, %ecx
  movzbl %al, %eax
  testb %dl, %dl
  js .LBB1_6
  andl $127, %eax
  shll $7, %eax
  orq %rax, %rcx
  movb $3, %al
  movq %rcx, (%rsi)
  retq
.LBB1_6:
  shll $14, %eax
  movzbl 3(%rdi), %edx
  orl %edx, %eax
  andl $2080895, %eax
  testb %dl, %dl
  js .LBB1_8
  movl %ecx, %ecx
  shlq $7, %rcx
  orq %rax, %rcx
  movb $4, %al
  movq %rcx, (%rsi)
  retq
.LBB1_8:
  movl %ecx, %edx
  shll $14, %edx
  movzbl 4(%rdi), %r8d
  orq %r8, %rdx
  testb %r8b, %r8b
  js .LBB1_10
  movl %eax, %eax
  shlq $7, %rax
  orq %rax, %rdx
  shrl $18, %ecx
  shlq $32, %rcx
  orq %rdx, %rcx
  movb $5, %al
  movq %rcx, (%rsi)
  retq
.LBB1_10:
  movl %ecx, %r9d
  shlq $7, %r9
  movl %eax, %ecx
  orq %r9, %rcx
  shll $14, %eax
  movzbl 5(%rdi), %r9d
  orq %r9, %rax
  testb %r9b, %r9b
  js .LBB1_12
  shll $7, %edx
  andl $266354560, %edx
  orq %rdx, %rax
  shrl $18, %ecx
  shlq $32, %rcx
  orq %rax, %rcx
  movb $6, %al
  movq %rcx, (%rsi)
  retq
.LBB1_12:
  shll $14, %edx
  movzbl 6(%rdi), %r9d
  orq %r9, %rdx
  testb %r9b, %r9b
  js .LBB1_14
  andl $-266354561, %edx
  shll $7, %eax
  andl $266354560, %eax
  orq %rdx, %rax
  shrl $11, %ecx
  shlq $32, %rcx
  orq %rax, %rcx
  movb $7, %al
  movq %rcx, (%rsi)
  retq
.LBB1_14:
  andl $2080895, %edx
  shll $14, %eax
  movzbl 7(%rdi), %r9d
  orq %r9, %rax
  testb %r9b, %r9b
  js .LBB1_16
  andl $-266354561, %eax
  shlq $7, %rdx
  orq %rax, %rdx
  shrl $4, %ecx
  shlq $32, %rcx
  orq %rdx, %rcx
  movb $8, %al
  movq %rcx, (%rsi)
  retq
.LBB1_16:
  shll $15, %edx
  movzbl 8(%rdi), %edi
  orq %rdi, %rdx
  shll $8, %eax
  andl $532709120, %eax
  orq %rdx, %rax
  shll $4, %ecx
  shrl $3, %r8d
  andl $15, %r8d
  orl %ecx, %r8d
  shlq $32, %r8
  orq %rax, %r8
  movb $9, %al
  movq %r8, (%rsi)
  retq

.L.str:

check_known_values.values:


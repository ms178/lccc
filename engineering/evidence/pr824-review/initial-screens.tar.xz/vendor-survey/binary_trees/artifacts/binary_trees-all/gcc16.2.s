check:
  subq $136, %rsp
  movl $1, %eax
  movq %r13, 112(%rsp)
  movq (%rdi), %r13
  testq %r13, %r13
  je .L1
  movq %rbp, 96(%rsp)
  movq %r12, 104(%rsp)
  movq %r14, 120(%rsp)
  movq %rdi, %r14
  movq %r15, 128(%rsp)
  xorl %r15d, %r15d
.L7:
  movq 0(%r13), %rbp
  xorl %r12d, %r12d
  testq %rbp, %rbp
  je .L3
  movq %rbx, 88(%rsp)
  movq %rbp, %rbx
  movl %r15d, 48(%rsp)
  movq %r14, %r15
  movl %r12d, %r14d
  movq %r13, %r12
.L4:
  movq (%rbx), %rbp
  xorl %eax, %eax
  testq %rbp, %rbp
  je .L5
  movl %r14d, 52(%rsp)
  movl %eax, %r13d
  movq %r12, 40(%rsp)
  movq %rbx, %r12
.L6:
  movq 0(%rbp), %r14
  xorl %ebx, %ebx
  testq %r14, %r14
  je .L8
  movq %r12, 56(%rsp)
  movq %r14, %rax
  movq %rbp, %r14
  movl %r13d, 72(%rsp)
  movq %rax, %rbp
  movq %r15, 64(%rsp)
  movl %ebx, %r15d
.L9:
  movq 0(%rbp), %r12
  xorl %r13d, %r13d
  testq %r12, %r12
  je .L10
  movl %r15d, 76(%rsp)
  movq %rbp, %rax
  movq %r12, %rbx
  movl %r13d, %ecx
.L11:
  movq (%rbx), %r12
  xorl %r13d, %r13d
  testq %r12, %r12
  je .L12
  movl %ecx, 36(%rsp)
  movq %rax, 24(%rsp)
  movl %r13d, %eax
.L13:
  movq (%r12), %r13
  xorl %r15d, %r15d
  testq %r13, %r13
  je .L14
  movl %eax, 32(%rsp)
  movq %r13, %rbp
  movq %rbx, 16(%rsp)
  movq %r12, %rbx
.L15:
  movq 0(%rbp), %r12
  xorl %r13d, %r13d
  testq %r12, %r12
  je .L16
  movq %rbx, 8(%rsp)
  movl %r13d, %ebx
  movq %rbp, %r13
.L17:
  movq (%r12), %rdi
  xorl %ebp, %ebp
  testq %rdi, %rdi
  je .L18
.L19:
  call check
  movq 8(%r12), %r12
  leal 1(%rbp,%rax), %ebp
  movq (%r12), %rdi
  testq %rdi, %rdi
  jne .L19
.L18:
  movq 8(%r13), %r13
  leal 2(%rbx,%rbp), %ebx
  movq 0(%r13), %r12
  testq %r12, %r12
  jne .L17
  movl %ebx, %r13d
  movq 8(%rsp), %rbx
.L16:
  movq 8(%rbx), %rbx
  leal 2(%r15,%r13), %r15d
  movq (%rbx), %rbp
  testq %rbp, %rbp
  jne .L15
  movq 16(%rsp), %rbx
  movl 32(%rsp), %eax
.L14:
  movq 8(%rbx), %rbx
  leal 2(%rax,%r15), %eax
  movq (%rbx), %r12
  testq %r12, %r12
  jne .L13
  movl %eax, %r13d
  movl 36(%rsp), %ecx
  movq 24(%rsp), %rax
.L12:
  movq 8(%rax), %rax
  leal 2(%rcx,%r13), %ecx
  movq (%rax), %rbx
  testq %rbx, %rbx
  jne .L11
  movl 76(%rsp), %r15d
  movl %ecx, %r13d
.L10:
  movq 8(%r14), %r14
  leal 2(%r15,%r13), %r15d
  movq (%r14), %rbp
  testq %rbp, %rbp
  jne .L9
  movl %r15d, %ebx
  movq 56(%rsp), %r12
  movl 72(%rsp), %r13d
  movq 64(%rsp), %r15
.L8:
  movq 8(%r12), %r12
  leal 2(%r13,%rbx), %r13d
  movq (%r12), %rbp
  testq %rbp, %rbp
  jne .L6
  movq 40(%rsp), %r12
  movl 52(%rsp), %r14d
  movl %r13d, %eax
.L5:
  movq 8(%r12), %r12
  leal 2(%r14,%rax), %r14d
  movq (%r12), %rbx
  testq %rbx, %rbx
  jne .L4
  movl %r14d, %r12d
  movq 88(%rsp), %rbx
  movq %r15, %r14
  movl 48(%rsp), %r15d
.L3:
  movq 8(%r14), %r14
  leal 2(%r15,%r12), %r15d
  movq (%r14), %r13
  testq %r13, %r13
  jne .L7
  leal 1(%r15), %eax
  movq 96(%rsp), %rbp
  movq 104(%rsp), %r12
  movq 120(%rsp), %r14
  movq 128(%rsp), %r15
.L1:
  movq 112(%rsp), %r13
  addq $136, %rsp
  ret
destroy:
  subq $40, %rsp
  movq %rbp, 24(%rsp)
  movq (%rdi), %rbp
  movq %rbx, 16(%rsp)
  movq %rdi, %rbx
  testq %rbp, %rbp
  je .L74
  movq 0(%rbp), %rax
  movq %r14, 32(%rsp)
  testq %rax, %rax
  je .L75
  movq (%rax), %rdx
  testq %rdx, %rdx
  je .L76
  movq (%rdx), %rdi
  testq %rdi, %rdi
  je .L77
  movq %rax, 8(%rsp)
  movq %rdx, (%rsp)
  call destroy
  movq (%rsp), %rdx
  movq 8(%rdx), %rdi
  call destroy
  movq 8(%rsp), %rax
  movq (%rsp), %rdx
.L77:
  movq %rdx, %rdi
  movq %rax, (%rsp)
  call free
  movq (%rsp), %rax
  movq 8(%rax), %rdx
  movq (%rdx), %rdi
  testq %rdi, %rdi
  je .L78
  movq %rax, 8(%rsp)
  movq %rdx, (%rsp)
  call destroy
  movq (%rsp), %rdx
  movq 8(%rdx), %rdi
  call destroy
  movq 8(%rsp), %rax
  movq (%rsp), %rdx
.L78:
  movq %rdx, %rdi
  movq %rax, (%rsp)
  call free
  movq (%rsp), %rax
.L76:
  movq %rax, %rdi
  call free
  movq 8(%rbp), %rax
  movq %rax, %r14
  movq (%rax), %rax
  testq %rax, %rax
  je .L79
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L80
  movq %rax, (%rsp)
  call destroy
  movq (%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq (%rsp), %rax
.L80:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L81
  movq %rax, (%rsp)
  call destroy
  movq (%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq (%rsp), %rax
.L81:
  movq %rax, %rdi
  call free
.L79:
  movq %r14, %rdi
  call free
.L75:
  movq %rbp, %rdi
  call free
  movq 8(%rbx), %rbp
  movq 0(%rbp), %rax
  testq %rax, %rax
  je .L82
  movq (%rax), %rdx
  testq %rdx, %rdx
  je .L83
  movq (%rdx), %rdi
  testq %rdi, %rdi
  je .L84
  movq %rax, 8(%rsp)
  movq %rdx, (%rsp)
  call destroy
  movq (%rsp), %rdx
  movq 8(%rdx), %rdi
  call destroy
  movq 8(%rsp), %rax
  movq (%rsp), %rdx
.L84:
  movq %rdx, %rdi
  movq %rax, (%rsp)
  call free
  movq (%rsp), %rax
  movq 8(%rax), %rdx
  movq (%rdx), %rdi
  testq %rdi, %rdi
  je .L85
  movq %rax, 8(%rsp)
  movq %rdx, (%rsp)
  call destroy
  movq (%rsp), %rdx
  movq 8(%rdx), %rdi
  call destroy
  movq 8(%rsp), %rax
  movq (%rsp), %rdx
.L85:
  movq %rdx, %rdi
  movq %rax, (%rsp)
  call free
  movq (%rsp), %rax
.L83:
  movq %rax, %rdi
  call free
  movq 8(%rbp), %rax
  movq %rax, %r14
  movq (%rax), %rax
  testq %rax, %rax
  je .L86
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L87
  movq %rax, (%rsp)
  call destroy
  movq (%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq (%rsp), %rax
.L87:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L88
  movq %rax, (%rsp)
  call destroy
  movq (%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq (%rsp), %rax
.L88:
  movq %rax, %rdi
  call free
.L86:
  movq %r14, %rdi
  call free
.L82:
  movq %rbp, %rdi
  call free
  movq 32(%rsp), %r14
.L74:
  movq 24(%rsp), %rbp
  movq %rbx, %rdi
  movq 16(%rsp), %rbx
  addq $40, %rsp
  jmp free
make:
  subq $72, %rsp
  movq %rbp, 48(%rsp)
  movl %edi, %ebp
  movl $16, %edi
  movq %rbx, 40(%rsp)
  call malloc
  movq %rax, %rbx
  testl %ebp, %ebp
  jne .L143
  vpxor %xmm0, %xmm0, %xmm0
  vmovdqu %xmm0, (%rax)
.L135:
  movq %rbx, %rax
  movq 48(%rsp), %rbp
  movq 40(%rsp), %rbx
  addq $72, %rsp
  ret
.L143:
  movl $16, %edi
  call malloc
  cmpl $1, %ebp
  jne .L144
  movq %rax, (%rbx)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  vmovdqu %xmm0, (%rax)
  vmovdqa %xmm0, (%rsp)
  call malloc
  vmovdqa (%rsp), %xmm0
  movq %rax, %rbp
  vmovdqu %xmm0, (%rax)
.L140:
  movq %rbp, 8(%rbx)
  jmp .L135
.L144:
  movl $16, %edi
  movq %rax, (%rsp)
  call malloc
  cmpl $2, %ebp
  movq (%rsp), %rdx
  jne .L145
  movq %rax, (%rdx)
  vpxor %xmm1, %xmm1, %xmm1
  movl $16, %edi
  vmovdqu %xmm1, (%rax)
  movq %rdx, 24(%rsp)
  vmovdqa %xmm1, (%rsp)
  call malloc
  movq 24(%rsp), %rdx
  vmovdqa (%rsp), %xmm1
  movl $16, %edi
  movq %rax, 8(%rdx)
  movq %rdx, (%rbx)
  vmovdqu %xmm1, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %rbp
  call malloc
  vmovdqa (%rsp), %xmm1
  movl $16, %edi
  movq %rax, 0(%rbp)
  vmovdqu %xmm1, (%rax)
  call malloc
  vmovdqa (%rsp), %xmm1
  movq %rax, %rcx
  vmovdqu %xmm1, (%rax)
.L139:
  movq %rcx, 8(%rbp)
  jmp .L140
.L145:
  movq %r14, 56(%rsp)
  leal -3(%rbp), %r14d
  movl %r14d, %edi
  movq %r15, 64(%rsp)
  movq %rdx, 24(%rsp)
  movq %rax, (%rsp)
  call make
  movq (%rsp), %rcx
  movl %r14d, %edi
  movq %rax, (%rcx)
  call make
  movq (%rsp), %rcx
  movq 24(%rsp), %rdx
  movl $16, %edi
  movq %rcx, (%rdx)
  movq %rax, 8(%rcx)
  movq %rdx, (%rsp)
  call malloc
  movl %r14d, %edi
  movq %rax, %rbp
  call make
  movl %r14d, %edi
  movq %rax, 0(%rbp)
  call make
  movq (%rsp), %rdx
  movl $16, %edi
  movq %rax, 8(%rbp)
  movq %rbp, 8(%rdx)
  movq %rdx, (%rbx)
  call malloc
  movl $16, %edi
  movq %rax, %rbp
  call malloc
  movl %r14d, %edi
  movq %rax, %r15
  call make
  movl %r14d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, 0(%rbp)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r14d, %edi
  movq %rax, (%rsp)
  call make
  movq (%rsp), %rcx
  movl %r14d, %edi
  movq %rax, (%rcx)
  call make
  movq (%rsp), %rcx
  movq 56(%rsp), %r14
  movq 64(%rsp), %r15
  movq %rax, 8(%rcx)
  jmp .L139
.LC0:
.LC1:
.LC2:
main:
  pushq %r15
  movl $16, %edi
  pushq %r14
  pushq %r13
  movl $18, %r13d
  pushq %r12
  pushq %rbp
  pushq %rbx
  subq $88, %rsp
  call malloc
  movl $18, %edi
  movq %rax, %rbx
  call make
  movl $18, %edi
  movq %rax, (%rbx)
  call make
  movq %rbx, %rdi
  movl $19, %esi
  movq %rax, 8(%rbx)
  call check
  movl $.LC0, %edi
  movl %eax, %edx
  xorl %eax, %eax
  vzeroupper
  call printf
  movq %rbx, %rdi
  call destroy
  movl $16, %edi
  call malloc
  movl $17, %edi
  movq %rax, %rbx
  call make
  movl $17, %edi
  movq %rax, (%rbx)
  call make
  movl $4, 24(%rsp)
  movq %rax, 8(%rbx)
  movq %rbx, 72(%rsp)
.L147:
  xorl %edx, %edx
  movl $1, %eax
  testb $1, %r13b
  je .L148
  movl $1, %edx
  movl $2, %eax
  cmpl %r13d, %edx
  je .L406
.L148:
  addl $2, %edx
  sall $2, %eax
  cmpl %r13d, %edx
  jne .L148
.L406:
  testl %eax, %eax
  jle .L218
  movl $0, 4(%rsp)
  movl $0, 56(%rsp)
  movl %eax, 28(%rsp)
  movl %r13d, 60(%rsp)
.L216:
  movl $16, %edi
  call malloc
  movl $16, %edi
  movq %rax, %rbx
  call malloc
  movl $16, %edi
  movq %rax, 8(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, %rbp
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  movl 24(%rsp), %ecx
  movq %rax, %r13
  cmpl $4, %ecx
  jne .L410
  movq %rax, (%r12)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, 0(%rbp)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, 8(%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq 8(%rsp), %r14
  movq %r12, 8(%rbp)
  vpxor %xmm0, %xmm0, %xmm0
  movq %rax, 8(%r12)
  movl $16, %edi
  movq %rbp, (%r14)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r15
  movq %rax, 32(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, (%r15)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, 8(%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, 8(%r15)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %r15, 8(%r14)
  movq %rax, 8(%r12)
  movq %r14, (%rbx)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r15
  call malloc
  movl $16, %edi
  movq %rax, %r14
  movq %rax, 16(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, (%r14)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, 8(%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, 8(%r14)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, 8(%r12)
  movq %r14, (%r15)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl $16, %edi
  movq %rax, %r12
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movq %r12, 0(%r13)
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, 8(%r12)
  vmovdqu %xmm0, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r14
  movq %rax, 48(%rsp)
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movl $16, %edi
  movq %rax, (%r14)
  vmovdqu %xmm0, (%rax)
  call malloc
  vpxor %xmm0, %xmm0, %xmm0
  movq %r14, 8(%r13)
  movl 56(%rsp), %r8d
  movq %rax, 8(%r14)
  vmovdqu %xmm0, (%rax)
  addl $1, %r8d
  movq %r13, 8(%r15)
.L151:
  movq %r15, 8(%rbx)
  movq 8(%rsp), %rdi
  movq %rbx, %rdx
  xorl %esi, %esi
.L155:
  call check
  movq 8(%rdx), %rdx
  leal 1(%rsi,%rax), %esi
  movq (%rdx), %rdi
  testq %rdi, %rdi
  jne .L155
  leal (%rsi,%r8), %eax
  movl %eax, 56(%rsp)
  testq %rbp, %rbp
  je .L153
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L156
  movq (%r12), %r14
  testq %r14, %r14
  je .L157
  movq (%r14), %rax
  testq %rax, %rax
  je .L158
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L159
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L159:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L160
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L160:
  movq %rax, %rdi
  call free
.L158:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rax
  testq %rax, %rax
  je .L161
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L162
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L162:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L163
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L163:
  movq %rax, %rdi
  call free
.L161:
  movq %r14, %rdi
  call free
.L157:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L164
  movq (%r14), %rax
  testq %rax, %rax
  je .L165
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L166
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L166:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L167
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L167:
  movq %rax, %rdi
  call free
.L165:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rax
  testq %rax, %rax
  je .L168
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L169
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L169:
  movq %rax, %rdi
  call free
  movq 8(%r14), %rax
  movq (%rax), %rdi
  testq %rdi, %rdi
  je .L170
  movq %rax, 40(%rsp)
  call destroy
  movq 40(%rsp), %rax
  movq 8(%rax), %rdi
  call destroy
  movq 40(%rsp), %rax
.L170:
  movq %rax, %rdi
  call free
.L168:
  movq %r14, %rdi
  call free
.L164:
  movq %r12, %rdi
  call free
.L156:
  movq %rbp, %rdi
  call free
  movq 32(%rsp), %rax
  movq (%rax), %rbp
  testq %rbp, %rbp
  je .L171
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L172
  movq (%r12), %r14
  testq %r14, %r14
  je .L173
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L174
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L174:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L175
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L175:
  movq %r14, %rdi
  call free
.L173:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L176
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L177
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L177:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L178
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L178:
  movq %r14, %rdi
  call free
.L176:
  movq %r12, %rdi
  call free
.L172:
  movq %rbp, %rdi
  call free
  movq 32(%rsp), %rax
  movq 8(%rax), %rbp
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L179
  movq (%r12), %r14
  testq %r14, %r14
  je .L180
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L181
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L181:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L182
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L182:
  movq %r14, %rdi
  call free
.L180:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L183
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L184
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L184:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L185
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L185:
  movq %r14, %rdi
  call free
.L183:
  movq %r12, %rdi
  call free
.L179:
  movq %rbp, %rdi
  call free
.L171:
  movq 32(%rsp), %rdi
  call free
.L153:
  movq 8(%rsp), %rdi
  call free
  movq 16(%rsp), %rax
  movq (%rax), %rbp
  testq %rbp, %rbp
  je .L186
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L187
  movq (%r12), %r14
  testq %r14, %r14
  je .L188
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L189
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L189:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L190
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L190:
  movq %r14, %rdi
  call free
.L188:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L191
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L192
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L192:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L193
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L193:
  movq %r14, %rdi
  call free
.L191:
  movq %r12, %rdi
  call free
.L187:
  movq %rbp, %rdi
  call free
  movq 16(%rsp), %rax
  movq 8(%rax), %rbp
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L194
  movq (%r12), %r14
  testq %r14, %r14
  je .L195
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L196
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L196:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L197
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L197:
  movq %r14, %rdi
  call free
.L195:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L198
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L199
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L199:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L200
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L200:
  movq %r14, %rdi
  call free
.L198:
  movq %r12, %rdi
  call free
.L194:
  movq %rbp, %rdi
  call free
.L186:
  movq 16(%rsp), %rdi
  call free
  movq 0(%r13), %rbp
  testq %rbp, %rbp
  je .L201
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L202
  movq (%r12), %r14
  testq %r14, %r14
  je .L203
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L204
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L204:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L205
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L205:
  movq %r14, %rdi
  call free
.L203:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %r14
  testq %r14, %r14
  je .L206
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L207
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L207:
  movq %r14, %rdi
  call free
  movq 8(%r12), %r14
  movq (%r14), %rdi
  testq %rdi, %rdi
  je .L208
  call destroy
  movq 8(%r14), %rdi
  call destroy
.L208:
  movq %r14, %rdi
  call free
.L206:
  movq %r12, %rdi
  call free
.L202:
  movq %rbp, %rdi
  call free
  movq 48(%rsp), %rax
  movq (%rax), %rbp
  testq %rbp, %rbp
  je .L209
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L210
  movq (%r12), %rdi
  testq %rdi, %rdi
  je .L211
  call destroy
  movq 8(%r12), %rdi
  call destroy
.L211:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %rdi
  testq %rdi, %rdi
  je .L212
  call destroy
  movq 8(%r12), %rdi
  call destroy
.L212:
  movq %r12, %rdi
  call free
.L210:
  movq %rbp, %rdi
  call free
  movq 48(%rsp), %rax
  movq 8(%rax), %rbp
  movq 0(%rbp), %r12
  testq %r12, %r12
  je .L213
  movq (%r12), %rdi
  testq %rdi, %rdi
  je .L214
  call destroy
  movq 8(%r12), %rdi
  call destroy
.L214:
  movq %r12, %rdi
  call free
  movq 8(%rbp), %r12
  movq (%r12), %rdi
  testq %rdi, %rdi
  je .L215
  call destroy
  movq 8(%r12), %rdi
  call destroy
.L215:
  movq %r12, %rdi
  call free
.L213:
  movq %rbp, %rdi
  call free
.L209:
  movq 48(%rsp), %rdi
  call free
.L201:
  movq %r13, %rdi
  call free
  movq %r15, %rdi
  call free
  movq %rbx, %rdi
  call free
  addl $1, 4(%rsp)
  movl 28(%rsp), %ecx
  cmpl %ecx, 4(%rsp)
  jne .L216
  movl 56(%rsp), %ecx
  movl 28(%rsp), %eax
  movl 60(%rsp), %r13d
.L149:
  movl 24(%rsp), %ebx
  movl %eax, %esi
  movl $.LC1, %edi
  xorl %eax, %eax
  subl $2, %r13d
  movl %ebx, %edx
  call printf
  leal 2(%rbx), %eax
  movl %eax, 24(%rsp)
  cmpl $20, %eax
  jne .L147
  movq 72(%rsp), %rbx
  movl $18, %esi
  movq %rbx, %rdi
  call check
  movl $.LC2, %edi
  movl %eax, %edx
  xorl %eax, %eax
  call printf
  movq %rbx, %rdi
  call destroy
  addq $88, %rsp
  xorl %eax, %eax
  popq %rbx
  popq %rbp
  popq %r12
  popq %r13
  popq %r14
  popq %r15
  ret
.L410:
  leal -5(%rcx), %r15d
  movl %r15d, %edi
  call make
  movl %r15d, %edi
  movq %rax, 0(%r13)
  call make
  movq %r13, (%r12)
  movl $16, %edi
  movq %rax, 8(%r13)
  call malloc
  movl %r15d, %edi
  movq %rax, %r13
  call make
  movl %r15d, %edi
  movl %r15d, 40(%rsp)
  movq %rax, 0(%r13)
  call make
  movq %r13, 8(%r12)
  movl $16, %edi
  movq %rax, 8(%r13)
  movq %r12, 0(%rbp)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl 24(%rsp), %ecx
  movq %rax, %r15
  leal -6(%rcx), %r12d
  movl %r12d, %edi
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %r14, 0(%r13)
  movq %rax, 8(%r15)
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  movq 8(%rsp), %rax
  movq %r14, 8(%r13)
  movq %r13, 8(%rbp)
  movq %rbp, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, 32(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %r14, 0(%r13)
  movq %rax, 8(%r15)
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq 32(%rsp), %rcx
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %r14, 8(%r13)
  movq %r13, (%rcx)
  movq %rax, 8(%r15)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %r14, 0(%r13)
  movq %rax, 8(%r15)
  call malloc
  movl $16, %edi
  movq %rax, %r14
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq %r15, (%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  call malloc
  movl %r12d, %edi
  movq %rax, %r15
  call make
  movl %r12d, %edi
  movq %rax, (%r15)
  call make
  movq 32(%rsp), %rcx
  movq %r15, 8(%r14)
  movl $16, %edi
  movq %rax, 8(%r15)
  movq 8(%rsp), %rax
  movq %r13, 8(%rcx)
  movq %rcx, 8(%rax)
  movq %r14, 8(%r13)
  movq %rax, (%rbx)
  call malloc
  movl $16, %edi
  movq %rax, %r15
  call malloc
  movl $16, %edi
  movq %rax, 16(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl 40(%rsp), %edi
  movq %rax, %r14
  call make
  movl 40(%rsp), %edi
  movq %rax, (%r14)
  call make
  movq %r14, 0(%r13)
  movl $16, %edi
  movq %rax, 8(%r14)
  call malloc
  movl 40(%rsp), %edi
  movq %rax, %r14
  call make
  movl 40(%rsp), %edi
  movq %rax, (%r14)
  call make
  movq %r14, 8(%r13)
  movl $16, %edi
  movq %rax, 8(%r14)
  movq 16(%rsp), %rax
  movq %r13, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl 40(%rsp), %edi
  movq %rax, %r14
  call make
  movl 40(%rsp), %edi
  movq %rax, (%r14)
  call make
  movq %r14, 0(%r13)
  movl $16, %edi
  movq %rax, 8(%r14)
  call malloc
  movl 40(%rsp), %edi
  movq %rax, %r14
  call make
  movl 40(%rsp), %edi
  movq %rax, (%r14)
  call make
  movq %r14, 8(%r13)
  movl $16, %edi
  movq %rax, 8(%r14)
  movq 16(%rsp), %rax
  movq %r13, 8(%rax)
  movq %rax, (%r15)
  call malloc
  movl $16, %edi
  movq %rax, %r13
  call malloc
  movl $16, %edi
  movq %rax, 48(%rsp)
  call malloc
  movl $16, %edi
  movq %rax, 64(%rsp)
  call malloc
  movl %r12d, %edi
  movq %rax, %r14
  call make
  movl %r12d, %edi
  movq %rax, (%r14)
  call make
  movq 64(%rsp), %rcx
  movl $16, %edi
  movq %rax, 8(%r14)
  movq %r14, (%rcx)
  call malloc
  movl %r12d, %edi
  movq %rax, %r14
  call make
  movl %r12d, %edi
  movq %rax, (%r14)
  call make
  movq 64(%rsp), %rcx
  movl $16, %edi
  movq %rax, 8(%r14)
  movq 48(%rsp), %rax
  movq %r14, 8(%rcx)
  movq %rcx, (%rax)
  call malloc
  movl $16, %edi
  movq %rax, 64(%rsp)
  call malloc
  movl %r12d, %edi
  movq %rax, %r14
  call make
  movl %r12d, %edi
  movq %rax, (%r14)
  call make
  movq 64(%rsp), %rcx
  movl $16, %edi
  movq %rax, 8(%r14)
  movq %r14, (%rcx)
  call malloc
  movl %r12d, %edi
  movq %rax, %r14
  call make
  movl %r12d, %edi
  movq %rax, (%r14)
  call make
  movq 64(%rsp), %rcx
  movl $16, %edi
  movq %rax, 8(%r14)
  movq 48(%rsp), %rax
  movq %r14, 8(%rcx)
  movq %rcx, 8(%rax)
  movq %rax, 0(%r13)
  call malloc
  movl $16, %edi
  movq %rax, 48(%rsp)
  call malloc
  movl 40(%rsp), %r14d
  movq %rax, %r12
  movl %r14d, %edi
  call make
  movl %r14d, %edi
  movq %rax, (%r12)
  call make
  movl $16, %edi
  movq %rax, 8(%r12)
  movq 48(%rsp), %rax
  movq %r12, (%rax)
  call malloc
  movl %r14d, %edi
  movq %rax, %r12
  call make
  movl %r14d, %edi
  movq %rax, (%r12)
  call make
  movl 56(%rsp), %r8d
  movq %rax, 8(%r12)
  movq 48(%rsp), %rax
  addl $1, %r8d
  movq %r12, 8(%rax)
  movq %rax, 8(%r13)
  movq %r13, 8(%r15)
  jmp .L151
.L218:
  xorl %ecx, %ecx
  jmp .L149

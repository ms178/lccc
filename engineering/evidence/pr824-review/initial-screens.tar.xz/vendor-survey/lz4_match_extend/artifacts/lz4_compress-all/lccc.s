.Lstr0:

src_data:
dst_data:
hash_table:

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $216, %rsp
    leaq dst_data(%rip), %rax
    movq %rax, 72(%rsp)
    leaq src_data(%rip), %rax
    movq %rax, 64(%rsp)
    leaq 524288(%rax), %rbp
    movq 64(%rsp), %rax
    addq $524276, %rax
    movq %rax, 56(%rsp)
    movq 64(%rsp), %rax
    addq $1, %rax
    movq %rax, 48(%rsp)
    xorl %r11d, %r11d
    movl $1511734397, %r10d
.LBB1:
    cmpl $524288, %r11d
jb .LBB2
.LBB55:
    movq $0, 200(%rsp)
    movq $0, 192(%rsp)
    jmp .LBB56
.LBB2:
    imull $1664525, %r10d, %r10d
    leal 1013904223(%r10), %r8d
    cmpl $128, %r11d
    setae %r9b
    movzbl %r9b, %r9d
    movzbl %r11b, %edi
    cmpl $96, %edi
    setb %sil
    movzbl %sil, %esi
    andl %esi, %r9d
je .LBB52
.LBB3:
    movl %r11d, %edx
    subl $128, %edx
    leaq src_data(%rip), %rcx
    movzbl (%rcx, %rdx), %edi
    jmp .LBB4
.LBB52:
    movl %r8d, %esi
    andl $15, %esi
    cmpl $6, %esi
jae .LBB54
    cmpl $128, %r11d
jb .LBB54
.LBB53:
    leal -128(%r11), %r9d
    movl %r8d, %esi
    andl $63, %esi
    addl %esi, %r9d
    leaq src_data(%rip), %rcx
    movzbl (%rcx, %r9), %edi
    jmp .LBB4
.LBB54:
    movl %r8d, %r10d
    shrl $24, %r10d
    movzbl %r10b, %edi
.LBB4:
    movl %r11d, %r9d
    leaq src_data(%rip), %rcx
    movb %dil, (%rcx, %r9)
    addl $1, %r11d
    movq %r8, %r10
    cmpl $524288, %r11d
jb .LBB2
    jmp .LBB55
.LBB56:
    movl 200(%rsp), %eax
    cmpl $2048, %eax
jae .LBB57
.LBB5:
    jmp .LBB6
.LBB7:
    movq 48(%rsp), %rdx
    movq 72(%rsp), %rax
    movq %rax, 184(%rsp)
    movq 64(%rsp), %r15
.LBB8:
    cmpq 56(%rsp), %rdx
jae .LBB34
.LBB9:
    movl (%rdx), %r11d
    imull $-1640531535, %r11d, %r11d
    shrl $18, %r11d
    leaq hash_table(%rip), %r8
    leaq (%r8, %r11, 4), %r8
    movl (%r8), %r9d
    leaq src_data(%rip), %rcx
    leaq (%rcx, %r9), %rdi
    movq %rdx, %rsi
    subq 64(%rsp), %rsi
    movl %esi, (%r8)
    cmpq %rdx, %rdi
jae .LBB49
.LBB10:
    cmpq 64(%rsp), %rdi
jb .LBB49
.LBB11:
    movl (%rdi), %esi
    cmpl (%rdx), %esi
jne .LBB49
.LBB12:
    movq %rdx, %rax
    addq $4, %rax
    movq %rax, 176(%rsp)
    leaq 4(%rdi), %r12
    jmp .LBB13
.LBB15:
    cmpq %rbp, %rbx
jae .LBB18
.LBB16:
    movzbl (%rbx), %r10d
    cmpb (%r14), %r10b
jne .LBB18
.LBB17:
    addq $1, %rbx
    addq $1, %r14
    cmpq %rbp, %rbx
jb .LBB16
.LBB18:
    movq %r14, %r9
    subq %rdi, %r9
    leaq -4(%r9), %rax
    movq %rax, 40(%rsp)
    movq 184(%rsp), %rax
    addq $1, %rax
    movq %rax, 160(%rsp)
    subq %r15, %rdx
    movl %edx, %eax
    movq %rax, 32(%rsp)
    cmpl $15, %edx
jb .LBB48
.LBB19:
    movq 184(%rsp), %rcx
    movb $240, (%rcx)
    movq 160(%rsp), %r12
    movl 32(%rsp), %r13d
    subl $15, %r13d
.LBB20:
    cmpl $255, %r13d
jb .LBB22
.LBB21:
    movb $255, (%r12)
    subl $255, %r13d
    leaq 1(%r12), %rax
    movq %rax, 16(%rsp)
    movq %rax, %r12
    cmpl $255, %r13d
jae .LBB21
.LBB22:
    movq %r12, %rax
    addq $1, %rax
    movq %rax, 160(%rsp)
    movb %r13b, (%r12)
    jmp .LBB23
.LBB48:
    movl 32(%rsp), %edx
    shll $4, %edx
    movq 184(%rsp), %rcx
    movb %dl, (%rcx)
.LBB23:
    movl 32(%rsp), %r11d
    movq %r11, %r10
    movq 160(%rsp), %r8
    subq %r15, %r8
    subq $1, %r10
    cmpq %r10, %r8
    movl %r11d, %r13d
ja .LBB47
.LBB24:
    xorl %r12d, %r12d
.LBB25:
    cmpq %r13, %r12
jb .LBB39
.LBB26:
    jmp .LBB27
.LBB39:
    movzbl (%r15, %r12), %eax
    movq 160(%rsp), %rcx
    movb %al, (%rcx)
    leaq 1(%r12), %rax
    movq %rax, 16(%rsp)
    addq $1, 160(%rsp)
    movq 16(%rsp), %r12
    cmpq %r13, %r12
jb .LBB39
    jmp .LBB27
.LBB27:
    movq %rbx, %rdx
    subq %r14, %rdx
    movzwl %dx, %r10d
    movq 160(%rsp), %r8
    addq $1, %r8
    movl %r10d, %r9d
    movq 160(%rsp), %rcx
    movb %r10b, (%rcx)
    movq 160(%rsp), %r13
    addq $2, %r13
    sarl $8, %r9d
    movb %r9b, (%r8)
    movl 40(%rsp), %r14d
    cmpl $15, %r14d
jb .LBB46
.LBB28:
    movq 184(%rsp), %rcx
    movzbl (%rcx), %r10d
    orl $15, %r10d
    movb %r10b, (%rcx)
    movq %r13, %r15
    movl %r14d, %r12d
    subl $15, %r12d
.LBB29:
    cmpl $255, %r12d
jb .LBB31
.LBB30:
    movb $255, (%r15)
    leal -255(%r12), %eax
    movl %eax, 20(%rsp)
    leaq 1(%r15), %rax
    movq %rax, %r15
    movl 20(%rsp), %r12d
    cmpl $255, %r12d
jae .LBB30
.LBB31:
    leaq 1(%r15), %r14
    movb %r12b, (%r15)
    jmp .LBB32
.LBB46:
    movzbl 40(%rsp), %edx
    movq 184(%rsp), %rcx
    movzbl (%rcx), %eax
    orl %eax, %edx
    movb %dl, (%rcx)
    movq %r13, %r14
.LBB32:
    movq %rbx, %r12
    movq %rbx, 136(%rsp)
    jmp .LBB33
.LBB49:
    leaq 1(%rdx), %r9
    subq %r15, %rdx
    sarq $6, %rdx
    addq %rdx, %r9
    movq %r9, 16(%rsp)
    movq %r9, %r12
    movq 184(%rsp), %r14
    movq %r15, 136(%rsp)
.LBB33:
    movq %r12, %rdx
    movq %r14, 184(%rsp)
    movq 136(%rsp), %r15
    cmpq 56(%rsp), %r12
jb .LBB9
.LBB34:
    movq %rbp, %rsi
    subq %r15, %rsi
    movl %esi, %r13d
    movq 184(%rsp), %rax
    addq $1, %rax
    movq %rax, 24(%rsp)
    movl %esi, %r10d
    shll $4, %r10d
    cmpl $15, %esi
    movl $240, %r8d
    cmovbl %r10d, %r8d
    movq 184(%rsp), %rcx
    movb %r8b, (%rcx)
    movl %r13d, %r10d
    movq %r10, %rdi
    movq 24(%rsp), %rsi
    subq %r15, %rsi
    subq $1, %rdi
    cmpq %rdi, %rsi
    movl %r13d, %r12d
ja .LBB50
.LBB35:
    movq 24(%rsp), %r13
    xorl %r14d, %r14d
.LBB36:
    cmpq %r12, %r14
jb .LBB45
.LBB37:
    movq %r13, 128(%rsp)
    jmp .LBB38
.LBB45:
    movzbl (%r15, %r14), %eax
    movb %al, (%r13)
    leaq 1(%r14), %rax
    movq %rax, 16(%rsp)
    leaq 1(%r13), %rax
    movq %rax, %r13
    movq 16(%rsp), %r14
    cmpq %r12, %r14
jb .LBB45
    jmp .LBB37
.LBB38:
    movq 128(%rsp), %rdi
    subq 72(%rsp), %rdi
    movl %edi, %esi
    movl %edi, %edx
    shlq $32, %rdx
    movzbl dst_data(%rip), %eax
    xorq %rax, %rdx
    shrl $1, %esi
    leaq dst_data(%rip), %rcx
    movzbl (%rcx, %rsi), %edi
    shlq $16, %rdi
    xorq %rdi, %rdx
    addq %rdx, 192(%rsp)
    movl 200(%rsp), %eax
    imull $4099, %eax, %eax
    movl %eax, %esi
    andq $524287, %rsi
    leaq src_data(%rip), %r8
    addq %rsi, %r8
    movzbl (%r8), %r9d
    xorl $85, %r9d
    movb %r9b, (%r8)
    movl 200(%rsp), %eax
    addl $1, %eax
    movq %rax, 200(%rsp)
    cmpl $2048, %eax
    jb .LBB6
.LBB57:
    leaq .Lstr0(%rip), %rdi
    movq 192(%rsp), %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $216, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB47:
    movq 160(%rsp), %rdi
    movq %r15, %rsi
    movq %r11, %rdx
    call memmove@PLT
    movq 160(%rsp), %rcx
    movq 32(%rsp), %rax
    addq %rcx, %rax
    movq %rax, 160(%rsp)
    jmp .LBB27
.LBB50:
    movq 24(%rsp), %rdi
    movq %r15, %rsi
    movq %r10, %rdx
    call memmove@PLT
    movq 24(%rsp), %rcx
    addq %rcx, %r13
    movq %r13, 128(%rsp)
    jmp .LBB38
.LBB13:
    movq 176(%rsp), %rsi
    addq $31, %rsi
    cmpq %rbp, %rsi
jb .LBB40
.LBB14:
    movq 176(%rsp), %rbx
    movq %r12, %r14
    jmp .LBB15
.LBB40:
    leaq 31(%r12), %r11
    movq %r12, %r10
    orq $4095, %r10
    cmpq %r10, %r11
jbe .LBB41
.LBB44:
    movq 176(%rsp), %rbx
    movq %r12, %r14
    jmp .LBB15
.LBB41:
    movq 176(%rsp), %rax
    vmovdqu (%rax), %ymm2
    vmovdqu (%r12), %ymm3
    vpcmpeqb %ymm3, %ymm2, %ymm0
    vpmovmskb %ymm0, %eax
    movq %rax, 40(%rsp)
    cmpl $-1, %eax
je .LBB42
.LBB43:
    xorq $-1, %rax
    tzcntl %eax, %eax
    movl %eax, %r8d
    movq %r8, %rax
    addq 176(%rsp), %rax
    movq %rax, 16(%rsp)
    leaq (%r12, %r8, 1), %r9
    movq %rax, %rbx
    movq %r9, %r14
    jmp .LBB15
.LBB42:
    addq $32, 176(%rsp)
    addq $32, %r12
    movq 176(%rsp), %rsi
    addq $31, %rsi
    cmpq %rbp, %rsi
jb .LBB40
    jmp .LBB14
.LBB6:
    movl $16384, %eax
    subq $0, %rax
    leaq 0(,%rax,4), %r11
    testq %rax, %rax
je .LBB7
.LBB51:
    leaq hash_table(%rip), %rdi
    xorl %esi, %esi
    movq %r11, %rdx
    call memset@PLT
    jmp .LBB7



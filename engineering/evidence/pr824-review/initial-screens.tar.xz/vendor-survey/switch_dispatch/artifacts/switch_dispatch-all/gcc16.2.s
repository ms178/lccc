.LC0:
main:
  subq $8, %rsp
  xorl %ecx, %ecx
  movl $777, %eax
  xorl %edi, %edi
.L19:
  imull $1664525, %eax, %eax
  movl %ecx, %r8d
  addl $1, %ecx
  addl $1013904223, %eax
  movl %eax, %edx
  movzwl %ax, %esi
  shrl $16, %edx
  andl $15, %edx
  jmp *.L4(,%rdx,8)
.L4:
.L3:
  leal (%rsi,%rcx), %edx
.L18:
  movslq %edx, %rdx
  addq %rdx, %rdi
  cmpl $50000000, %ecx
  jne .L19
  movq %rdi, %rsi
  xorl %eax, %eax
  movl $.LC0, %edi
  call printf
  xorl %eax, %eax
  addq $8, %rsp
  ret
.L10:
  leal -1(%rsi), %edx
  subl %r8d, %edx
  jmp .L18
.L11:
  movl %eax, %edx
  andl $7, %edx
  sarx %edx, %r8d, %edx
  jmp .L18
.L12:
  movl %eax, %edx
  andl $7, %edx
  shlx %edx, %r8d, %edx
  jmp .L18
.L13:
  andl %r8d, %esi
  movl %esi, %edx
  jmp .L18
.L14:
  orl %r8d, %esi
  movl %esi, %edx
  jmp .L18
.L15:
  xorl %r8d, %esi
  movl %esi, %edx
  jmp .L18
.L16:
  imull %r8d, %esi
  movl %esi, %edx
  jmp .L18
.L17:
  movl %r8d, %edx
  subl %esi, %edx
  jmp .L18
.L5:
  andl %r8d, %esi
  leal 2(%rsi), %edx
  jmp .L18
.L6:
  orl %r8d, %esi
  leal -1(%rsi), %edx
  jmp .L18
.L7:
  xorl %r8d, %esi
  leal 1(%rsi), %edx
  jmp .L18
.L8:
  subl %esi, %r8d
  leal (%r8,%r8,4), %edx
  jmp .L18
.L9:
  addl %r8d, %esi
  leal (%rsi,%rsi,2), %edx
  jmp .L18
.L2:
  leal (%rsi,%r8), %edx
  jmp .L18

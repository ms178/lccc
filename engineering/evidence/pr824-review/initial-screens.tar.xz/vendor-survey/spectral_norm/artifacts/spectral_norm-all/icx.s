.LCPI0_0:
.LCPI0_1:
.LCPI0_2:
.LCPI0_3:
.LCPI0_4:
main:
  subq $48008, %rsp
  vstmxcsr 16000(%rsp)
  orl $32832, 16000(%rsp)
  vldmxcsr 16000(%rsp)
  movq $-40, %rax
  vbroadcastsd .LCPI0_0(%rip), %ymm0
.LBB0_1:
  vmovups %ymm0, 320(%rsp,%rax,8)
  vmovups %ymm0, 352(%rsp,%rax,8)
  vmovups %ymm0, 384(%rsp,%rax,8)
  vmovups %ymm0, 416(%rsp,%rax,8)
  vmovups %ymm0, 448(%rsp,%rax,8)
  vmovups %ymm0, 480(%rsp,%rax,8)
  vmovups %ymm0, 512(%rsp,%rax,8)
  vmovups %ymm0, 544(%rsp,%rax,8)
  vmovups %ymm0, 576(%rsp,%rax,8)
  vmovups %ymm0, 608(%rsp,%rax,8)
  addq $40, %rax
  cmpq $1960, %rax
  jb .LBB0_1
  xorl %eax, %eax
  vmovdqu .LCPI0_1(%rip), %xmm0
  vmovdqu .LCPI0_2(%rip), %xmm1
  vpcmpeqd %xmm2, %xmm2, %xmm2
  vmovdqu .LCPI0_3(%rip), %ymm3
  vmovdqu .LCPI0_4(%rip), %ymm4
.LBB0_3:
  movl $4, %ecx
  xorl %edx, %edx
.LBB0_4:
  vmovd %edx, %xmm5
  vpbroadcastd %xmm5, %xmm6
  vpxor %xmm5, %xmm5, %xmm5
  movq $-4, %rsi
  movl %ecx, %edi
.LBB0_5:
  leal -4(%rdi), %r8d
  vmovd %r8d, %xmm7
  vpbroadcastd %xmm7, %xmm7
  vpaddd %xmm0, %xmm7, %xmm8
  vpaddd %xmm1, %xmm7, %xmm7
  vpmulld %xmm7, %xmm8, %xmm7
  vpsrld $31, %xmm7, %xmm8
  vpaddd %xmm7, %xmm8, %xmm7
  vmovupd 32(%rsp,%rsi,8), %ymm8
  vmovd %edi, %xmm9
  vpsrad $1, %xmm7, %xmm7
  vpbroadcastd %xmm9, %xmm9
  vpaddd %xmm0, %xmm9, %xmm10
  vpaddd %xmm1, %xmm9, %xmm9
  vpaddd %xmm6, %xmm7, %xmm7
  vpmulld %xmm9, %xmm10, %xmm9
  vpsrld $31, %xmm9, %xmm10
  vpsubd %xmm2, %xmm7, %xmm7
  vpaddd %xmm10, %xmm9, %xmm9
  vpsrad $1, %xmm9, %xmm9
  vcvtdq2pd %xmm7, %ymm7
  vpaddd %xmm6, %xmm9, %xmm9
  vpsubd %xmm2, %xmm9, %xmm9
  vcvtdq2pd %xmm9, %ymm9
  vmovupd 64(%rsp,%rsi,8), %ymm10
  vdivpd %ymm7, %ymm8, %ymm7
  vdivpd %ymm9, %ymm10, %ymm8
  vaddpd %ymm5, %ymm7, %ymm5
  vaddpd %ymm5, %ymm8, %ymm5
  addl $8, %edi
  addq $8, %rsi
  cmpq $1996, %rsi
  jb .LBB0_5
  vextractf128 $1, %ymm5, %xmm6
  vaddpd %xmm6, %xmm5, %xmm5
  vshufpd $1, %xmm5, %xmm5, %xmm6
  vaddsd %xmm6, %xmm5, %xmm5
  vmovsd %xmm5, 16000(%rsp,%rdx,8)
  leaq 1(%rdx), %rsi
  incl %ecx
  cmpq $1999, %rdx
  movq %rsi, %rdx
  jne .LBB0_4
  xorl %ecx, %ecx
.LBB0_8:
  vxorpd %xmm5, %xmm5, %xmm5
  vxorpd %xmm6, %xmm6, %xmm6
  xorl %edx, %edx
.LBB0_9:
  leal (%rcx,%rdx), %esi
  vmovd %esi, %xmm7
  vpbroadcastd %xmm7, %ymm7
  vpaddd %ymm3, %ymm7, %ymm8
  vpaddd %ymm4, %ymm7, %ymm7
  vpmulld %ymm7, %ymm8, %ymm7
  vpsrld $31, %ymm7, %ymm8
  vpaddd %ymm7, %ymm8, %ymm7
  vpsrad $1, %ymm7, %ymm7
  vmovd %edx, %xmm8
  vpbroadcastd %xmm8, %ymm8
  vpaddd %ymm3, %ymm8, %ymm8
  vpaddd %ymm7, %ymm8, %ymm7
  vextracti128 $1, %ymm7, %xmm8
  vcvtdq2pd %xmm8, %ymm8
  vcvtdq2pd %xmm7, %ymm7
  vmovupd 16000(%rsp,%rdx,8), %ymm9
  vdivpd %ymm7, %ymm9, %ymm7
  vmovupd 16032(%rsp,%rdx,8), %ymm9
  vdivpd %ymm8, %ymm9, %ymm8
  vaddpd %ymm6, %ymm8, %ymm6
  vaddpd %ymm5, %ymm7, %ymm5
  leaq 8(%rdx), %rsi
  cmpq $1992, %rdx
  movq %rsi, %rdx
  jb .LBB0_9
  vaddpd %ymm6, %ymm5, %ymm5
  vextractf128 $1, %ymm5, %xmm6
  vaddpd %xmm6, %xmm5, %xmm5
  vshufpd $1, %xmm5, %xmm5, %xmm6
  vaddsd %xmm6, %xmm5, %xmm5
  vmovsd %xmm5, 32000(%rsp,%rcx,8)
  leaq 1(%rcx), %rdx
  cmpq $1999, %rcx
  movq %rdx, %rcx
  jne .LBB0_8
  movl $4, %ecx
  xorl %edx, %edx
.LBB0_12:
  vmovd %edx, %xmm5
  vpbroadcastd %xmm5, %xmm6
  vpxor %xmm5, %xmm5, %xmm5
  movq $-4, %rsi
  movl %ecx, %edi
.LBB0_13:
  leal -4(%rdi), %r8d
  vmovd %r8d, %xmm7
  vpbroadcastd %xmm7, %xmm7
  vpaddd %xmm0, %xmm7, %xmm8
  vpaddd %xmm1, %xmm7, %xmm7
  vpmulld %xmm7, %xmm8, %xmm7
  vpsrld $31, %xmm7, %xmm8
  vpaddd %xmm7, %xmm8, %xmm7
  vmovupd 32032(%rsp,%rsi,8), %ymm8
  vmovd %edi, %xmm9
  vpsrad $1, %xmm7, %xmm7
  vpbroadcastd %xmm9, %xmm9
  vpaddd %xmm0, %xmm9, %xmm10
  vpaddd %xmm1, %xmm9, %xmm9
  vpaddd %xmm6, %xmm7, %xmm7
  vpmulld %xmm9, %xmm10, %xmm9
  vpsrld $31, %xmm9, %xmm10
  vpsubd %xmm2, %xmm7, %xmm7
  vpaddd %xmm10, %xmm9, %xmm9
  vpsrad $1, %xmm9, %xmm9
  vcvtdq2pd %xmm7, %ymm7
  vpaddd %xmm6, %xmm9, %xmm9
  vpsubd %xmm2, %xmm9, %xmm9
  vcvtdq2pd %xmm9, %ymm9
  vmovupd 32064(%rsp,%rsi,8), %ymm10
  vdivpd %ymm7, %ymm8, %ymm7
  vdivpd %ymm9, %ymm10, %ymm8
  vaddpd %ymm5, %ymm7, %ymm5
  vaddpd %ymm5, %ymm8, %ymm5
  addl $8, %edi
  addq $8, %rsi
  cmpq $1996, %rsi
  jb .LBB0_13
  vextractf128 $1, %ymm5, %xmm6
  vaddpd %xmm6, %xmm5, %xmm5
  vshufpd $1, %xmm5, %xmm5, %xmm6
  vaddsd %xmm6, %xmm5, %xmm5
  vmovsd %xmm5, 16000(%rsp,%rdx,8)
  leaq 1(%rdx), %rsi
  incl %ecx
  cmpq $1999, %rdx
  movq %rsi, %rdx
  jne .LBB0_12
  xorl %ecx, %ecx
.LBB0_16:
  vxorpd %xmm5, %xmm5, %xmm5
  xorl %edx, %edx
  vxorpd %xmm6, %xmm6, %xmm6
.LBB0_17:
  leal (%rcx,%rdx), %esi
  vmovd %esi, %xmm7
  vpbroadcastd %xmm7, %ymm7
  vpaddd %ymm3, %ymm7, %ymm8
  vpaddd %ymm4, %ymm7, %ymm7
  vpmulld %ymm7, %ymm8, %ymm7
  vpsrld $31, %ymm7, %ymm8
  vpaddd %ymm7, %ymm8, %ymm7
  vpsrad $1, %ymm7, %ymm7
  vmovd %edx, %xmm8
  vpbroadcastd %xmm8, %ymm8
  vpaddd %ymm3, %ymm8, %ymm8
  vpaddd %ymm7, %ymm8, %ymm7
  vextracti128 $1, %ymm7, %xmm8
  vcvtdq2pd %xmm8, %ymm8
  vcvtdq2pd %xmm7, %ymm7
  vmovupd 16000(%rsp,%rdx,8), %ymm9
  vdivpd %ymm7, %ymm9, %ymm7
  vmovupd 16032(%rsp,%rdx,8), %ymm9
  vdivpd %ymm8, %ymm9, %ymm8
  vaddpd %ymm6, %ymm8, %ymm6
  vaddpd %ymm5, %ymm7, %ymm5
  leaq 8(%rdx), %rsi
  cmpq $1992, %rdx
  movq %rsi, %rdx
  jb .LBB0_17
  vaddpd %ymm6, %ymm5, %ymm5
  vextractf128 $1, %ymm5, %xmm6
  vaddpd %xmm6, %xmm5, %xmm5
  vshufpd $1, %xmm5, %xmm5, %xmm6
  vaddsd %xmm6, %xmm5, %xmm5
  vmovsd %xmm5, (%rsp,%rcx,8)
  leaq 1(%rcx), %rdx
  cmpq $1999, %rcx
  movq %rdx, %rcx
  jne .LBB0_16
  leal 1(%rax), %ecx
  cmpl $9, %eax
  movl %ecx, %eax
  jne .LBB0_3
  vpxor %xmm0, %xmm0, %xmm0
  movq $-20, %rax
  vpxor %xmm1, %xmm1, %xmm1
.LBB0_21:
  vmovupd 32160(%rsp,%rax,8), %ymm2
  vmovupd 32192(%rsp,%rax,8), %ymm3
  vmovupd 32224(%rsp,%rax,8), %ymm4
  vmovupd 32256(%rsp,%rax,8), %ymm5
  vfmadd231pd 160(%rsp,%rax,8), %ymm2, %ymm1
  vfmadd231pd %ymm2, %ymm2, %ymm0
  vfmadd231pd 192(%rsp,%rax,8), %ymm3, %ymm1
  vfmadd231pd %ymm3, %ymm3, %ymm0
  vfmadd231pd 224(%rsp,%rax,8), %ymm4, %ymm1
  vfmadd231pd 256(%rsp,%rax,8), %ymm5, %ymm1
  vfmadd231pd %ymm4, %ymm4, %ymm0
  vmovupd 32288(%rsp,%rax,8), %ymm2
  vfmadd231pd 288(%rsp,%rax,8), %ymm2, %ymm1
  vfmadd231pd %ymm5, %ymm5, %ymm0
  vfmadd231pd %ymm2, %ymm2, %ymm0
  addq $20, %rax
  cmpq $1980, %rax
  jb .LBB0_21
  vextractf128 $1, %ymm1, %xmm2
  vaddpd %xmm2, %xmm1, %xmm1
  vshufpd $1, %xmm1, %xmm1, %xmm2
  vaddsd %xmm2, %xmm1, %xmm1
  vextractf128 $1, %ymm0, %xmm2
  vaddpd %xmm2, %xmm0, %xmm0
  vshufpd $1, %xmm0, %xmm0, %xmm2
  vaddsd %xmm2, %xmm0, %xmm0
  vdivsd %xmm0, %xmm1, %xmm0
  vsqrtsd %xmm0, %xmm0, %xmm0
  movl $.L.str, %edi
  movb $1, %al
  vzeroupper
  callq printf
  xorl %eax, %eax
  addq $48008, %rsp
  retq

.L.str:


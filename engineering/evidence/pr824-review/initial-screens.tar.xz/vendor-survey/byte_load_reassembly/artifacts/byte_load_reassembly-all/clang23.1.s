.LCPI0_0:
.LCPI0_10:
.LCPI0_9:
.LCPI0_11:
.LCPI0_12:
.LCPI0_13:
.LCPI0_14:
.LCPI0_15:
.LCPI0_16:
.LCPI0_17:
.LCPI0_18:
.LCPI0_19:
.LCPI0_20:
.LCPI0_21:
.LCPI0_22:
main:
  vmovdqa .LCPI0_0(%rip), %ymm0
  xorl %eax, %eax
  vpbroadcastd .LCPI0_15(%rip), %ymm1
  vpbroadcastd .LCPI0_16(%rip), %ymm2
  vpbroadcastd .LCPI0_17(%rip), %ymm3
  vpbroadcastd .LCPI0_18(%rip), %ymm4
  vpbroadcastd .LCPI0_19(%rip), %ymm5
  vpbroadcastd .LCPI0_20(%rip), %ymm6
  vpbroadcastd .LCPI0_21(%rip), %ymm7
  leaq main.buf(%rip), %rcx
  vpbroadcastd .LCPI0_22(%rip), %ymm8
.LBB0_1:
  vpmaddubsw %ymm1, %ymm0, %ymm9
  vpsllw $8, %ymm9, %ymm9
  vpmullw %ymm2, %ymm0, %ymm10
  vpand %ymm3, %ymm10, %ymm10
  vpor %ymm9, %ymm10, %ymm9
  vpaddb %ymm4, %ymm9, %ymm10
  vpaddb %ymm5, %ymm9, %ymm11
  vpaddb %ymm6, %ymm9, %ymm12
  vpaddb %ymm7, %ymm9, %ymm9
  vmovdqu %ymm10, (%rax,%rcx)
  vmovdqu %ymm11, 32(%rax,%rcx)
  vmovdqu %ymm12, 64(%rax,%rcx)
  vmovdqu %ymm9, 96(%rax,%rcx)
  subq $-128, %rax
  vpxor %ymm0, %ymm8, %ymm0
  cmpq $4096, %rax
  jne .LBB0_1
  vmovdqa .LCPI0_9(%rip), %xmm0
  vmovdqa %xmm0, main.fr(%rip)
  movl $287454020, main.fr+16(%rip)
  movabsq $578437695752307201, %rdx
  movq %rdx, main.buf(%rip)
  movl $3, %eax
  xorl %esi, %esi
  testb %sil, %sil
  jne .LBB0_10
  movl $4, %eax
  cmpq %rdx, main.buf(%rip)
  jne .LBB0_10
  movl $6, %eax
  movabsq $-579005069656919568, %rdx
  cmpq %rdx, main.fr+8(%rip)
  jne .LBB0_10
  movl $3840, %eax
  xorl main.buf+3840(%rip), %eax
  movl $3848, %edx
  xorl main.buf+3848(%rip), %edx
  addl %eax, %edx
  movl $3856, %eax
  xorl main.buf+3856(%rip), %eax
  movl $3864, %esi
  xorl main.buf+3864(%rip), %esi
  addl %eax, %esi
  addl %edx, %esi
  movl $3872, %eax
  xorl main.buf+3872(%rip), %eax
  movl $3880, %edx
  xorl main.buf+3880(%rip), %edx
  addl %eax, %edx
  movl $3888, %edi
  xorl main.buf+3888(%rip), %edi
  addl %edx, %edi
  addl %esi, %edi
  movl $3896, %eax
  xorl main.buf+3896(%rip), %eax
  movl $3904, %edx
  xorl main.buf+3904(%rip), %edx
  addl %eax, %edx
  movl $3912, %esi
  xorl main.buf+3912(%rip), %esi
  addl %edx, %esi
  movl $3920, %eax
  xorl main.buf+3920(%rip), %eax
  addl %esi, %eax
  addl %edi, %eax
  movl $3928, %edx
  xorl main.buf+3928(%rip), %edx
  movl $3936, %esi
  xorl main.buf+3936(%rip), %esi
  addl %edx, %esi
  movl $3944, %edx
  xorl main.buf+3944(%rip), %edx
  addl %esi, %edx
  movl $3952, %esi
  xorl main.buf+3952(%rip), %esi
  addl %edx, %esi
  movl $3960, %edx
  xorl main.buf+3960(%rip), %edx
  addl %esi, %edx
  addl %eax, %edx
  movl $3968, %eax
  xorl main.buf+3968(%rip), %eax
  movl $3976, %esi
  xorl main.buf+3976(%rip), %esi
  addl %eax, %esi
  movl $3984, %eax
  xorl main.buf+3984(%rip), %eax
  addl %esi, %eax
  movl $3992, %esi
  xorl main.buf+3992(%rip), %esi
  addl %eax, %esi
  movl $4000, %edi
  xorl main.buf+4000(%rip), %edi
  addl %esi, %edi
  movl $4008, %eax
  xorl main.buf+4008(%rip), %eax
  addl %edi, %eax
  addl %edx, %eax
  movl $4016, %edx
  xorl main.buf+4016(%rip), %edx
  movl $4024, %esi
  xorl main.buf+4024(%rip), %esi
  addl %edx, %esi
  movl $4032, %edx
  xorl main.buf+4032(%rip), %edx
  addl %esi, %edx
  movl $4040, %esi
  xorl main.buf+4040(%rip), %esi
  addl %edx, %esi
  movl $4048, %edx
  xorl main.buf+4048(%rip), %edx
  addl %esi, %edx
  movl $4056, %esi
  xorl main.buf+4056(%rip), %esi
  addl %edx, %esi
  movl $4064, %edx
  xorl main.buf+4064(%rip), %edx
  addl %esi, %edx
  addl %eax, %edx
  movl $4072, %eax
  xorl main.buf+4072(%rip), %eax
  movl $4080, %esi
  xorl main.buf+4080(%rip), %esi
  addl %eax, %esi
  movl $4088, %eax
  xorl main.buf+4088(%rip), %eax
  addl %esi, %eax
  addl %edx, %eax
  xorl %esi, %esi
  vpbroadcastd .LCPI0_11(%rip), %ymm1
  vpbroadcastd .LCPI0_12(%rip), %ymm2
  vpbroadcastd .LCPI0_13(%rip), %ymm3
  vpbroadcastd .LCPI0_14(%rip), %ymm4
  xorl %edx, %edx
.LBB0_6:
  vmovd %esi, %xmm5
  vpxor %xmm6, %xmm6, %xmm6
  movl $24, %esi
  vpxor %xmm7, %xmm7, %xmm7
  vpxor %xmm8, %xmm8, %xmm8
  vmovdqa .LCPI0_10(%rip), %ymm9
.LBB0_7:
  vpaddd %ymm1, %ymm9, %ymm10
  vpaddd %ymm2, %ymm9, %ymm11
  vpaddd %ymm3, %ymm9, %ymm12
  vmovups -192(%rcx,%rsi,8), %ymm13
  vmovups -128(%rcx,%rsi,8), %ymm14
  vmovups -64(%rcx,%rsi,8), %ymm15
  vmovups (%rcx,%rsi,8), %ymm0
  vshufps $136, -160(%rcx,%rsi,8), %ymm13, %ymm13
  vpermpd $216, %ymm13, %ymm13
  vshufps $136, -96(%rcx,%rsi,8), %ymm14, %ymm14
  vpermpd $216, %ymm14, %ymm14
  vxorps %ymm10, %ymm14, %ymm10
  vpaddd %ymm6, %ymm10, %ymm6
  vshufps $136, -32(%rcx,%rsi,8), %ymm15, %ymm10
  vpermpd $216, %ymm10, %ymm10
  vxorps %ymm11, %ymm10, %ymm10
  vpaddd %ymm7, %ymm10, %ymm7
  vshufps $136, 32(%rcx,%rsi,8), %ymm0, %ymm0
  vpermpd $216, %ymm0, %ymm0
  vxorps %ymm0, %ymm12, %ymm0
  vpaddd %ymm0, %ymm8, %ymm8
  vxorps %ymm9, %ymm13, %ymm0
  vpaddd %ymm5, %ymm0, %ymm5
  vpaddd %ymm4, %ymm9, %ymm9
  addq $32, %rsi
  cmpq $504, %rsi
  jne .LBB0_7
  vpaddd %ymm5, %ymm6, %ymm0
  vpaddd %ymm0, %ymm7, %ymm0
  vpaddd %ymm0, %ymm8, %ymm0
  vextracti128 $1, %ymm0, %xmm5
  vpaddd %xmm5, %xmm0, %xmm0
  vpshufd $238, %xmm0, %xmm5
  vpaddd %xmm5, %xmm0, %xmm0
  vpshufd $85, %xmm0, %xmm5
  vpaddd %xmm5, %xmm0, %xmm0
  vmovd %xmm0, %esi
  addl %eax, %esi
  incq %rdx
  cmpq $20000, %rdx
  jne .LBB0_6
  pushq %rax
  leaq .L.str(%rip), %rdi
  movabsq $4453885151207054848, %rdx
  xorl %eax, %eax
  vzeroupper
  callq printf@PLT
  xorl %eax, %eax
  addq $8, %rsp
.LBB0_10:
  vzeroupper
  retq

.L.str:


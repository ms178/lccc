.Lstr0:

main.buf.0:
main.fr.1:

body_le64:
    movq 8(%rdi), %rax
    ret

main:
    pushq %rbx
    pushq %r12
    pushq %r13
    pushq %r14
    pushq %r15
    pushq %rbp
    subq $24, %rsp
    leaq main.buf.0(%rip), %r11
    xorl %ebx, %ebx
.LBB2:
    cmpq $4096, %rbx
jae .LBB4
.LBB3:
    imulq $37, %rbx, %r9
    leaq 11(%r9), %rdi
    movb %dil, (%r11, %rbx)
    addq $1, %rbx
    cmpq $4096, %rbx
jb .LBB3
.LBB4:
    movb $1, main.fr.1(%rip)
    movb $240, main.fr.1+8(%rip)
    movb $2, main.fr.1+1(%rip)
    movb $241, main.fr.1+9(%rip)
    movb $3, main.fr.1+2(%rip)
    movb $242, main.fr.1+10(%rip)
    movb $4, main.fr.1+3(%rip)
    movb $243, main.fr.1+11(%rip)
    movb $5, main.fr.1+4(%rip)
    movb $244, main.fr.1+12(%rip)
    movb $6, main.fr.1+5(%rip)
    movb $245, main.fr.1+13(%rip)
    movb $7, main.fr.1+6(%rip)
    movb $246, main.fr.1+14(%rip)
    movb $8, main.fr.1+7(%rip)
    movb $247, main.fr.1+15(%rip)
    movl $287454020, main.fr.1+16(%rip)
    movb $1, main.buf.0(%rip)
    movb $2, main.buf.0+1(%rip)
    movb $3, main.buf.0+2(%rip)
    movb $4, main.buf.0+3(%rip)
    movb $5, main.buf.0+4(%rip)
    movb $6, main.buf.0+5(%rip)
    movb $7, main.buf.0+6(%rip)
    movb $8, main.buf.0+7(%rip)
    movzwl main.buf.0(%rip), %edx
    cmpw $513, %dx
je .LBB6
.LBB5:
    movl $2, %eax
.L__lccc_epilogue_1:
    addq $24, %rsp
    popq %rbp
    popq %r15
    popq %r14
    popq %r13
    popq %r12
    popq %rbx
    ret
.LBB6:
    movzbl main.buf.0(%rip), %r11d
    movl %r11d, %r10d
    movzbl main.buf.0+1(%rip), %r8d
    movl %r8d, %r9d
    shll $8, %r9d
    orl %r9d, %r10d
    movzbl main.buf.0+2(%rip), %edi
    movl %edi, %esi
    shll $16, %esi
    orl %esi, %r10d
    movzbl main.buf.0+3(%rip), %edx
    movl %edx, %r9d
    shll $24, %r9d
    orl %r9d, %r10d
    cmpl $67305985, %r10d
je .LBB8
.LBB7:
    movl $3, %eax
    jmp .L__lccc_epilogue_1
.LBB8:
    movzbl %r11b, %esi
    movzbl %r8b, %r11d
    shlq $8, %r11
    orq %r11, %rsi
    movzbl %dil, %r10d
    shlq $16, %r10
    orq %r10, %rsi
    movzbl %dl, %r8d
    shlq $24, %r8
    orq %r8, %rsi
    movzbl main.buf.0+4(%rip), %r9d
    movl %r9d, %edi
    shlq $32, %rdi
    orq %rdi, %rsi
    movzbl main.buf.0+5(%rip), %edx
    movl %edx, %r11d
    shlq $40, %r11
    orq %r11, %rsi
    movzbl main.buf.0+6(%rip), %r10d
    movl %r10d, %r8d
    shlq $48, %r8
    orq %r8, %rsi
    movabsq $576460752303423488, %rax
    orq %rax, %rsi
    movabsq $578437695752307201, %rcx
    cmpq %rcx, %rsi
je .LBB10
.LBB9:
    movl $4, %eax
    jmp .L__lccc_epilogue_1
.LBB10:
    movzbl main.buf.0(%rip), %edi
    shlq $56, %rdi
    movzbl main.buf.0+1(%rip), %esi
    shlq $48, %rsi
    orq %rsi, %rdi
    movzbl main.buf.0+2(%rip), %r11d
    shlq $40, %r11
    orq %r11, %rdi
    movzbl main.buf.0+3(%rip), %r8d
    shlq $32, %r8
    orq %r8, %rdi
    movzbl %r9b, %esi
    shlq $24, %rsi
    orq %rsi, %rdi
    movzbl %dl, %r11d
    shlq $16, %r11
    orq %r11, %rdi
    movzbl %r10b, %r8d
    shlq $8, %r8
    orq %r8, %rdi
    orq $8, %rdi
    movabsq $72623859790382856, %rcx
    cmpq %rcx, %rdi
je .LBB12
.LBB11:
    movl $5, %eax
    jmp .L__lccc_epilogue_1
.LBB12:
    leaq main.fr.1(%rip), %rdi
    call body_le64
    movabsq $-579005069656919568, %rcx
    cmpq %rcx, %rax
jne .LBB20
.LBB13:
    xorl %r12d, %r12d
    xorl %r13d, %r13d
    xorl %r14d, %r14d
.LBB14:
    cmpq $20000, %r13
jae .LBB19
.LBB15:
    xorl %r15d, %r15d
    movq %r12, %rbp
    leaq main.buf.0(%rip), %rbx
.LBB16:
    leaq 8(%r15), %rsi
    cmpq $4096, %rsi
ja .LBB18
.LBB17:
    movl (%rbx), %edx
    xorl %r15d, %edx
    addl %edx, %ebp
    addq $8, %r15
    leaq 8(%rbx), %rbx
    leaq 8(%r15), %r10
    cmpq $4096, %r10
jbe .LBB17
.LBB18:
    leaq main.fr.1(%rip), %rdi
    call body_le64
    addq %rax, %r14
    addq $1, %r13
    movq %rbp, %r12
    cmpq $20000, %r13
jb .LBB15
.LBB19:
    leaq .Lstr0(%rip), %rdi
    movq %r12, %rsi
    movq %r14, %rdx
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    jmp .L__lccc_epilogue_1
.LBB20:
    movl $6, %eax
    jmp .L__lccc_epilogue_1



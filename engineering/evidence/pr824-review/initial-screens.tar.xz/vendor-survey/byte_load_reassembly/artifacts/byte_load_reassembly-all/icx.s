.LCPI0_0:
.LCPI0_1:
main:
  pushq %rax
  vstmxcsr 4(%rsp)
  orl $32832, 4(%rsp)
  vldmxcsr 4(%rsp)
  xorl %eax, %eax
  vmovdqu .LCPI0_0(%rip), %xmm0
.LBB0_1:
  vmovd %eax, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, main.buf(%rax)
  leal 80(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, main.buf+16(%rax)
  leal -96(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, main.buf+32(%rax)
  leal -16(%rax), %ecx
  vmovd %ecx, %xmm1
  vpbroadcastb %xmm1, %xmm1
  vpaddb %xmm0, %xmm1, %xmm1
  vmovdqu %xmm1, main.buf+48(%rax)
  leaq 48(%rax), %rcx
  addq $64, %rax
  cmpq $4080, %rcx
  jb .LBB0_1
  vmovups .LCPI0_1(%rip), %xmm0
  vmovups %xmm0, main.fr(%rip)
  movl $287454020, main.fr+16(%rip)
  movabsq $578437695752307201, %rax
  movq %rax, main.buf(%rip)
  xorl %eax, %eax
  xorl %esi, %esi
.LBB0_3:
  xorl %ecx, %ecx
.LBB0_4:
  movl main.buf(%rcx), %edx
  xorl %ecx, %edx
  leal 8(%rcx), %edi
  xorl main.buf+8(%rcx), %edi
  addl %esi, %edx
  leal 16(%rcx), %r8d
  xorl main.buf+16(%rcx), %r8d
  addl %edi, %r8d
  leal 24(%rcx), %esi
  xorl main.buf+24(%rcx), %esi
  addl %edx, %r8d
  addl %r8d, %esi
  addq $32, %rcx
  cmpq $4096, %rcx
  jne .LBB0_4
  leaq 1(%rax), %rcx
  cmpq $19999, %rax
  movq %rcx, %rax
  jne .LBB0_3
  movabsq $4453885151207054848, %rdx
  movl $.L.str, %edi
  xorl %eax, %eax
  callq printf
  xorl %eax, %eax
  popq %rcx
  retq

.L.str:


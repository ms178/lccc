.Lstr0:

main:
    subq $8, %rsp
    movsd .LCFP_0(%rip), %xmm2
    movsd .LCFP_1(%rip), %xmm3
    movsd .LCFP_2(%rip), %xmm4
    movsd .LCFP_3(%rip), %xmm5
    xorl %r11d, %r11d
    xorl %r10d, %r10d
.LBB1:
    cmpl $4000, %r10d
jge .LBB10
.LBB2:
    vcvtsi2sdl %r10d, %xmm0, %xmm6
    vaddsd %xmm6, %xmm6, %xmm6
    vdivsd %xmm2, %xmm6, %xmm6
    vsubsd %xmm4, %xmm6, %xmm6
    movq %r11, %r8
    xorl %r9d, %r9d
.LBB3:
    cmpl $4000, %r9d
jge .LBB9
.LBB4:
    vcvtsi2sdl %r9d, %xmm0, %xmm7
    vaddsd %xmm7, %xmm7, %xmm7
    vdivsd %xmm2, %xmm7, %xmm7
    vsubsd %xmm3, %xmm7, %xmm7
    xorpd %xmm8, %xmm8
    xorpd %xmm9, %xmm9
    xorl %edi, %edi
    xorpd %xmm10, %xmm10
.LBB5:
    cmpl $50, %edi
jge .LBB8
.LBB6:
    vfnmadd231sd %xmm10, %xmm10, %xmm8
    vaddsd %xmm7, %xmm8, %xmm12
    vaddsd %xmm9, %xmm9, %xmm9
    vfmadd132sd %xmm9, %xmm6, %xmm10
    vmulsd %xmm12, %xmm12, %xmm14
    vmovsd %xmm14, %xmm14, %xmm8
    vfmadd231sd %xmm10, %xmm10, %xmm8
    ucomisd %xmm5, %xmm8
ja .LBB8
.LBB7:
    addl $1, %edi
    movapd %xmm14, %xmm8
    vmovapd %xmm12, %xmm9
    cmpl $50, %edi
jl .LBB6
.LBB8:
    addl %edi, %r8d
    addl $1, %r9d
    cmpl $4000, %r9d
jl .LBB4
.LBB9:
    addl $1, %r10d
    movq %r8, %r11
    cmpl $4000, %r10d
jl .LBB2
.LBB10:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    xorl %eax, %eax
    addq $8, %rsp
    ret

.LCFP_0:
.LCFP_1:
.LCFP_2:
.LCFP_3:


.section .rodata
.Lstr0:
    .byte 37, 48, 49, 54, 108, 108, 120, 10, 0

.section .rodata
.align 16
.type K, @object
.size K, 256
K:
    .long 1116352408
    .long 1899447441
    .long 3049323471
    .long 3921009573
    .long 961987163
    .long 1508970993
    .long 2453635748
    .long 2870763221
    .long 3624381080
    .long 310598401
    .long 607225278
    .long 1426881987
    .long 1925078388
    .long 2162078206
    .long 2614888103
    .long 3248222580
    .long 3835390401
    .long 4022224774
    .long 264347078
    .long 604807628
    .long 770255983
    .long 1249150122
    .long 1555081692
    .long 1996064986
    .long 2554220882
    .long 2821834349
    .long 2952996808
    .long 3210313671
    .long 3336571891
    .long 3584528711
    .long 113926993
    .long 338241895
    .long 666307205
    .long 773529912
    .long 1294757372
    .long 1396182291
    .long 1695183700
    .long 1986661051
    .long 2177026350
    .long 2456956037
    .long 2730485921
    .long 2820302411
    .long 3259730800
    .long 3345764771
    .long 3516065817
    .long 3600352804
    .long 4094571909
    .long 275423344
    .long 430227734
    .long 506948616
    .long 659060556
    .long 883997877
    .long 958139571
    .long 1322822218
    .long 1537002063
    .long 1747873779
    .long 1955562222
    .long 2024104815
    .long 2227730452
    .long 2361852424
    .long 2428436474
    .long 2756734187
    .long 3204031479
    .long 3329325298

.text
.p2align 4
.type sha256_transform, @function
sha256_transform:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $280, %rsp
    .cfi_def_cfa_offset 336
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 0
    movq %rdi, %rbx
    xorl %edi, %edi
.LBB1:
    cmpq $64, %rdi
jge .LBB3
.p2align 5,,15
.p2align 4
.LBB2:
    vmovdqu (%rsi,%rdi), %ymm2
    vmovdqu %ymm2, 16(%rsp, %rdi)
    addq $32, %rdi
    cmpq $64, %rdi
jl .LBB2
.LBB3:
    movl $16, %esi
.LBB4:
    cmpl $64, %esi
jge .LBB6
.p2align 5,,15
.p2align 4
.LBB5:
    movslq %esi, %rdx
    shlq $2, %rdx
    addl $2, %esi
    vmovq 8(%rsp, %rdx), %xmm3
    vpslld $15, %xmm3, %xmm15
    vpsrld $17, %xmm3, %xmm14
    vpor %xmm14, %xmm15, %xmm15
    vpslld $13, %xmm3, %xmm14
    vpsrld $19, %xmm3, %xmm13
    vpor %xmm13, %xmm14, %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    vpsrld $10, %xmm3, %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    vmovq -12(%rsp, %rdx), %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq -44(%rsp, %rdx), %xmm4
    vpslld $25, %xmm4, %xmm14
    vpsrld $7, %xmm4, %xmm13
    vpor %xmm13, %xmm14, %xmm14
    vpslld $14, %xmm4, %xmm13
    vpsrld $18, %xmm4, %xmm12
    vpor %xmm12, %xmm13, %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    vpsrld $3, %xmm4, %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq -48(%rsp, %rdx), %xmm14
    vpaddd %xmm14, %xmm15, %xmm15
    vmovq %xmm15, 16(%rsp, %rdx)
    cmpl $64, %esi
jl .LBB5
.LBB6:
    movl (%rbx), %r12d
    movl 4(%rbx), %r10d
    movl 8(%rbx), %esi
    movl 12(%rbx), %r13d
    movl 16(%rbx), %r14d
    movl 20(%rbx), %r11d
    movl 24(%rbx), %edi
    movl 28(%rbx), %ebp
    xorl %r9d, %r9d
    movq %rbp, %r8
.LBB7:
    cmpl $64, %r9d
jge .LBB9
    leaq K(%rip), %rcx
.p2align 4,,10
.p2align 3
.LBB8:
    movslq %r9d, %rdx
    movl (%rcx, %rdx, 4), %eax
    movl %eax, 12(%rsp)
    movl 16(%rsp, %rdx, 4), %r15d
    leal (%rax, %r15), %edx
    addl %r8d, %edx
    movq %r14, %rbp
    andl %r11d, %ebp
    andnl %edi, %r14d, %r15d
    xorl %r15d, %ebp
    addl %ebp, %edx
    rorxl $6, %r14d, %ebp
    rorxl $11, %r14d, %r15d
    xorl %r15d, %ebp
    rorxl $25, %r14d, %r15d
    xorl %r15d, %ebp
    addl %edx, %ebp
    rorxl $2, %r12d, %edx
    rorxl $13, %r12d, %r15d
    xorl %r15d, %edx
    rorxl $22, %r12d, %r15d
    xorl %r15d, %edx
    movl %r12d, %r15d
    andl %r10d, %r15d
    movl %r12d, %eax
    xorl %r10d, %eax
    andl %esi, %eax
    xorl %eax, %r15d
    addl %r15d, %edx
    addl $1, %r9d
    movq %rdi, %r8
    movq %r11, %rdi
    movq %r14, %r11
    leal (%r13, %rbp), %r14d
    movq %rsi, %r13
    movq %r10, %rsi
    movq %r12, %r10
    leal (%rbp, %rdx), %r12d
    cmpl $64, %r9d
jl .LBB8
.LBB9:
    vmovdqu (%rbx), %xmm15
    vmovd %r12d, %xmm0
    vmovd %r10d, %xmm1
    vpunpckldq %xmm1, %xmm0, %xmm0
    movq %rsi, %rax
    shlq $32, %r13
    orq %r13, %rax
    vmovq %rax, %xmm1
    vpunpcklqdq %xmm1, %xmm0, %xmm0
    vpaddd %xmm0, %xmm15, %xmm15
    vmovdqu %xmm15, (%rbx)
    vmovdqu 16(%rbx), %xmm15
    vmovd %r14d, %xmm0
    vmovd %r11d, %xmm1
    vpunpckldq %xmm1, %xmm0, %xmm0
    movq %rdi, %rax
    shlq $32, %r8
    orq %r8, %rax
    vmovq %rax, %xmm1
    vpunpcklqdq %xmm1, %xmm0, %xmm0
    vpaddd %xmm0, %xmm15, %xmm15
    vmovdqu %xmm15, 16(%rbx)
    vzeroupper
    addq $280, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size sha256_transform, .-sha256_transform

.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    pushq %rbp
    .cfi_def_cfa_offset 56
    .cfi_offset %rbp, -56
    subq $472, %rsp
    .cfi_def_cfa_offset 528
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    movl $1779033703, 336(%rsp)
    movl $3144134277, 340(%rsp)
    movl $1013904242, 344(%rsp)
    movl $2773480762, 348(%rsp)
    movl $1359893119, 352(%rsp)
    movl $2600822924, 356(%rsp)
    movl $528734635, 360(%rsp)
    movl $1541459225, 364(%rsp)
    movl $1633837952, 272(%rsp)
    movl $0, 276(%rsp)
    movl $0, 280(%rsp)
    movl $0, 284(%rsp)
    pxor %xmm0, %xmm0
    movdqu %xmm0, 288(%rsp)
    movdqu %xmm0, 304(%rsp)
    movl $0, 320(%rsp)
    movl $0, 324(%rsp)
    movl $0, 328(%rsp)
    movl $24, 332(%rsp)
    leaq 336(%rsp), %rdi
    leaq 272(%rsp), %rsi
    call sha256_transform
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    movl 336(%rsp), %r8d
    cmpl $3128432319, %r8d
je .LBB21
.LBB11:
    xorl %r9d, %r9d
    jmp .LBB12
.LBB21:
    movl 340(%rsp), %esi
    cmpl $2399260650, %esi
je .LBB23
.LBB22:
    xorl %r9d, %r9d
    jmp .LBB12
.LBB23:
    movl 364(%rsp), %r10d
    cmpl $4060091821, %r10d
    movl $0, %ecx
    movl $1, %r9d
    cmovnel %ecx, %r9d
.LBB12:
    movl $1664525, %eax
    vmovd %eax, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    movdqu %xmm0, 176(%rsp)
    vmovdqa .LCVEC_0(%rip), %xmm0
    movdqu %xmm0, 144(%rsp)
    vmovdqa .LCVEC_1(%rip), %xmm0
    movdqu %xmm0, 112(%rsp)
    vmovdqa .LCVEC_2(%rip), %xmm0
    movdqu %xmm0, 80(%rsp)
    vmovdqa .LCVEC_3(%rip), %xmm0
    movdqu %xmm0, 48(%rsp)
    testl %r9d, %r9d
je .LBB20
.LBB13:
    xorl %r11d, %r11d
    xorl %r14d, %r14d
    jmp .LBB14
.LBB20:
    movl $2, %eax
.L__lccc_epilogue_1:
    addq $472, %rsp
    .cfi_def_cfa_offset 56
    popq %rbp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.LBB14:
    .cfi_def_cfa_offset 528
    cmpl $2, %r14d
jae .LBB19
.p2align 5,,15
.p2align 4
.LBB15:
    movq %r14, %rax
    xorq $1779033703, %rax
    movl %eax, 432(%rsp)
    movl $3144134277, 436(%rsp)
    movl $1013904242, 440(%rsp)
    movl $2773480762, 444(%rsp)
    movl $1359893119, 448(%rsp)
    movl $2600822924, 452(%rsp)
    movl $528734635, 456(%rsp)
    movl $1541459225, 460(%rsp)
    movq %r11, %rbx
    xorl %r15d, %r15d
.LBB16:
    cmpl $256, %r15d
jb .LBB18
.LBB17:
    addl $1, %r14d
    movq %rbx, %r11
    cmpl $2, %r14d
jb .LBB15
.LBB19:
    leaq .Lstr0(%rip), %rdi
    movq %r11, %rsi
    xorl %eax, %eax
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    xorl %eax, %eax
    jmp .L__lccc_epilogue_1
.p2align 5,,15
.p2align 4
.LBB18:
    vmovd %r15d, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 144(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 432(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 368(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 112(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 448(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 384(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm14
    movdqu 80(%rsp), %xmm1
    vpaddd %xmm1, %xmm14, %xmm14
    movdqu 432(%rsp), %xmm13
    vpxor %xmm13, %xmm14, %xmm14
    movdqu %xmm14, 400(%rsp)
    movdqu 176(%rsp), %xmm1
    vpmulld %xmm1, %xmm0, %xmm15
    movdqu 48(%rsp), %xmm1
    vpaddd %xmm1, %xmm15, %xmm15
    movdqu 448(%rsp), %xmm14
    vpxor %xmm14, %xmm15, %xmm15
    movdqu %xmm15, 416(%rsp)
    leaq 432(%rsp), %rdi
    leaq 368(%rsp), %rsi
    call sha256_transform
    # LCCC_CALL_ARGS 2
    # LCCC_CALL_FP 0
    movl 432(%rsp), %r8d
    shlq $32, %r8
    movl 460(%rsp), %eax
    xorq %rax, %r8
    movl 444(%rsp), %edi
    shlq $16, %rdi
    xorq %rdi, %r8
    addq %r8, %rbx
    addl $1, %r15d
    cmpl $256, %r15d
jb .LBB18
    jmp .LBB17
.cfi_endproc
.size main, .-main

.section .rodata
.p2align 4
.LCVEC_0:
    .quad 4354685479061291008
    .quad -5382687634497870146
.p2align 4
.LCVEC_1:
    .quad 3326683325652520316
    .quad -6410689792201608134
.p2align 4
.LCVEC_2:
    .quad 2298681167948782328
    .quad -7438691949905346122
.p2align 4
.LCVEC_3:
    .quad 1270679010245044340
    .quad -8466694107609084110

.section .note.GNU-stack,"",@progbits

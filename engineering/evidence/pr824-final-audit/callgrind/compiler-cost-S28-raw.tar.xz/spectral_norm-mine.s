.section .rodata
.Lstr0:
    .byte 37, 46, 57, 102, 10, 0

.text
.p2align 4
.type mul_AtAv, @function
mul_AtAv:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    subq $1224, %rsp
    .cfi_def_cfa_offset 1248
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 0
    movq %rsi, %rbx
    movq %rdx, %r12
    vmovdqa .LCVEC_0(%rip), %xmm15
    movl $1, %eax
    vmovd %eax, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vmovdqa %xmm0, %xmm14
    vmovsd .LCFP_1(%rip), %xmm2
    xorl %r11d, %r11d
.LBB1:
    cmpl $128, %r11d
jge .LBB16
.p2align 5,,15
.p2align 4
.LBB2:
    vmovd %r11d, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vmovdqa %xmm0, %xmm13
    vxorpd %xmm3, %xmm3, %xmm3
    xorl %r10d, %r10d
.LBB3:
    movl $128, %r8d
    subl %r10d, %r8d
    cmpl $3, %r8d
jg .LBB15
.LBB4:
    vmovapd %xmm3, %xmm4
    movq %r10, %r9
.LBB5:
    cmpl $128, %r9d
jge .LBB7
.p2align 4,,10
.p2align 3
.LBB6:
    leal (%r11, %r9), %edi
    leal 1(%rdi), %esi
    imull %esi, %edi
    sarl $1, %edi
    addl %r11d, %edi
    leal 1(%rdi), %eax
    vcvtsi2sdl %eax, %xmm0, %xmm5
    vdivsd %xmm5, %xmm2, %xmm6
    movslq %r9d, %r10
    vfmadd231sd (%rbx, %r10, 8), %xmm6, %xmm4
    addl $1, %r9d
    cmpl $128, %r9d
jl .LBB6
.LBB7:
    movslq %r11d, %rsi
    vmovsd %xmm4, 192(%rsp, %rsi, 8)
    addl $1, %r11d
    cmpl $128, %r11d
jl .LBB2
    jmp .LBB16
.p2align 5,,15
.p2align 4
.LBB8:
    vmovd %r9d, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vmovdqa %xmm0, %xmm13
    vxorpd %xmm2, %xmm2, %xmm2
    xorl %edi, %edi
.LBB9:
    movl $128, %esi
    subl %edi, %esi
    cmpl $3, %esi
jg .LBB14
.LBB10:
    vmovapd %xmm2, %xmm3
    movq %rdi, %r11
.LBB11:
    cmpl $128, %r11d
jge .LBB13
.p2align 4,,10
.p2align 3
.LBB12:
    leal (%r11, %r9), %r10d
    leal 1(%r10), %r8d
    imull %r8d, %r10d
    sarl $1, %r10d
    addl %r11d, %r10d
    leal 1(%r10), %eax
    vcvtsi2sdl %eax, %xmm0, %xmm4
    vdivsd %xmm4, %xmm9, %xmm5
    movslq %r11d, %rdi
    vfmadd231sd 192(%rsp, %rdi, 8), %xmm5, %xmm3
    leal 1(%r11), %eax
    movl %eax, %r11d
    cmpl $128, %eax
jl .LBB12
.LBB13:
    movslq %r9d, %r8
    vmovsd %xmm3, (%r12, %r8, 8)
    addl $1, %r9d
    cmpl $128, %r9d
jl .LBB8
    jmp .LBB18
.p2align 5,,15
.p2align 4
.LBB14:
    vmovd %edi, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vpaddd %xmm15, %xmm0, %xmm12
    vpaddd %xmm13, %xmm12, %xmm11
    vpaddd %xmm13, %xmm12, %xmm10
    vpaddd %xmm14, %xmm10, %xmm10
    vpmulld %xmm10, %xmm11, %xmm11
    vpsrad $31, %xmm11, %xmm8
    vpsrld $31, %xmm8, %xmm10
    vpaddd %xmm10, %xmm11, %xmm11
    vpsrad $1, %xmm11, %xmm11
    vpaddd %xmm12, %xmm11, %xmm11
    vpaddd %xmm14, %xmm11, %xmm11
    movslq %edi, %r11
    shlq $3, %r11
    vcvtdq2pd %xmm11, %ymm0
    vbroadcastsd .Lvc2(%rip), %ymm1
    vdivpd %ymm0, %ymm1, %ymm0
    vmulpd 192(%rsp, %r11), %ymm0, %ymm0
    vextractf128 $1, %ymm0, %xmm1
    vaddsd %xmm0, %xmm2, %xmm2
    vunpckhpd %xmm0, %xmm0, %xmm0
    vaddsd %xmm0, %xmm2, %xmm2
    vaddsd %xmm1, %xmm2, %xmm2
    vunpckhpd %xmm1, %xmm1, %xmm1
    vaddsd %xmm1, %xmm2, %xmm2
    addl $4, %edi
    movl $128, %r10d
    subl %edi, %r10d
    cmpl $3, %r10d
jg .LBB14
    jmp .LBB10
.p2align 5,,15
.p2align 4
.LBB15:
    vmovd %r10d, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vpaddd %xmm15, %xmm0, %xmm11
    vpaddd %xmm11, %xmm13, %xmm12
    vpaddd %xmm11, %xmm13, %xmm11
    vpaddd %xmm14, %xmm11, %xmm11
    vpmulld %xmm11, %xmm12, %xmm12
    vpsrad $31, %xmm12, %xmm4
    vpsrld $31, %xmm4, %xmm11
    vpaddd %xmm11, %xmm12, %xmm12
    vpsrad $1, %xmm12, %xmm12
    vpaddd %xmm13, %xmm12, %xmm12
    vpaddd %xmm14, %xmm12, %xmm12
    movslq %r10d, %r8
    shlq $3, %r8
    vcvtdq2pd %xmm12, %ymm0
    vbroadcastsd .Lvc2(%rip), %ymm1
    vdivpd %ymm0, %ymm1, %ymm0
    vmulpd (%rbx,%r8), %ymm0, %ymm0
    vextractf128 $1, %ymm0, %xmm1
    vaddsd %xmm0, %xmm3, %xmm3
    vunpckhpd %xmm0, %xmm0, %xmm0
    vaddsd %xmm0, %xmm3, %xmm3
    vaddsd %xmm1, %xmm3, %xmm3
    vunpckhpd %xmm1, %xmm1, %xmm1
    vaddsd %xmm1, %xmm3, %xmm3
    addl $4, %r10d
    movl $128, %r9d
    subl %r10d, %r9d
    cmpl $3, %r9d
jg .LBB15
    jmp .LBB4
.LBB16:
    vmovdqa .LCVEC_0(%rip), %xmm15
    movl $1, %eax
    vmovd %eax, %xmm0
    vpshufd $0x00, %xmm0, %xmm0
    vmovdqa %xmm0, %xmm14
    vmovsd .LCFP_1(%rip), %xmm9
    xorl %r9d, %r9d
.LBB17:
    cmpl $128, %r9d
jl .LBB8
.LBB18:
    vzeroupper
    addq $1224, %rsp
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size mul_AtAv, .-mul_AtAv

.section .rodata
.align 4
.Lvc2:
    .quad 4607182418800017408
.section .text,"ax",@progbits
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    subq $2064, %rsp
    .cfi_def_cfa_offset 2096
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    xorl %ebx, %ebx
.LBB20:
    cmpl $128, %ebx
jge .LBB22
.p2align 4,,10
.p2align 3
.LBB21:
    movslq %ebx, %r11
    movsd .LCFP_1(%rip), %xmm0
    movsd %xmm0, 1032(%rsp, %r11, 8)
    addl $1, %ebx
    cmpl $128, %ebx
jl .LBB21
.LBB22:
    xorl %r12d, %r12d
.LBB23:
    cmpl $10, %r12d
jge .LBB25
.p2align 4,,10
.p2align 3
.LBB24:
    movl $128, %edi
    leaq 1032(%rsp), %rsi
    leaq 8(%rsp), %rdx
    call mul_AtAv
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movl $128, %edi
    leaq 8(%rsp), %rsi
    leaq 1032(%rsp), %rdx
    call mul_AtAv
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    addl $1, %r12d
    cmpl $10, %r12d
jl .LBB24
.LBB25:
    xorpd %xmm2, %xmm2
    xorl %r13d, %r13d
    xorpd %xmm3, %xmm3
.LBB26:
    cmpl $128, %r13d
jge .LBB28
.p2align 4,,10
.p2align 3
.LBB27:
    movslq %r13d, %r9
    movsd 1032(%rsp, %r9, 8), %xmm4
    movsd 8(%rsp, %r9, 8), %xmm5
    vfmadd231sd %xmm5, %xmm4, %xmm3
    vfmadd231sd %xmm5, %xmm5, %xmm2
    addl $1, %r13d
    cmpl $128, %r13d
jl .LBB27
.LBB28:
    vdivsd %xmm2, %xmm3, %xmm3
    vsqrtsd %xmm3, %xmm3, %xmm3
    leaq .Lstr0(%rip), %rdi
    vmovsd %xmm3, %xmm3, %xmm0
    movb $1, %al
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 1
    # LCCC_CALL_FP 1
    xorl %eax, %eax
    addq $2064, %rsp
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main

.section .rodata
.p2align 4
.LCFP_1:
    .quad 4607182418800017408
    .quad 0
.p2align 4
.LCVEC_0:
    .quad 4294967296
    .quad 12884901890

.section .note.GNU-stack,"",@progbits

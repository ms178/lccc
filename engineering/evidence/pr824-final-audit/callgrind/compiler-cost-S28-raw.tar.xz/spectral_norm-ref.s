.section .rodata
.Lstr0:
    .byte 37, 46, 57, 102, 10, 0

.text
.p2align 4
.type mul_AtAv, @function
mul_AtAv:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    pushq %r14
    .cfi_def_cfa_offset 40
    .cfi_offset %r14, -40
    pushq %r15
    .cfi_def_cfa_offset 48
    .cfi_offset %r15, -48
    subq $1232, %rsp
    .cfi_def_cfa_offset 1280
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 0
    movq %rsi, %rbx
    movq %rdx, %r12
    vmovsd .LCFP_0(%rip), %xmm2
    xorl %r11d, %r11d
.LBB1:
    cmpl $128, %r11d
jge .LBB16
.p2align 4,,10
.p2align 3
.LBB2:
    vxorpd %xmm3, %xmm3, %xmm3
    xorl %r10d, %r10d
.LBB3:
    movl $128, %r8d
    subl %r10d, %r8d
    cmpl $3, %r8d
jg .LBB15
.LBB4:
    vmovapd %xmm3, %xmm4
    movq %r10, %r9
.LBB5:
    cmpl $128, %r9d
jge .LBB7
.p2align 4,,10
.p2align 3
.LBB6:
    leal (%r11, %r9), %edi
    leal 1(%rdi), %esi
    imull %esi, %edi
    sarl $1, %edi
    addl %r11d, %edi
    leal 1(%rdi), %eax
    vcvtsi2sdl %eax, %xmm0, %xmm5
    vdivsd %xmm5, %xmm2, %xmm6
    movslq %r9d, %r10
    vfmadd231sd (%rbx, %r10, 8), %xmm6, %xmm4
    addl $1, %r9d
    cmpl $128, %r9d
jl .LBB6
.LBB7:
    movslq %r11d, %rsi
    vmovsd %xmm4, 200(%rsp, %rsi, 8)
    addl $1, %r11d
    cmpl $128, %r11d
jl .LBB2
    jmp .LBB16
.p2align 4,,10
.p2align 3
.LBB8:
    vxorpd %xmm10, %xmm10, %xmm10
    xorl %edi, %edi
.LBB9:
    movl $128, %esi
    subl %edi, %esi
    cmpl $3, %esi
jg .LBB14
.LBB10:
    vmovapd %xmm10, %xmm11
    movq %rdi, %r11
.LBB11:
    cmpl $128, %r11d
jge .LBB13
.p2align 4,,10
.p2align 3
.LBB12:
    leal (%r11, %r9), %r10d
    leal 1(%r10), %r8d
    imull %r8d, %r10d
    sarl $1, %r10d
    addl %r11d, %r10d
    leal 1(%r10), %eax
    vcvtsi2sdl %eax, %xmm0, %xmm12
    vdivsd %xmm12, %xmm9, %xmm13
    movslq %r11d, %rdi
    vfmadd231sd 200(%rsp, %rdi, 8), %xmm13, %xmm11
    leal 1(%r11), %eax
    movl %eax, %r11d
    cmpl $128, %eax
jl .LBB12
.LBB13:
    movslq %r9d, %r8
    vmovsd %xmm11, (%r12, %r8, 8)
    addl $1, %r9d
    cmpl $128, %r9d
jl .LBB8
    jmp .LBB18
.p2align 4,,10
.p2align 3
.LBB14:
    leal 1(%rdi), %r11d
    leal 2(%rdi), %r10d
    leal 3(%rdi), %r8d
    leal (%rdi, %r9), %esi
    leal 1(%rsi), %edx
    imull %edx, %esi
    sarl $1, %esi
    addl %edi, %esi
    leal 1(%rsi), %edx
    leal (%r11, %r9), %esi
    leal 1(%rsi), %r13d
    imull %r13d, %esi
    sarl $1, %esi
    addl %r11d, %esi
    addl $1, %esi
    leal (%r10, %r9), %r11d
    leal 1(%r11), %r14d
    imull %r14d, %r11d
    sarl $1, %r11d
    addl %r10d, %r11d
    addl $1, %r11d
    leal (%r8, %r9), %r10d
    leal 1(%r10), %r15d
    imull %r15d, %r10d
    sarl $1, %r10d
    addl %r8d, %r10d
    addl $1, %r10d
    movslq %edi, %r8
    shlq $3, %r8
    vmovd %edx, %xmm0
    vpinsrd $1, %esi, %xmm0, %xmm0
    vpinsrd $2, %r11d, %xmm0, %xmm0
    vpinsrd $3, %r10d, %xmm0, %xmm0
    vcvtdq2pd %xmm0, %ymm0
    vbroadcastsd .Lvc2(%rip), %ymm1
    vdivpd %ymm0, %ymm1, %ymm0
    vmulpd 200(%rsp, %r8), %ymm0, %ymm0
    vextractf128 $1, %ymm0, %xmm1
    vaddsd %xmm0, %xmm10, %xmm10
    vunpckhpd %xmm0, %xmm0, %xmm0
    vaddsd %xmm0, %xmm10, %xmm10
    vaddsd %xmm1, %xmm10, %xmm10
    vunpckhpd %xmm1, %xmm1, %xmm1
    vaddsd %xmm1, %xmm10, %xmm10
    addl $4, %edi
    movl $128, %esi
    subl %edi, %esi
    cmpl $3, %esi
jg .LBB14
    jmp .LBB10
.p2align 4,,10
.p2align 3
.LBB15:
    leal 1(%r10), %r8d
    leal 2(%r10), %r9d
    leal 3(%r10), %edi
    leal (%r11, %r10), %esi
    leal 1(%rsi), %edx
    imull %edx, %esi
    sarl $1, %esi
    addl %r11d, %esi
    leal 1(%rsi), %edx
    leal (%r11, %r8), %esi
    leal 1(%rsi), %r8d
    imull %r8d, %esi
    sarl $1, %esi
    addl %r11d, %esi
    addl $1, %esi
    leal (%r11, %r9), %r8d
    leal 1(%r8), %r9d
    imull %r9d, %r8d
    sarl $1, %r8d
    addl %r11d, %r8d
    addl $1, %r8d
    leal (%r11, %rdi), %r9d
    leal 1(%r9), %edi
    imull %edi, %r9d
    sarl $1, %r9d
    addl %r11d, %r9d
    addl $1, %r9d
    movslq %r10d, %rdi
    shlq $3, %rdi
    vmovd %edx, %xmm0
    vpinsrd $1, %esi, %xmm0, %xmm0
    vpinsrd $2, %r8d, %xmm0, %xmm0
    vpinsrd $3, %r9d, %xmm0, %xmm0
    vcvtdq2pd %xmm0, %ymm0
    vbroadcastsd .Lvc2(%rip), %ymm1
    vdivpd %ymm0, %ymm1, %ymm0
    vmulpd (%rbx,%rdi), %ymm0, %ymm0
    vextractf128 $1, %ymm0, %xmm1
    vaddsd %xmm0, %xmm3, %xmm3
    vunpckhpd %xmm0, %xmm0, %xmm0
    vaddsd %xmm0, %xmm3, %xmm3
    vaddsd %xmm1, %xmm3, %xmm3
    vunpckhpd %xmm1, %xmm1, %xmm1
    vaddsd %xmm1, %xmm3, %xmm3
    addl $4, %r10d
    movl $128, %esi
    subl %r10d, %esi
    cmpl $3, %esi
jg .LBB15
    jmp .LBB4
.LBB16:
    vmovsd .LCFP_0(%rip), %xmm9
    xorl %r9d, %r9d
.LBB17:
    cmpl $128, %r9d
jl .LBB8
.LBB18:
    vzeroupper
    addq $1232, %rsp
    .cfi_def_cfa_offset 48
    popq %r15
    .cfi_def_cfa_offset 40
    popq %r14
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size mul_AtAv, .-mul_AtAv

.section .rodata
.align 4
.Lvc2:
    .quad 4607182418800017408
.section .text,"ax",@progbits
.globl main
.p2align 4
.type main, @function
main:
.cfi_startproc
    pushq %rbx
    .cfi_def_cfa_offset 16
    .cfi_offset %rbx, -16
    pushq %r12
    .cfi_def_cfa_offset 24
    .cfi_offset %r12, -24
    pushq %r13
    .cfi_def_cfa_offset 32
    .cfi_offset %r13, -32
    subq $2064, %rsp
    .cfi_def_cfa_offset 2096
    # LCCC_RET_XMM 0
    # LCCC_RET_RDX 0
    # LCCC_RET_RAX 1
    xorl %ebx, %ebx
.LBB20:
    cmpq $128, %rbx
jge .LBB22
.p2align 4,,10
.p2align 3
.LBB21:
    movsd .LCFP_0(%rip), %xmm0
    movsd %xmm0, 1032(%rsp, %rbx, 8)
    addq $1, %rbx
    cmpq $128, %rbx
jl .LBB21
.LBB22:
    xorl %r12d, %r12d
.LBB23:
    cmpl $10, %r12d
jge .LBB25
.p2align 4,,10
.p2align 3
.LBB24:
    movl $128, %edi
    leaq 1032(%rsp), %rsi
    leaq 8(%rsp), %rdx
    call mul_AtAv
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    movl $128, %edi
    leaq 8(%rsp), %rsi
    leaq 1032(%rsp), %rdx
    call mul_AtAv
    # LCCC_CALL_ARGS 3
    # LCCC_CALL_FP 0
    addl $1, %r12d
    cmpl $10, %r12d
jl .LBB24
.LBB25:
    xorpd %xmm2, %xmm2
    xorl %r13d, %r13d
    xorpd %xmm3, %xmm3
.LBB26:
    cmpq $128, %r13
jge .LBB28
.p2align 4,,10
.p2align 3
.LBB27:
    movsd 1032(%rsp, %r13, 8), %xmm4
    movsd 8(%rsp, %r13, 8), %xmm5
    vfmadd231sd %xmm5, %xmm4, %xmm3
    vfmadd231sd %xmm5, %xmm5, %xmm2
    addq $1, %r13
    cmpq $128, %r13
jl .LBB27
.LBB28:
    vdivsd %xmm2, %xmm3, %xmm3
    vsqrtsd %xmm3, %xmm3, %xmm3
    leaq .Lstr0(%rip), %rdi
    vmovsd %xmm3, %xmm3, %xmm0
    movb $1, %al
    call printf@PLT
    # LCCC_VA_CALL
    # LCCC_CALL_ARGS 1
    # LCCC_CALL_FP 1
    xorl %eax, %eax
    addq $2064, %rsp
    .cfi_def_cfa_offset 32
    popq %r13
    .cfi_def_cfa_offset 24
    popq %r12
    .cfi_def_cfa_offset 16
    popq %rbx
    .cfi_def_cfa_offset 8
    ret
.cfi_endproc
.size main, .-main

.section .rodata
.p2align 4
.LCFP_0:
    .quad 4607182418800017408
    .quad 0

.section .note.GNU-stack,"",@progbits

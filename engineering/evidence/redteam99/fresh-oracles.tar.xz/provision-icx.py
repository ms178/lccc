import pathlib,urllib.request,hashlib,json,subprocess,gzip
r=pathlib.Path('/home/user/.cache/redteam94'); dest=r/'intel';dest.mkdir(exist_ok=True)
s=(r/'intel-packages.txt').read_text()
try:s+='\n\n'+gzip.decompress(urllib.request.urlopen('https://apt.repos.intel.com/oneapi/dists/all/main/binary-all/Packages.gz',timeout=45).read()).decode()
except Exception as e:print('all-index',e,flush=True)
packages=[]
for part in s.split('\n\n'):
 d=dict(line.split(': ',1) for line in part.splitlines() if ': ' in line and not line.startswith(' '))
 if d.get('Version')=='2026.1.1-325' and d.get('Package') in ['intel-oneapi-dpcpp-cpp-2026.1','intel-oneapi-compiler-shared-2026.1','intel-oneapi-compiler-shared-runtime-2026.1','intel-oneapi-compiler-dpcpp-cpp-common-2026.1','intel-oneapi-compiler-shared-common-2026.1']:packages.append(d)
(r/'icx-packages-selected.json').write_text(json.dumps(packages,indent=2))
for d in packages:
 p=r/pathlib.Path(d['Filename']).name;print('fetch',d['Package'],d['Size'],flush=True)
 urllib.request.urlretrieve('https://apt.repos.intel.com/oneapi/'+d['Filename'],p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==d['SHA256']
 subprocess.run(['dpkg-deb','-x',str(p),str(dest)],check=True);p.unlink();print('extracted',d['Package'],flush=True)
print('COMPLETE',flush=True)

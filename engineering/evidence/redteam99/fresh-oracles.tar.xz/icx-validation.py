import pathlib,json,subprocess,hashlib
r=pathlib.Path('/home/user/.cache/redteam94');cc=r/'intel/opt/intel/oneapi/compiler/2026.1/bin/icx';work=r/'icx-validation';work.mkdir(exist_ok=True);repo=pathlib.Path('/home/user/lccc');rows=[]
version=subprocess.check_output([str(cc),'--version'],text=True)
for case in json.loads((r/'semantic65/index.json').read_text())['cases']:
 binary=work/case['id'].replace('/','-');cmd=case['arms']['gcc_optimized']['build']['command'].copy();cmd[0]=str(cc);cmd[cmd.index('-o')+1]=str(binary);cmd=[x for x in cmd if not x.startswith('-I/usr/lib/gcc/')]
 q=subprocess.run(cmd,capture_output=True,text=True,timeout=60);row={'id':case['id'],'command':cmd,'build_exit':q.returncode,'build_stderr':q.stderr,'source_sha256':case['source_sha256']}
 if q.returncode==0:
  p=subprocess.run([str(binary),*case['arguments']],capture_output=True,timeout=20);row.update(run_exit=p.returncode,stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr=p.stderr.decode(errors='replace'),binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest());row['pass']=p.returncode==0 and row['stdout_sha256']==case['arms']['gcc']['run']['stdout_sha256']
 else:row['pass']=False
 rows.append(row)
for family,driver,source,bad in [('vector','vector-driver.c','vector.s',1),('padding','driver.c','caller.s',13)]:
 for stage,asm,expected in [('original',repo/'tests/regression/fixtures/peephole-padding-effects'/source,0),('before',repo/'engineering/evidence/redteam97'/f'{family}-before.s',bad)]:
  binary=work/f'{family}-{stage}';cmd=[str(cc),'-O2','-Werror',str(repo/'tests/regression/fixtures/peephole-padding-effects'/driver),str(asm),'-o',str(binary)];q=subprocess.run(cmd,capture_output=True,text=True);p=subprocess.run([str(binary)],capture_output=True) if q.returncode==0 else None;rows.append({'id':f'directive/{family}/{stage}','command':cmd,'build_exit':q.returncode,'build_stderr':q.stderr,'run_exit':p.returncode if p else None,'expected_exit':expected,'pass':q.returncode==0 and not q.stderr and p.returncode==expected})
report={'version':version,'binary_sha256':hashlib.sha256(cc.read_bytes()).hexdigest(),'latest_package':'2026.1.1-325','rows':rows,'pass':sum(x['pass'] for x in rows),'total':len(rows)};(work/'index.json').write_text(json.dumps(report,indent=2));print(version);print(report['pass'],report['total']);print([x for x in rows if not x['pass']]);print('diagnostic cases',[x['id'] for x in rows if x['build_stderr']])
